import { useState } from "react";
import { GoalHeader } from "./components/GoalHeader";
import { CategoryFilter } from "./components/CategoryFilter";
import { GoalCategories } from "./components/GoalCategories";
import { ProgressSummary } from "./components/ProgressSummary";
import { AcademicTasks } from "./components/AcademicTasks";
import { HPAMTasks } from "./components/HPAMTasks";
import { ProjectTimeline } from "./components/ProjectTimeline";
import { AIAssistant } from "./components/AIAssistant";
import { Notebook } from "./components/Notebook";
import { ResearchWorkspace } from "./components/ResearchWorkspace";
import { EnhancedGoals } from "./components/EnhancedGoals";
import { DailyDashboard } from "./components/DailyDashboard";
import { HealthAndPersonal } from "./components/HealthAndPersonal";
import { PersonalGrowth } from "./components/PersonalGrowth";
import { ProfessionalGoalsTracker } from "./components/ProfessionalGoalsTracker";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./components/ui/tabs";
import {
  Target,
  BookOpen,
  FileText,
  Bot,
  PenTool,
  GraduationCap,
  Search,
  Zap,
  Calendar,
  Heart,
  Users,
  Trophy,
} from "lucide-react";

export function Planner() {
  const [selectedCategory, setSelectedCategory] = useState<string>("all");

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50 dark:from-gray-950 dark:via-purple-950/20 dark:to-blue-950/20 transition-all duration-500">
      <GoalHeader />
      <div className="max-w-7xl mx-auto px-6 py-8">
        <Tabs defaultValue="daily-dashboard" className="w-full">
          <TabsList className="grid w-full max-w-7xl mx-auto grid-cols-12 mb-8 bg-white/70 dark:bg-gray-900/70 backdrop-blur-sm border-purple-200/50 dark:border-purple-700/30">
            <TabsTrigger value="daily-dashboard" className="flex items-center gap-1 text-xs data-[state=active]:bg-purple-100 dark:data-[state=active]:bg-purple-900/50 data-[state=active]:text-purple-700 dark:data-[state=active]:text-purple-300">
              <Calendar className="w-3 h-3" />
              Daily
            </TabsTrigger>
            <TabsTrigger value="enhanced-goals" className="flex items-center gap-1 text-xs data-[state=active]:bg-purple-100 dark:data-[state=active]:bg-purple-900/50 data-[state=active]:text-purple-700 dark:data-[state=active]:text-purple-300">
              <Zap className="w-3 h-3" />
              Enhanced
            </TabsTrigger>
            <TabsTrigger value="goals" className="flex items-center gap-1 text-xs data-[state=active]:bg-purple-100 dark:data-[state=active]:bg-purple-900/50 data-[state=active]:text-purple-700 dark:data-[state=active]:text-purple-300">
              <Target className="w-3 h-3" />
              Goals
            </TabsTrigger>
            <TabsTrigger value="professional" className="flex items-center gap-1 text-xs data-[state=active]:bg-purple-100 dark:data-[state=active]:bg-purple-900/50 data-[state=active]:text-purple-700 dark:data-[state=active]:text-purple-300">
              <Trophy className="w-3 h-3" />
              Professional
            </TabsTrigger>
            <TabsTrigger value="research" className="flex items-center gap-1 text-xs data-[state=active]:bg-purple-100 dark:data-[state=active]:bg-purple-900/50 data-[state=active]:text-purple-700 dark:data-[state=active]:text-purple-300">
              <Search className="w-3 h-3" />
              Research
            </TabsTrigger>
            <TabsTrigger value="tasks" className="flex items-center gap-1 text-xs data-[state=active]:bg-purple-100 dark:data-[state=active]:bg-purple-900/50 data-[state=active]:text-purple-700 dark:data-[state=active]:text-purple-300">
              <BookOpen className="w-3 h-3" />
              Tasks
            </TabsTrigger>
            <TabsTrigger value="hpam" className="flex items-center gap-1 text-xs data-[state=active]:bg-purple-100 dark:data-[state=active]:bg-purple-900/50 data-[state=active]:text-purple-700 dark:data-[state=active]:text-purple-300">
              <GraduationCap className="w-3 h-3" />
              Leadership
            </TabsTrigger>
            <TabsTrigger value="project" className="flex items-center gap-1 text-xs data-[state=active]:bg-purple-100 dark:data-[state=active]:bg-purple-900/50 data-[state=active]:text-purple-700 dark:data-[state=active]:text-purple-300">
              <FileText className="w-3 h-3" />
              DMAN
            </TabsTrigger>
            <TabsTrigger value="notebook" className="flex items-center gap-1 text-xs data-[state=active]:bg-purple-100 dark:data-[state=active]:bg-purple-900/50 data-[state=active]:text-purple-700 dark:data-[state=active]:text-purple-300">
              <PenTool className="w-3 h-3" />
              Notebook
            </TabsTrigger>
            <TabsTrigger value="assistant" className="flex items-center gap-1 text-xs data-[state=active]:bg-purple-100 dark:data-[state=active]:bg-purple-900/50 data-[state=active]:text-purple-700 dark:data-[state=active]:text-purple-300">
              <Bot className="w-3 h-3" />
              AI
            </TabsTrigger>
            <TabsTrigger value="health" className="flex items-center gap-1 text-xs data-[state=active]:bg-purple-100 dark:data-[state=active]:bg-purple-900/50 data-[state=active]:text-purple-700 dark:data-[state=active]:text-purple-300">
              <Heart className="w-3 h-3" />
              Health
            </TabsTrigger>
            <TabsTrigger value="growth" className="flex items-center gap-1 text-xs data-[state=active]:bg-purple-100 dark:data-[state=active]:bg-purple-900/50 data-[state=active]:text-purple-700 dark:data-[state=active]:text-purple-300">
              <Users className="w-3 h-3" />
              Growth
            </TabsTrigger>
          </TabsList>

          <TabsContent value="daily-dashboard"><DailyDashboard /></TabsContent>
          <TabsContent value="enhanced-goals"><EnhancedGoals /></TabsContent>
          <TabsContent value="goals">
            <CategoryFilter selectedCategory={selectedCategory} onCategoryChange={setSelectedCategory}/>
            <ProgressSummary selectedCategory={selectedCategory} />
            <GoalCategories selectedCategory={selectedCategory} />
          </TabsContent>
          <TabsContent value="professional"><ProfessionalGoalsTracker /></TabsContent>
          <TabsContent value="research"><ResearchWorkspace /></TabsContent>
          <TabsContent value="tasks"><AcademicTasks /></TabsContent>
          <TabsContent value="hpam"><HPAMTasks /></TabsContent>
          <TabsContent value="project"><ProjectTimeline /></TabsContent>
          <TabsContent value="notebook"><Notebook /></TabsContent>
          <TabsContent value="assistant">
            <div className="max-w-4xl mx-auto"><AIAssistant /></div>
          </TabsContent>
          <TabsContent value="health"><HealthAndPersonal /></TabsContent>
          <TabsContent value="growth"><PersonalGrowth /></TabsContent>
        </Tabs>
      </div>
    </div>
  );
}