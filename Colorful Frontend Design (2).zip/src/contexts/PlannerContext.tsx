import { createContext, useContext, useState, ReactNode, useEffect } from 'react';

// Types for all data structures
export interface Skill {
  id: string;
  name: string;
  category: string;
  proficiency: number;
  status: 'learning' | 'intermediate' | 'advanced' | 'expert';
  priority: 'high' | 'medium' | 'low';
  description?: string;
  targetProficiency?: number;
}

export interface Project {
  id: string;
  title: string;
  status: 'completed' | 'in-progress' | 'planned';
  date: string;
  course?: string;
  skills: string[];
  impact: string;
  lessons: string;
  category: string;
  progress?: number;
}

export interface Certification {
  id: string;
  name: string;
  provider: string;
  status: 'completed' | 'in-progress' | 'planned';
  completionDate?: string;
  priority: 'high' | 'medium' | 'low';
  relevance: string;
  cost?: number;
  url?: string;
}

export interface CareerGoal {
  id: string;
  title: string;
  description: string;
  targetDate: string;
  progress: number;
  milestones: string[];
  category: string;
  priority: 'high' | 'medium' | 'low';
  status: 'active' | 'completed' | 'paused';
}

export interface Goal {
  id: string;
  title: string;
  description: string;
  category: string;
  progress: number;
  priority: 'high' | 'medium' | 'low';
  status: 'active' | 'completed' | 'paused';
  dueDate?: string;
  tags: string[];
}

export interface Task {
  id: string;
  title: string;
  description: string;
  category: string;
  priority: 'high' | 'medium' | 'low';
  status: 'todo' | 'in-progress' | 'completed';
  dueDate?: string;
  course?: string;
  estimatedHours?: number;
  actualHours?: number;
}

export interface HealthMetric {
  id: string;
  name: string;
  type: 'daily' | 'weekly' | 'monthly';
  target: number;
  current: number;
  unit: string;
  category: 'fitness' | 'nutrition' | 'mental' | 'sleep';
}

export interface NetworkingEvent {
  id: string;
  eventName: string;
  date: string;
  peopleMet: string[];
  lessonsLearned: string;
  followUpActions: string[];
  category: string;
  location?: string;
  type: 'conference' | 'meetup' | 'workshop' | 'informal';
}

export interface ReadingItem {
  id: string;
  title: string;
  author: string;
  type: 'book' | 'article' | 'paper' | 'blog';
  status: 'to-read' | 'reading' | 'completed';
  keyTakeaways: string;
  relevance: string;
  rating?: number;
  dateCompleted?: string;
}

export interface CalendarEvent {
  id: string;
  title: string;
  date: string;
  time: string;
  type: 'class' | 'assignment' | 'meeting' | 'personal' | 'deadline';
  description?: string;
  priority: 'high' | 'medium' | 'low';
}

// Context interface
interface PlannerContextType {
  // Data
  skills: Skill[];
  projects: Project[];
  certifications: Certification[];
  careerGoals: CareerGoal[];
  goals: Goal[];
  tasks: Task[];
  healthMetrics: HealthMetric[];
  networkingEvents: NetworkingEvent[];
  readingList: ReadingItem[];
  calendarEvents: CalendarEvent[];
  
  // Skills methods
  addSkill: (skill: Omit<Skill, 'id'>) => void;
  updateSkill: (id: string, updates: Partial<Skill>) => void;
  deleteSkill: (id: string) => void;
  
  // Projects methods
  addProject: (project: Omit<Project, 'id'>) => void;
  updateProject: (id: string, updates: Partial<Project>) => void;
  deleteProject: (id: string) => void;
  
  // Certifications methods
  addCertification: (cert: Omit<Certification, 'id'>) => void;
  updateCertification: (id: string, updates: Partial<Certification>) => void;
  deleteCertification: (id: string) => void;
  
  // Career Goals methods
  addCareerGoal: (goal: Omit<CareerGoal, 'id'>) => void;
  updateCareerGoal: (id: string, updates: Partial<CareerGoal>) => void;
  deleteCareerGoal: (id: string) => void;
  
  // Goals methods
  addGoal: (goal: Omit<Goal, 'id'>) => void;
  updateGoal: (id: string, updates: Partial<Goal>) => void;
  deleteGoal: (id: string) => void;
  
  // Tasks methods
  addTask: (task: Omit<Task, 'id'>) => void;
  updateTask: (id: string, updates: Partial<Task>) => void;
  deleteTask: (id: string) => void;
  
  // Health Metrics methods
  addHealthMetric: (metric: Omit<HealthMetric, 'id'>) => void;
  updateHealthMetric: (id: string, updates: Partial<HealthMetric>) => void;
  deleteHealthMetric: (id: string) => void;
  
  // Networking Events methods
  addNetworkingEvent: (event: Omit<NetworkingEvent, 'id'>) => void;
  updateNetworkingEvent: (id: string, updates: Partial<NetworkingEvent>) => void;
  deleteNetworkingEvent: (id: string) => void;
  
  // Reading List methods
  addReadingItem: (item: Omit<ReadingItem, 'id'>) => void;
  updateReadingItem: (id: string, updates: Partial<ReadingItem>) => void;
  deleteReadingItem: (id: string) => void;
  
  // Calendar Events methods
  addCalendarEvent: (event: Omit<CalendarEvent, 'id'>) => void;
  updateCalendarEvent: (id: string, updates: Partial<CalendarEvent>) => void;
  deleteCalendarEvent: (id: string) => void;
  
  // Theme and customization
  theme: 'light' | 'dark';
  toggleTheme: () => void;
  customColors: Record<string, string>;
  updateCustomColors: (colors: Record<string, string>) => void;
}

const PlannerContext = createContext<PlannerContextType | undefined>(undefined);

// Initial data
const initialSkills: Skill[] = [
  { id: '1', name: 'SQL', category: 'Technical', proficiency: 75, status: 'intermediate', priority: 'high', targetProficiency: 90 },
  { id: '2', name: 'R Programming', category: 'Technical', proficiency: 80, status: 'intermediate', priority: 'high', targetProficiency: 95 },
  { id: '3', name: 'Python', category: 'Technical', proficiency: 60, status: 'learning', priority: 'high', targetProficiency: 85 },
  { id: '4', name: 'Tableau', category: 'Technical', proficiency: 70, status: 'intermediate', priority: 'high', targetProficiency: 90 },
  { id: '5', name: 'Epidemiology', category: 'Domain', proficiency: 85, status: 'advanced', priority: 'high', targetProficiency: 95 },
  { id: '6', name: 'Program Evaluation', category: 'Domain', proficiency: 75, status: 'intermediate', priority: 'high', targetProficiency: 90 },
  { id: '7', name: 'Grant Writing', category: 'Professional', proficiency: 40, status: 'learning', priority: 'medium', targetProficiency: 80 },
  { id: '8', name: 'Public Speaking', category: 'Professional', proficiency: 55, status: 'learning', priority: 'medium', targetProficiency: 85 }
];

const initialProjects: Project[] = [
  {
    id: '1',
    title: 'Vaccines for Children (VFC) Program Evaluation',
    status: 'completed',
    date: 'Spring 2025',
    course: 'Health Program Planning & Evaluation',
    skills: ['Data Collection', 'Stakeholder Interviewing', 'Program Assessment'],
    impact: 'Identified key improvement areas for Georgia\'s VFC program',
    lessons: 'Program evaluation requires both quantitative data and qualitative stakeholder insights',
    category: 'Academic',
    progress: 100
  },
  {
    id: '2',
    title: 'MERS-CoV Surveillance Gap Analysis (Oman)',
    status: 'completed',
    date: 'Spring 2025',
    course: 'Public Health Surveillance',
    skills: ['Surveillance Evaluation', 'Gap Analysis', 'International Health Systems'],
    impact: 'Provided recommendations for strengthening MERS-CoV surveillance in Oman',
    lessons: 'Early detection systems are critical for global health security',
    category: 'Academic',
    progress: 100
  },
  {
    id: '3',
    title: 'Health Disparities Data Dashboard',
    status: 'in-progress',
    date: 'Fall 2025',
    skills: ['Data Visualization', 'Python', 'Public Health Analytics'],
    impact: 'Creating interactive tool for health equity research',
    lessons: 'Data storytelling is crucial for policy impact',
    category: 'Personal',
    progress: 65
  }
];

const initialCertifications: Certification[] = [
  {
    id: '1',
    name: 'SQL & Tableau Certification',
    provider: 'LinkedIn Learning',
    status: 'in-progress',
    priority: 'high',
    relevance: 'Essential for health informatics roles'
  },
  {
    id: '2',
    name: 'Python for Data Science',
    provider: 'edX Verizon',
    status: 'in-progress',
    priority: 'high',
    relevance: 'Critical for advanced data analysis positions'
  }
];

const initialCareerGoals: CareerGoal[] = [
  {
    id: '1',
    title: 'Secure CDC PHIFP Fellowship',
    description: 'Apply and be accepted to the CDC Public Health Informatics Fellowship Program for 2026',
    targetDate: 'March 2026',
    progress: 35,
    milestones: ['Complete application portfolio', 'Strengthen technical skills', 'Network with current fellows'],
    category: 'Career Development',
    priority: 'high',
    status: 'active'
  },
  {
    id: '2',
    title: 'Complete APE at Global Health Organization',
    description: 'Secure and complete Applied Practice Experience at WHO, Carter Center, or similar organization',
    targetDate: 'August 2025',
    progress: 60,
    milestones: ['Research opportunities', 'Submit applications', 'Prepare for interviews'],
    category: 'Academic',
    priority: 'high',
    status: 'active'
  }
];

export function PlannerProvider({ children }: { children: ReactNode }) {
  // State for all data
  const [skills, setSkills] = useState<Skill[]>(initialSkills);
  const [projects, setProjects] = useState<Project[]>(initialProjects);
  const [certifications, setCertifications] = useState<Certification[]>(initialCertifications);
  const [careerGoals, setCareerGoals] = useState<CareerGoal[]>(initialCareerGoals);
  const [goals, setGoals] = useState<Goal[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [healthMetrics, setHealthMetrics] = useState<HealthMetric[]>([]);
  const [networkingEvents, setNetworkingEvents] = useState<NetworkingEvent[]>([]);
  const [readingList, setReadingList] = useState<ReadingItem[]>([]);
  const [calendarEvents, setCalendarEvents] = useState<CalendarEvent[]>([]);
  
  // Theme state
  const [theme, setTheme] = useState<'light' | 'dark'>('light');
  const [customColors, setCustomColors] = useState<Record<string, string>>({});

  // Load data from localStorage on mount
  useEffect(() => {
    const savedData = localStorage.getItem('plannerData');
    if (savedData) {
      try {
        const data = JSON.parse(savedData);
        setSkills(data.skills || initialSkills);
        setProjects(data.projects || initialProjects);
        setCertifications(data.certifications || initialCertifications);
        setCareerGoals(data.careerGoals || initialCareerGoals);
        setGoals(data.goals || []);
        setTasks(data.tasks || []);
        setHealthMetrics(data.healthMetrics || []);
        setNetworkingEvents(data.networkingEvents || []);
        setReadingList(data.readingList || []);
        setCalendarEvents(data.calendarEvents || []);
        setCustomColors(data.customColors || {});
      } catch (error) {
        console.error('Error loading planner data:', error);
      }
    }
    
    const savedTheme = localStorage.getItem('plannerTheme') as 'light' | 'dark';
    if (savedTheme) {
      setTheme(savedTheme);
      document.documentElement.classList.toggle('dark', savedTheme === 'dark');
    }
  }, []);

  // Save data to localStorage when state changes
  useEffect(() => {
    const data = {
      skills,
      projects,
      certifications,
      careerGoals,
      goals,
      tasks,
      healthMetrics,
      networkingEvents,
      readingList,
      calendarEvents,
      customColors
    };
    localStorage.setItem('plannerData', JSON.stringify(data));
  }, [skills, projects, certifications, careerGoals, goals, tasks, healthMetrics, networkingEvents, readingList, calendarEvents, customColors]);

  // Generic CRUD methods
  const generateId = () => Date.now().toString() + Math.random().toString(36).substr(2, 9);

  // Skills methods
  const addSkill = (skill: Omit<Skill, 'id'>) => {
    setSkills(prev => [...prev, { ...skill, id: generateId() }]);
  };

  const updateSkill = (id: string, updates: Partial<Skill>) => {
    setSkills(prev => prev.map(skill => skill.id === id ? { ...skill, ...updates } : skill));
  };

  const deleteSkill = (id: string) => {
    setSkills(prev => prev.filter(skill => skill.id !== id));
  };

  // Projects methods
  const addProject = (project: Omit<Project, 'id'>) => {
    setProjects(prev => [...prev, { ...project, id: generateId() }]);
  };

  const updateProject = (id: string, updates: Partial<Project>) => {
    setProjects(prev => prev.map(project => project.id === id ? { ...project, ...updates } : project));
  };

  const deleteProject = (id: string) => {
    setProjects(prev => prev.filter(project => project.id !== id));
  };

  // Certifications methods
  const addCertification = (cert: Omit<Certification, 'id'>) => {
    setCertifications(prev => [...prev, { ...cert, id: generateId() }]);
  };

  const updateCertification = (id: string, updates: Partial<Certification>) => {
    setCertifications(prev => prev.map(cert => cert.id === id ? { ...cert, ...updates } : cert));
  };

  const deleteCertification = (id: string) => {
    setCertifications(prev => prev.filter(cert => cert.id !== id));
  };

  // Career Goals methods
  const addCareerGoal = (goal: Omit<CareerGoal, 'id'>) => {
    setCareerGoals(prev => [...prev, { ...goal, id: generateId() }]);
  };

  const updateCareerGoal = (id: string, updates: Partial<CareerGoal>) => {
    setCareerGoals(prev => prev.map(goal => goal.id === id ? { ...goal, ...updates } : goal));
  };

  const deleteCareerGoal = (id: string) => {
    setCareerGoals(prev => prev.filter(goal => goal.id !== id));
  };

  // Goals methods
  const addGoal = (goal: Omit<Goal, 'id'>) => {
    setGoals(prev => [...prev, { ...goal, id: generateId() }]);
  };

  const updateGoal = (id: string, updates: Partial<Goal>) => {
    setGoals(prev => prev.map(goal => goal.id === id ? { ...goal, ...updates } : goal));
  };

  const deleteGoal = (id: string) => {
    setGoals(prev => prev.filter(goal => goal.id !== id));
  };

  // Tasks methods
  const addTask = (task: Omit<Task, 'id'>) => {
    setTasks(prev => [...prev, { ...task, id: generateId() }]);
  };

  const updateTask = (id: string, updates: Partial<Task>) => {
    setTasks(prev => prev.map(task => task.id === id ? { ...task, ...updates } : task));
  };

  const deleteTask = (id: string) => {
    setTasks(prev => prev.filter(task => task.id !== id));
  };

  // Health Metrics methods
  const addHealthMetric = (metric: Omit<HealthMetric, 'id'>) => {
    setHealthMetrics(prev => [...prev, { ...metric, id: generateId() }]);
  };

  const updateHealthMetric = (id: string, updates: Partial<HealthMetric>) => {
    setHealthMetrics(prev => prev.map(metric => metric.id === id ? { ...metric, ...updates } : metric));
  };

  const deleteHealthMetric = (id: string) => {
    setHealthMetrics(prev => prev.filter(metric => metric.id !== id));
  };

  // Networking Events methods
  const addNetworkingEvent = (event: Omit<NetworkingEvent, 'id'>) => {
    setNetworkingEvents(prev => [...prev, { ...event, id: generateId() }]);
  };

  const updateNetworkingEvent = (id: string, updates: Partial<NetworkingEvent>) => {
    setNetworkingEvents(prev => prev.map(event => event.id === id ? { ...event, ...updates } : event));
  };

  const deleteNetworkingEvent = (id: string) => {
    setNetworkingEvents(prev => prev.filter(event => event.id !== id));
  };

  // Reading List methods
  const addReadingItem = (item: Omit<ReadingItem, 'id'>) => {
    setReadingList(prev => [...prev, { ...item, id: generateId() }]);
  };

  const updateReadingItem = (id: string, updates: Partial<ReadingItem>) => {
    setReadingList(prev => prev.map(item => item.id === id ? { ...item, ...updates } : item));
  };

  const deleteReadingItem = (id: string) => {
    setReadingList(prev => prev.filter(item => item.id !== id));
  };

  // Calendar Events methods
  const addCalendarEvent = (event: Omit<CalendarEvent, 'id'>) => {
    setCalendarEvents(prev => [...prev, { ...event, id: generateId() }]);
  };

  const updateCalendarEvent = (id: string, updates: Partial<CalendarEvent>) => {
    setCalendarEvents(prev => prev.map(event => event.id === id ? { ...event, ...updates } : event));
  };

  const deleteCalendarEvent = (id: string) => {
    setCalendarEvents(prev => prev.filter(event => event.id !== id));
  };

  // Theme methods
  const toggleTheme = () => {
    const newTheme = theme === 'light' ? 'dark' : 'light';
    setTheme(newTheme);
    document.documentElement.classList.toggle('dark', newTheme === 'dark');
    localStorage.setItem('plannerTheme', newTheme);
  };

  const updateCustomColors = (colors: Record<string, string>) => {
    setCustomColors(colors);
  };

  const value: PlannerContextType = {
    // Data
    skills,
    projects,
    certifications,
    careerGoals,
    goals,
    tasks,
    healthMetrics,
    networkingEvents,
    readingList,
    calendarEvents,
    
    // Methods
    addSkill,
    updateSkill,
    deleteSkill,
    addProject,
    updateProject,
    deleteProject,
    addCertification,
    updateCertification,
    deleteCertification,
    addCareerGoal,
    updateCareerGoal,
    deleteCareerGoal,
    addGoal,
    updateGoal,
    deleteGoal,
    addTask,
    updateTask,
    deleteTask,
    addHealthMetric,
    updateHealthMetric,
    deleteHealthMetric,
    addNetworkingEvent,
    updateNetworkingEvent,
    deleteNetworkingEvent,
    addReadingItem,
    updateReadingItem,
    deleteReadingItem,
    addCalendarEvent,
    updateCalendarEvent,
    deleteCalendarEvent,
    
    // Theme
    theme,
    toggleTheme,
    customColors,
    updateCustomColors
  };

  return (
    <PlannerContext.Provider value={value}>
      {children}
    </PlannerContext.Provider>
  );
}

export const usePlanner = () => {
  const context = useContext(PlannerContext);
  if (context === undefined) {
    throw new Error('usePlanner must be used within a PlannerProvider');
  }
  return context;
};