import { ColorfulHero } from "./components/ColorfulHero";
import { FeatureCards } from "./components/FeatureCards";
import { ColorfulStats } from "./components/ColorfulStats";
import { InteractiveSection } from "./components/InteractiveSection";
import { ColorfulFooter } from "./components/ColorfulFooter";
import { SkillsAndAdvice } from "./components/SkillsAndAdvice";
import { ProjectsShowcase } from "./components/ProjectsShowcase";
import { APESection } from "./components/APESection";
import { ProfessionalDevelopment } from "./components/ProfessionalDevelopment";

export function Portfolio() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50 dark:from-gray-950 dark:via-purple-950/20 dark:to-blue-950/20 transition-all duration-500">
      <ColorfulHero />
      <ColorfulStats />
      <SkillsAndAdvice />
      <ProjectsShowcase />
      <APESection />
      <ProfessionalDevelopment />
      <FeatureCards />
      <InteractiveSection />

      {/* Contact Section */}
      <section id="contact" className="py-16 px-6 bg-gradient-to-r from-blue-50 via-purple-50 to-pink-50 dark:from-blue-950/30 dark:via-purple-950/30 dark:to-pink-950/30 transition-all duration-500">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold mb-6 text-center bg-gradient-to-r from-blue-600 to-purple-600 dark:from-blue-400 dark:to-purple-400 bg-clip-text text-transparent">
            Contact & Resume
          </h2>
          <p className="text-center text-sm mb-6 text-gray-600 dark:text-gray-300">
            Connect with me or view my resume below:
          </p>
          <div className="flex justify-center gap-8">
            <a
              href="https://www.linkedin.com/in/lidiya-kassahun"
              target="_blank"
              className="group flex items-center gap-2 px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition-all duration-200 hover:scale-105 shadow-lg"
            >
              LinkedIn
            </a>
            <a
              href="https://github.com/Lidi-k"
              target="_blank"
              className="group flex items-center gap-2 px-6 py-3 bg-gray-800 hover:bg-gray-900 text-white rounded-lg font-medium transition-all duration-200 hover:scale-105 shadow-lg"
            >
              GitHub
            </a>
            <a
              href="/resume.pdf"
              target="_blank"
              className="group flex items-center gap-2 px-6 py-3 bg-purple-600 hover:bg-purple-700 text-white rounded-lg font-medium transition-all duration-200 hover:scale-105 shadow-lg"
            >
              Resume PDF
            </a>
          </div>
        </div>
      </section>

      <ColorfulFooter />
    </div>
  );
}