import { Planner } from "./Planner";
import { NavBar } from "./components/NavBar";
import { PlannerProvider } from "./contexts/PlannerContext";

/**
 * App component
 *
 * Main planner application with navigation and global state management.
 */
export default function App() {
  return (
    <PlannerProvider>
      <div className="min-h-screen transition-all duration-500">
        <NavBar />
        <Planner />
      </div>
    </PlannerProvider>
  );
}