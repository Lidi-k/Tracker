import { useState } from "react";
import {
  Dialog,
  DialogTrigger,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "./ui/dialog";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { Button } from "./ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Badge } from "./ui/badge";
import { Label } from "./ui/label";
import { Switch } from "./ui/switch";
import { Separator } from "./ui/separator";
import { Calendar } from "./ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "./ui/popover";
import { 
  Plus, 
  Calendar as CalendarIcon, 
  Target, 
  BookOpen, 
  GraduationCap, 
  Search, 
  PenTool,
  Star,
  Clock,
  Flag,
  Tag,
  Upload,
  Mic,
  Camera,
  Palette
} from "lucide-react";
// Utility function to format date
const format = (date: Date, formatStr: string) => {
  if (formatStr === 'yyyy-MM-dd') {
    return date.toISOString().split('T')[0];
  }
  if (formatStr === 'MMM dd, yyyy') {
    return date.toLocaleDateString('en-US', { 
      month: 'short', 
      day: '2-digit', 
      year: 'numeric' 
    });
  }
  return date.toISOString().split('T')[0];
};

export interface BasicTask {
  title: string;
  description: string;
  due_date: string;
  type: string;
  course: string;
  priority?: 'low' | 'medium' | 'high';
  category?: string;
  tags?: string[];
  attachments?: string[];
  estimatedTime?: number;
  recurring?: boolean;
  reminderTime?: string;
  color?: string;
  mood?: string;
}

interface AddTaskModalProps {
  onAdd: (task: BasicTask) => void;
  triggerText?: string;
  triggerIcon?: React.ReactNode;
  triggerVariant?: "default" | "outline" | "secondary" | "ghost" | "link" | "destructive";
  modalTitle?: string;
  modalDescription?: string;
  defaultType?: string;
  defaultCourse?: string;
  defaultCategory?: string;
  showAdvancedOptions?: boolean;
  customFields?: Array<{
    name: string;
    label: string;
    type: 'text' | 'select' | 'textarea' | 'date' | 'number' | 'switch';
    options?: string[];
    required?: boolean;
  }>;
  predefinedTypes?: string[];
  predefinedCourses?: string[];
  predefinedCategories?: string[];
  colorTheme?: 'purple' | 'blue' | 'green' | 'pink' | 'orange' | 'indigo';
}

export function AddTaskModal({ 
  onAdd,
  triggerText = "Add New",
  triggerIcon = <Plus className="w-4 h-4" />,
  triggerVariant = "outline",
  modalTitle = "Add New Item",
  modalDescription = "Fill in the details and press Save",
  defaultType = "",
  defaultCourse = "",
  defaultCategory = "",
  showAdvancedOptions = true,
  customFields = [],
  predefinedTypes = ["Assignment", "Exam", "Project", "Journal", "Research", "Reading", "Lab", "Presentation", "Discussion", "Quiz"],
  predefinedCourses = ["HPAM7700E", "DMAN7100E", "BIOS7210", "EPID7001", "ENVH7005", "HLTH7015", "Personal", "Professional"],
  predefinedCategories = ["Academic/MPH", "Professional Development", "Volunteering", "Skill Building", "Applied Practice", "Health & Personal", "Financial", "Personal Growth"],
  colorTheme = 'purple'
}: AddTaskModalProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [dueDate, setDueDate] = useState<Date>();
  const [course, setCourse] = useState(defaultCourse);
  const [type, setType] = useState(defaultType);
  const [category, setCategory] = useState(defaultCategory);
  const [priority, setPriority] = useState<'low' | 'medium' | 'high'>('medium');
  const [tags, setTags] = useState("");
  const [estimatedTime, setEstimatedTime] = useState<number>();
  const [recurring, setRecurring] = useState(false);
  const [reminderTime, setReminderTime] = useState("");
  const [color, setColor] = useState("");
  const [mood, setMood] = useState("");
  const [customFieldValues, setCustomFieldValues] = useState<Record<string, any>>({});
  const [showAdvanced, setShowAdvanced] = useState(false);

  const themeColors = {
    purple: {
      gradient: "from-purple-50 to-pink-50",
      primary: "bg-purple-600 hover:bg-purple-700",
      secondary: "bg-purple-100 text-purple-700",
      border: "border-purple-200",
      text: "text-purple-700"
    },
    blue: {
      gradient: "from-blue-50 to-cyan-50",
      primary: "bg-blue-600 hover:bg-blue-700",
      secondary: "bg-blue-100 text-blue-700",
      border: "border-blue-200",
      text: "text-blue-700"
    },
    green: {
      gradient: "from-green-50 to-emerald-50",
      primary: "bg-green-600 hover:bg-green-700",
      secondary: "bg-green-100 text-green-700",
      border: "border-green-200",
      text: "text-green-700"
    },
    pink: {
      gradient: "from-pink-50 to-rose-50",
      primary: "bg-pink-600 hover:bg-pink-700",
      secondary: "bg-pink-100 text-pink-700",
      border: "border-pink-200",
      text: "text-pink-700"
    },
    orange: {
      gradient: "from-orange-50 to-amber-50",
      primary: "bg-orange-600 hover:bg-orange-700",
      secondary: "bg-orange-100 text-orange-700",
      border: "border-orange-200",
      text: "text-orange-700"
    },
    indigo: {
      gradient: "from-indigo-50 to-purple-50",
      primary: "bg-indigo-600 hover:bg-indigo-700",
      secondary: "bg-indigo-100 text-indigo-700",
      border: "border-indigo-200",
      text: "text-indigo-700"
    }
  };

  const theme = themeColors[colorTheme];

  const handleSubmit = () => {
    if (!title) return;
    
    const taskData: BasicTask = {
      title,
      description,
      due_date: dueDate ? format(dueDate, 'yyyy-MM-dd') : '',
      type: type || "General",
      course: course || "Other",
      priority,
      category,
      tags: tags.split(',').map(tag => tag.trim()).filter(tag => tag),
      estimatedTime,
      recurring,
      reminderTime,
      color,
      mood,
      ...customFieldValues
    };

    onAdd(taskData);
    
    // Reset form
    setTitle("");
    setDescription("");
    setDueDate(undefined);
    setCourse(defaultCourse);
    setType(defaultType);
    setCategory(defaultCategory);
    setPriority('medium');
    setTags("");
    setEstimatedTime(undefined);
    setRecurring(false);
    setReminderTime("");
    setColor("");
    setMood("");
    setCustomFieldValues({});
    setShowAdvanced(false);
    setIsOpen(false);
  };

  const priorityColors = {
    low: "bg-green-100 text-green-700 border-green-200",
    medium: "bg-yellow-100 text-yellow-700 border-yellow-200",
    high: "bg-red-100 text-red-700 border-red-200"
  };

  const moodEmojis = ['🚀', '🎯', '✨', '💪', '🧘', '🌟', '💡', '🔥', '🌸', '🦋'];
  const colorOptions = ['#8B5CF6', '#EC4899', '#06B6D4', '#10B981', '#F59E0B', '#EF4444', '#6366F1', '#84CC16'];

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant={triggerVariant} className={theme.primary}>
          {triggerIcon}
          <span className="ml-2">{triggerText}</span>
        </Button>
      </DialogTrigger>
      <DialogContent className={`max-w-2xl max-h-[90vh] overflow-y-auto bg-gradient-to-br ${theme.gradient}`}>
        <DialogHeader>
          <DialogTitle className={`${theme.text} text-xl`}>{modalTitle}</DialogTitle>
          <DialogDescription className="text-gray-600">
            {modalDescription}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Basic Information */}
          <div className="space-y-4">
            <div>
              <Label htmlFor="title" className="text-sm font-medium">Title *</Label>
              <Input
                id="title"
                placeholder="Enter title..."
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="mt-1"
              />
            </div>

            <div>
              <Label htmlFor="description" className="text-sm font-medium">Description</Label>
              <Textarea
                id="description"
                placeholder="Add details, notes, or context..."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={3}
                className="mt-1 resize-none"
              />
            </div>

            {/* Primary Fields Row */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label className="text-sm font-medium">Type</Label>
                <Select value={type} onValueChange={setType}>
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    {predefinedTypes.map((typeOption) => (
                      <SelectItem key={typeOption} value={typeOption}>{typeOption}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="text-sm font-medium">Course/Context</Label>
                <Select value={course} onValueChange={setCourse}>
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Select course" />
                  </SelectTrigger>
                  <SelectContent>
                    {predefinedCourses.map((courseOption) => (
                      <SelectItem key={courseOption} value={courseOption}>{courseOption}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="text-sm font-medium">Due Date</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="w-full mt-1 justify-start text-left font-normal">
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {dueDate ? format(dueDate, "MMM dd, yyyy") : "Pick date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={dueDate}
                      onSelect={setDueDate}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </div>

            {/* Priority and Category */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label className="text-sm font-medium">Priority</Label>
                <div className="flex gap-2 mt-2">
                  {(['low', 'medium', 'high'] as const).map((priorityLevel) => (
                    <Button
                      key={priorityLevel}
                      variant={priority === priorityLevel ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setPriority(priorityLevel)}
                      className={priority === priorityLevel ? priorityColors[priorityLevel] : ''}
                    >
                      <Flag className="w-3 h-3 mr-1" />
                      {priorityLevel.charAt(0).toUpperCase() + priorityLevel.slice(1)}
                    </Button>
                  ))}
                </div>
              </div>

              <div>
                <Label className="text-sm font-medium">Category</Label>
                <Select value={category} onValueChange={setCategory}>
                  <SelectTrigger className="mt-2">
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    {predefinedCategories.map((catOption) => (
                      <SelectItem key={catOption} value={catOption}>{catOption}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Advanced Options Toggle */}
          {showAdvancedOptions && (
            <>
              <Separator />
              <div className="flex items-center justify-between">
                <Label className="text-sm font-medium">Advanced Options</Label>
                <Switch checked={showAdvanced} onCheckedChange={setShowAdvanced} />
              </div>

              {showAdvanced && (
                <div className="space-y-4">
                  {/* Tags and Time Estimation */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label className="text-sm font-medium">Tags</Label>
                      <Input
                        placeholder="tag1, tag2, tag3..."
                        value={tags}
                        onChange={(e) => setTags(e.target.value)}
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label className="text-sm font-medium">Estimated Time (hours)</Label>
                      <Input
                        type="number"
                        placeholder="2.5"
                        value={estimatedTime || ''}
                        onChange={(e) => setEstimatedTime(Number(e.target.value))}
                        className="mt-1"
                      />
                    </div>
                  </div>

                  {/* Mood and Color */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label className="text-sm font-medium">Mood</Label>
                      <div className="flex gap-2 mt-2 flex-wrap">
                        {moodEmojis.map((emoji) => (
                          <Button
                            key={emoji}
                            variant={mood === emoji ? 'default' : 'outline'}
                            size="sm"
                            onClick={() => setMood(mood === emoji ? '' : emoji)}
                            className="text-lg p-2"
                          >
                            {emoji}
                          </Button>
                        ))}
                      </div>
                    </div>
                    <div>
                      <Label className="text-sm font-medium">Color</Label>
                      <div className="flex gap-2 mt-2 flex-wrap">
                        {colorOptions.map((colorOption) => (
                          <Button
                            key={colorOption}
                            variant="outline"
                            size="sm"
                            onClick={() => setColor(color === colorOption ? '' : colorOption)}
                            className={`w-8 h-8 p-0 rounded-full border-2 ${color === colorOption ? 'ring-2 ring-offset-2 ring-gray-400' : ''}`}
                            style={{ backgroundColor: colorOption }}
                          >
                          </Button>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Recurring and Reminder */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="flex items-center space-x-2">
                      <Switch checked={recurring} onCheckedChange={setRecurring} />
                      <Label className="text-sm font-medium">Recurring Task</Label>
                    </div>
                    <div>
                      <Label className="text-sm font-medium">Reminder Time</Label>
                      <Input
                        type="time"
                        value={reminderTime}
                        onChange={(e) => setReminderTime(e.target.value)}
                        className="mt-1"
                      />
                    </div>
                  </div>

                  {/* Media Attachments */}
                  <div>
                    <Label className="text-sm font-medium">Attachments</Label>
                    <div className="flex gap-2 mt-2">
                      <Button variant="outline" size="sm">
                        <Upload className="w-4 h-4 mr-2" />
                        Files
                      </Button>
                      <Button variant="outline" size="sm">
                        <Camera className="w-4 h-4 mr-2" />
                        Photo
                      </Button>
                      <Button variant="outline" size="sm">
                        <Mic className="w-4 h-4 mr-2" />
                        Audio
                      </Button>
                    </div>
                  </div>
                </div>
              )}
            </>
          )}

          {/* Custom Fields */}
          {customFields.length > 0 && (
            <>
              <Separator />
              <div className="space-y-4">
                <Label className="text-sm font-medium">Additional Information</Label>
                {customFields.map((field) => (
                  <div key={field.name}>
                    <Label className="text-sm font-medium">
                      {field.label}
                      {field.required && <span className="text-red-500 ml-1">*</span>}
                    </Label>
                    {field.type === 'text' && (
                      <Input
                        value={customFieldValues[field.name] || ''}
                        onChange={(e) => setCustomFieldValues(prev => ({ ...prev, [field.name]: e.target.value }))}
                        className="mt-1"
                      />
                    )}
                    {field.type === 'textarea' && (
                      <Textarea
                        value={customFieldValues[field.name] || ''}
                        onChange={(e) => setCustomFieldValues(prev => ({ ...prev, [field.name]: e.target.value }))}
                        className="mt-1"
                        rows={2}
                      />
                    )}
                    {field.type === 'select' && (
                      <Select
                        value={customFieldValues[field.name] || ''}
                        onValueChange={(value) => setCustomFieldValues(prev => ({ ...prev, [field.name]: value }))}
                      >
                        <SelectTrigger className="mt-1">
                          <SelectValue placeholder={`Select ${field.label.toLowerCase()}`} />
                        </SelectTrigger>
                        <SelectContent>
                          {field.options?.map((option) => (
                            <SelectItem key={option} value={option}>{option}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    )}
                    {field.type === 'number' && (
                      <Input
                        type="number"
                        value={customFieldValues[field.name] || ''}
                        onChange={(e) => setCustomFieldValues(prev => ({ ...prev, [field.name]: Number(e.target.value) }))}
                        className="mt-1"
                      />
                    )}
                    {field.type === 'switch' && (
                      <Switch
                        checked={customFieldValues[field.name] || false}
                        onCheckedChange={(checked) => setCustomFieldValues(prev => ({ ...prev, [field.name]: checked }))}
                        className="mt-2"
                      />
                    )}
                  </div>
                ))}
              </div>
            </>
          )}

          {/* Action Buttons */}
          <div className="flex gap-3 justify-end pt-4">
            <Button variant="outline" onClick={() => setIsOpen(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleSubmit} 
              disabled={!title.trim()}
              className={theme.primary}
            >
              <Star className="w-4 h-4 mr-2" />
              Save
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}