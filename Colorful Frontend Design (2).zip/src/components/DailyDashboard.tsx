import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { Progress } from "./ui/progress";
import { Badge } from "./ui/badge";
import { Separator } from "./ui/separator";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "./ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Slider } from "./ui/slider";
import { AddTaskModal, BasicTask } from "./AddTaskModal";
import { 
  Calendar as CalendarIcon, 
  Plus, 
  Minus,
  Droplets, 
  Footprints, 
  Target, 
  CheckCircle, 
  Clock, 
  TrendingUp,
  Star,
  Sparkles,
  Heart,
  Zap,
  Coffee,
  Sunrise,
  Moon,
  Eye,
  Award,
  Activity,
  BarChart3,
  Edit,
  Trash2,
  Settings,
  Save,
  X,
  MoreHorizontal
} from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface DailyTask {
  id: string;
  title: string;
  description?: string;
  completed: boolean;
  priority: 'low' | 'medium' | 'high';
  category: string;
  estimatedTime?: number;
  timeSpent?: number;
}

interface VisionGoal {
  id: string;
  title: string;
  image?: string;
  description: string;
  progress: number;
  category: string;
}

interface CalendarEvent {
  id: string;
  title: string;
  description?: string;
  date: number;
  time?: string;
  color: string;
}

export function DailyDashboard() {
  const [currentDate] = useState(new Date());
  const [waterIntake, setWaterIntake] = useState(6);
  const [waterGoal, setWaterGoal] = useState(8);
  const [steps, setSteps] = useState(7543);
  const [stepsGoal, setStepsGoal] = useState(10000);
  const [selectedDay, setSelectedDay] = useState(currentDate.getDate());
  const [editingTask, setEditingTask] = useState<string | null>(null);
  const [editingGoal, setEditingGoal] = useState<string | null>(null);
  const [showSettings, setShowSettings] = useState(false);
  
  const [dailyTasks, setDailyTasks] = useState<DailyTask[]>([
    {
      id: '1',
      title: 'Complete Leadership Journal 03',
      description: 'Reflect on leadership models and theories',
      completed: false,
      priority: 'high',
      category: 'Academic',
      estimatedTime: 120,
      timeSpent: 45
    },
    {
      id: '2',
      title: 'Review DMAN Exam Materials',
      description: 'Study modules 1-4 for upcoming exam',
      completed: false,
      priority: 'high',
      category: 'Academic',
      estimatedTime: 90
    },
    {
      id: '3',
      title: 'Morning Workout',
      description: '30 min cardio + strength training',
      completed: true,
      priority: 'medium',
      category: 'Health',
      estimatedTime: 30,
      timeSpent: 35
    },
    {
      id: '4',
      title: 'LinkedIn Post - Leadership Insights',
      description: 'Share weekly reflection on public health leadership',
      completed: false,
      priority: 'medium',
      category: 'Professional',
      estimatedTime: 20
    },
    {
      id: '5',
      title: 'Meditation Session',
      description: '15 minutes mindfulness practice',
      completed: true,
      priority: 'low',
      category: 'Wellness',
      estimatedTime: 15,
      timeSpent: 15
    }
  ]);

  const [visionGoals, setVisionGoals] = useState<VisionGoal[]>([
    {
      id: 'v1',
      title: 'MPH Graduate 2025',
      description: 'Complete Master of Public Health with distinction',
      progress: 65,
      category: 'Education'
    },
    {
      id: 'v2',
      title: 'Public Health Leader',
      description: 'Secure leadership role in community health organization',
      progress: 40,
      category: 'Career'
    },
    {
      id: 'v3',
      title: 'Wellness Champion',
      description: 'Maintain optimal physical and mental health',
      progress: 78,
      category: 'Health'
    },
    {
      id: 'v4',
      title: 'Research Impact',
      description: 'Contribute to meaningful public health research',
      progress: 25,
      category: 'Research'
    }
  ]);

  const [calendarEvents, setCalendarEvents] = useState<CalendarEvent[]>([
    {
      id: 'e1',
      title: 'Leadership Class',
      description: 'HPAM7700E Discussion',
      date: 15,
      time: '10:00 AM',
      color: 'bg-purple-500'
    },
    {
      id: 'e2',
      title: 'Study Group',
      description: 'DMAN Exam Prep',
      date: 18,
      time: '2:00 PM',
      color: 'bg-blue-500'
    }
  ]);

  // Generate calendar days for current month
  const generateCalendarDays = () => {
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDayOfWeek = firstDay.getDay();
    
    const days = [];
    
    // Add empty cells for days before the first day of the month
    for (let i = 0; i < startingDayOfWeek; i++) {
      days.push(null);
    }
    
    // Add days of the month
    for (let day = 1; day <= daysInMonth; day++) {
      days.push(day);
    }
    
    return days;
  };

  const toggleTask = (taskId: string) => {
    setDailyTasks(prev => prev.map(task => 
      task.id === taskId ? { ...task, completed: !task.completed } : task
    ));
  };

  const deleteTask = (taskId: string) => {
    setDailyTasks(prev => prev.filter(task => task.id !== taskId));
  };

  const updateTask = (taskId: string, updates: Partial<DailyTask>) => {
    setDailyTasks(prev => prev.map(task => 
      task.id === taskId ? { ...task, ...updates } : task
    ));
  };

  const addWater = () => {
    setWaterIntake(prev => Math.min(prev + 1, waterGoal + 4));
  };

  const removeWater = () => {
    setWaterIntake(prev => Math.max(prev - 1, 0));
  };

  const updateSteps = (newSteps: number) => {
    setSteps(Math.max(0, newSteps));
  };

  const addDailyTask = (task: BasicTask) => {
    const newTask: DailyTask = {
      id: `task-${Date.now()}`,
      title: task.title,
      description: task.description,
      completed: false,
      priority: task.priority || 'medium',
      category: task.category || 'General',
      estimatedTime: task.estimatedTime
    };
    setDailyTasks(prev => [...prev, newTask]);
  };

  const addVisionGoal = () => {
    const newGoal: VisionGoal = {
      id: `vision-${Date.now()}`,
      title: 'New Vision Goal',
      description: 'Describe your vision here...',
      progress: 0,
      category: 'Personal'
    };
    setVisionGoals(prev => [...prev, newGoal]);
  };

  const updateVisionGoal = (goalId: string, updates: Partial<VisionGoal>) => {
    setVisionGoals(prev => prev.map(goal => 
      goal.id === goalId ? { ...goal, ...updates } : goal
    ));
  };

  const deleteVisionGoal = (goalId: string) => {
    setVisionGoals(prev => prev.filter(goal => goal.id !== goalId));
  };

  const addCalendarEvent = () => {
    const newEvent: CalendarEvent = {
      id: `event-${Date.now()}`,
      title: 'New Event',
      description: '',
      date: selectedDay,
      time: '12:00 PM',
      color: 'bg-violet-500'
    };
    setCalendarEvents(prev => [...prev, newEvent]);
  };

  const deleteCalendarEvent = (eventId: string) => {
    setCalendarEvents(prev => prev.filter(event => event.id !== eventId));
  };

  const getEventsForDay = (day: number) => {
    return calendarEvents.filter(event => event.date === day);
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-700 border-red-200';
      case 'medium': return 'bg-yellow-100 text-yellow-700 border-yellow-200';
      case 'low': return 'bg-green-100 text-green-700 border-green-200';
      default: return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category.toLowerCase()) {
      case 'academic': return <Target className="w-4 h-4" />;
      case 'health': return <Heart className="w-4 h-4" />;
      case 'professional': return <Award className="w-4 h-4" />;
      case 'wellness': return <Sparkles className="w-4 h-4" />;
      default: return <CheckCircle className="w-4 h-4" />;
    }
  };

  const completedTasks = dailyTasks.filter(task => task.completed).length;
  const totalTasks = dailyTasks.length;
  const dailyProgress = totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0;

  const monthNames = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];

  const dayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

  const TaskEditDialog = ({ task }: { task: DailyTask }) => {
    const [editedTask, setEditedTask] = useState(task);
    
    return (
      <Dialog open={editingTask === task.id} onOpenChange={() => setEditingTask(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Task</DialogTitle>
            <DialogDescription>
              Update your task details
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium">Title</label>
              <Input
                value={editedTask.title}
                onChange={(e) => setEditedTask(prev => ({ ...prev, title: e.target.value }))}
                placeholder="Task title"
              />
            </div>
            <div>
              <label className="text-sm font-medium">Description</label>
              <Textarea
                value={editedTask.description || ''}
                onChange={(e) => setEditedTask(prev => ({ ...prev, description: e.target.value }))}
                placeholder="Task description"
                rows={3}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium">Priority</label>
                <Select
                  value={editedTask.priority}
                  onValueChange={(value: 'low' | 'medium' | 'high') => 
                    setEditedTask(prev => ({ ...prev, priority: value }))
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-sm font-medium">Category</label>
                <Select
                  value={editedTask.category}
                  onValueChange={(value) => setEditedTask(prev => ({ ...prev, category: value }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Academic">Academic</SelectItem>
                    <SelectItem value="Health">Health</SelectItem>
                    <SelectItem value="Professional">Professional</SelectItem>
                    <SelectItem value="Wellness">Wellness</SelectItem>
                    <SelectItem value="Personal">Personal</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium">Estimated Time (min)</label>
                <Input
                  type="number"
                  value={editedTask.estimatedTime || ''}
                  onChange={(e) => setEditedTask(prev => ({ 
                    ...prev, 
                    estimatedTime: e.target.value ? parseInt(e.target.value) : undefined 
                  }))}
                  placeholder="0"
                />
              </div>
              <div>
                <label className="text-sm font-medium">Time Spent (min)</label>
                <Input
                  type="number"
                  value={editedTask.timeSpent || ''}
                  onChange={(e) => setEditedTask(prev => ({ 
                    ...prev, 
                    timeSpent: e.target.value ? parseInt(e.target.value) : undefined 
                  }))}
                  placeholder="0"
                />
              </div>
            </div>
            <div className="flex gap-2 pt-4">
              <Button
                onClick={() => {
                  updateTask(task.id, editedTask);
                  setEditingTask(null);
                }}
                className="flex-1"
              >
                <Save className="w-4 h-4 mr-2" />
                Save Changes
              </Button>
              <Button
                variant="outline"
                onClick={() => setEditingTask(null)}
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    );
  };

  const VisionGoalEditDialog = ({ goal }: { goal: VisionGoal }) => {
    const [editedGoal, setEditedGoal] = useState(goal);
    
    return (
      <Dialog open={editingGoal === goal.id} onOpenChange={() => setEditingGoal(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Vision Goal</DialogTitle>
            <DialogDescription>
              Update your vision goal details
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium">Title</label>
              <Input
                value={editedGoal.title}
                onChange={(e) => setEditedGoal(prev => ({ ...prev, title: e.target.value }))}
                placeholder="Goal title"
              />
            </div>
            <div>
              <label className="text-sm font-medium">Description</label>
              <Textarea
                value={editedGoal.description}
                onChange={(e) => setEditedGoal(prev => ({ ...prev, description: e.target.value }))}
                placeholder="Goal description"
                rows={3}
              />
            </div>
            <div>
              <label className="text-sm font-medium">Category</label>
              <Select
                value={editedGoal.category}
                onValueChange={(value) => setEditedGoal(prev => ({ ...prev, category: value }))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Education">Education</SelectItem>
                  <SelectItem value="Career">Career</SelectItem>
                  <SelectItem value="Health">Health</SelectItem>
                  <SelectItem value="Research">Research</SelectItem>
                  <SelectItem value="Personal">Personal</SelectItem>
                  <SelectItem value="Financial">Financial</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium">Progress: {editedGoal.progress}%</label>
              <Slider
                value={[editedGoal.progress]}
                onValueChange={(value) => setEditedGoal(prev => ({ ...prev, progress: value[0] }))}
                max={100}
                step={1}
                className="mt-2"
              />
            </div>
            <div className="flex gap-2 pt-4">
              <Button
                onClick={() => {
                  updateVisionGoal(goal.id, editedGoal);
                  setEditingGoal(null);
                }}
                className="flex-1"
              >
                <Save className="w-4 h-4 mr-2" />
                Save Changes
              </Button>
              <Button
                variant="outline"
                onClick={() => setEditingGoal(null)}
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    );
  };

  return (
    <div className="space-y-6 relative">
      {/* Cinematic Background Effects */}
      <div className="fixed inset-0 -z-10 overflow-hidden pointer-events-none">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-50/50 via-pink-50/30 to-blue-50/50 dark:from-purple-950/20 dark:via-pink-950/10 dark:to-blue-950/20 transition-all duration-1000" />
        
        {/* Floating orbs */}
        <div className="absolute top-20 left-10 w-32 h-32 bg-purple-200/20 dark:bg-purple-500/10 rounded-full blur-xl animate-pulse" />
        <div className="absolute top-60 right-20 w-24 h-24 bg-pink-200/20 dark:bg-pink-500/10 rounded-full blur-xl animate-pulse delay-1000" />
        <div className="absolute bottom-40 left-1/4 w-40 h-40 bg-blue-200/20 dark:bg-blue-500/10 rounded-full blur-xl animate-pulse delay-2000" />
        
        {/* Grid pattern */}
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(147,51,234,0.03)_1px,transparent_1px)] dark:bg-[radial-gradient(circle_at_50%_50%,rgba(147,51,234,0.1)_1px,transparent_1px)] bg-[size:20px_20px]" />
      </div>

      {/* Header */}
      <Card className="relative bg-gradient-to-r from-indigo-50/80 via-purple-50/80 to-pink-50/80 dark:from-indigo-950/50 dark:via-purple-950/50 dark:to-pink-950/50 border-purple-200/50 dark:border-purple-700/30 backdrop-blur-sm">
        {/* Gradient border effect */}
        <div className="absolute inset-0 bg-gradient-to-r from-purple-200/30 via-pink-200/30 to-blue-200/30 dark:from-purple-500/20 dark:via-pink-500/20 dark:to-blue-500/20 rounded-lg blur-sm -z-10" />
        
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="relative">
                <Sunrise className="w-8 h-8 text-purple-600 dark:text-purple-400 drop-shadow-lg" />
                <div className="absolute inset-0 w-8 h-8 bg-purple-400/20 dark:bg-purple-500/30 rounded-full blur-md -z-10" />
              </div>
              <div>
                <CardTitle className="text-3xl bg-gradient-to-r from-purple-700 via-pink-600 to-blue-600 dark:from-purple-300 dark:via-pink-300 dark:to-blue-300 bg-clip-text text-transparent">
                  Daily Dashboard
                </CardTitle>
                <p className="text-gray-600 dark:text-gray-300 text-sm mt-1 font-medium">
                  Your personal command center for productivity, wellness, and goal achievement
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Badge className="bg-gradient-to-r from-purple-100 to-pink-100 dark:from-purple-800/50 dark:to-pink-800/50 text-purple-700 dark:text-purple-200 border-purple-200/50 dark:border-purple-600/30 shadow-lg">
                {currentDate.toLocaleDateString('en-US', { 
                  weekday: 'long', 
                  month: 'long', 
                  day: 'numeric' 
                })}
              </Badge>
              <Dialog open={showSettings} onOpenChange={setShowSettings}>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm" className="backdrop-blur-sm bg-white/50 dark:bg-gray-800/50 border-purple-200/50 dark:border-purple-600/30 hover:bg-purple-50 dark:hover:bg-purple-900/30">
                    <Settings className="w-4 h-4" />
                  </Button>
                </DialogTrigger>
                <DialogContent className="bg-white/95 dark:bg-gray-900/95 backdrop-blur-xl border-purple-200/50 dark:border-purple-700/30">
                  <DialogHeader>
                    <DialogTitle className="bg-gradient-to-r from-purple-600 to-pink-600 dark:from-purple-400 dark:to-pink-400 bg-clip-text text-transparent">
                      Dashboard Settings
                    </DialogTitle>
                    <DialogDescription className="text-gray-600 dark:text-gray-300">
                      Customize your dashboard preferences
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <label className="text-sm font-medium text-gray-700 dark:text-gray-200">Daily Water Goal</label>
                      <Input
                        type="number"
                        value={waterGoal}
                        onChange={(e) => setWaterGoal(parseInt(e.target.value) || 8)}
                        min="1"
                        max="20"
                        className="mt-1 bg-white/70 dark:bg-gray-800/70 border-purple-200/50 dark:border-purple-600/30"
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium text-gray-700 dark:text-gray-200">Daily Steps Goal</label>
                      <Input
                        type="number"
                        value={stepsGoal}
                        onChange={(e) => setStepsGoal(parseInt(e.target.value) || 10000)}
                        min="1000"
                        max="50000"
                        step="1000"
                        className="mt-1 bg-white/70 dark:bg-gray-800/70 border-purple-200/50 dark:border-purple-600/30"
                      />
                    </div>
                    <Button 
                      onClick={() => setShowSettings(false)} 
                      className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                    >
                      Save Settings
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Vision Board Section */}
      <Card className="relative bg-gradient-to-br from-blue-50/70 to-indigo-50/70 dark:from-blue-950/30 dark:to-indigo-950/30 border-blue-200/50 dark:border-blue-700/30 backdrop-blur-sm overflow-hidden">
        {/* Cinematic glow effect */}
        <div className="absolute inset-0 bg-gradient-to-r from-blue-200/10 via-indigo-200/10 to-purple-200/10 dark:from-blue-500/5 dark:via-indigo-500/5 dark:to-purple-500/5 rounded-lg blur-xl" />
        
        <CardHeader>
          <div className="flex items-center justify-between relative z-10">
            <CardTitle className="flex items-center gap-3">
              <div className="relative">
                <Eye className="w-6 h-6 text-blue-600 dark:text-blue-400 drop-shadow-md" />
                <div className="absolute inset-0 w-6 h-6 bg-blue-400/20 dark:bg-blue-500/30 rounded-full blur-md -z-10" />
              </div>
              <span className="text-xl bg-gradient-to-r from-blue-700 to-indigo-700 dark:from-blue-300 dark:to-indigo-300 bg-clip-text text-transparent">
                Vision Board - 2025 Goals
              </span>
            </CardTitle>
            <div className="flex items-center gap-3">
              <Badge variant="outline" className="bg-white/60 dark:bg-gray-800/60 border-blue-200/50 dark:border-blue-600/30 backdrop-blur-sm">
                {visionGoals.length} Active Goals
              </Badge>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={addVisionGoal}
                className="bg-white/50 dark:bg-gray-800/50 border-blue-200/50 dark:border-blue-600/30 hover:bg-blue-50 dark:hover:bg-blue-900/30 backdrop-blur-sm"
              >
                <Plus className="w-4 h-4 mr-1" />
                Add Goal
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {visionGoals.map(goal => (
              <Card key={goal.id} className="relative bg-white/80 dark:bg-gray-900/50 hover:bg-white/90 dark:hover:bg-gray-900/70 transition-all duration-300 hover:scale-105 hover:rotate-1 group border-0 shadow-lg hover:shadow-2xl backdrop-blur-sm overflow-hidden">
                {/* Card glow effect */}
                <div className="absolute inset-0 bg-gradient-to-br from-indigo-100/20 via-purple-100/20 to-pink-100/20 dark:from-indigo-500/10 dark:via-purple-500/10 dark:to-pink-500/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                
                <CardContent className="p-5 relative z-10">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Target className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                        <Badge variant="outline" className="text-xs bg-white/70 dark:bg-gray-800/70 border-indigo-200/50 dark:border-indigo-600/30">
                          {goal.category}
                        </Badge>
                      </div>
                      <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setEditingGoal(goal.id)}
                          className="h-7 w-7 p-0 hover:bg-blue-100 dark:hover:bg-blue-900/50"
                        >
                          <Edit className="w-3 h-3" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => deleteVisionGoal(goal.id)}
                          className="h-7 w-7 p-0 text-red-500 hover:text-red-700 hover:bg-red-100 dark:hover:bg-red-900/50"
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                    <h4 className="font-semibold text-sm text-gray-800 dark:text-gray-100">{goal.title}</h4>
                    <p className="text-xs text-gray-600 dark:text-gray-300 line-clamp-2 leading-relaxed">{goal.description}</p>
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-xs text-gray-500 dark:text-gray-400 font-medium">Progress</span>
                        <span className="text-xs font-bold text-indigo-600 dark:text-indigo-400">{goal.progress}%</span>
                      </div>
                      <div className="relative">
                        <Progress value={goal.progress} className="h-2" />
                        <div className="absolute inset-0 bg-gradient-to-r from-indigo-200/20 to-purple-200/20 dark:from-indigo-500/20 dark:to-purple-500/20 rounded-full blur-sm" />
                      </div>
                    </div>
                  </div>
                </CardContent>
                <VisionGoalEditDialog goal={goal} />
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Main Dashboard Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Large Colorful Calendar */}
        <Card className="lg:col-span-7 relative bg-gradient-to-br from-violet-50/70 to-purple-50/70 dark:from-violet-950/30 dark:to-purple-950/30 border-violet-200/50 dark:border-violet-700/30 backdrop-blur-sm overflow-hidden">
          {/* Animated calendar glow */}
          <div className="absolute inset-0 bg-gradient-to-br from-violet-200/10 via-purple-200/10 to-pink-200/10 dark:from-violet-500/5 dark:via-purple-500/5 dark:to-pink-500/5 rounded-lg blur-xl animate-pulse" />
          
          <CardHeader>
            <div className="flex items-center justify-between relative z-10">
              <CardTitle className="flex items-center gap-3">
                <div className="relative">
                  <CalendarIcon className="w-6 h-6 text-violet-600 dark:text-violet-400 drop-shadow-lg" />
                  <div className="absolute inset-0 w-6 h-6 bg-violet-400/30 dark:bg-violet-500/30 rounded-full blur-md -z-10" />
                </div>
                <span className="text-xl bg-gradient-to-r from-violet-700 to-purple-700 dark:from-violet-300 dark:to-purple-300 bg-clip-text text-transparent">
                  {monthNames[currentDate.getMonth()]} {currentDate.getFullYear()}
                </span>
              </CardTitle>
              <div className="flex gap-2">
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={addCalendarEvent}
                  className="bg-white/50 dark:bg-gray-800/50 border-violet-200/50 dark:border-violet-600/30 hover:bg-violet-50 dark:hover:bg-violet-900/30 backdrop-blur-sm shadow-lg"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Add Event
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {/* Day headers */}
              <div className="grid grid-cols-7 gap-2">
                {dayNames.map(day => (
                  <div key={day} className="text-center text-sm font-medium text-gray-600 py-2">
                    {day}
                  </div>
                ))}
              </div>
              
              {/* Calendar grid */}
              <div className="grid grid-cols-7 gap-2">
                {generateCalendarDays().map((day, index) => {
                  const events = day ? getEventsForDay(day) : [];
                  return (
                    <div
                      key={index}
                      className={`
                        aspect-square flex flex-col items-center justify-start p-1 text-sm rounded-lg cursor-pointer transition-all duration-200 relative
                        ${!day ? 'invisible' : ''}
                        ${day === currentDate.getDate() 
                          ? 'bg-violet-600 text-white font-medium shadow-lg' 
                          : day === selectedDay 
                            ? 'bg-violet-100 text-violet-700 font-medium'
                            : 'hover:bg-violet-100 text-gray-700'
                        }
                        ${day && day < currentDate.getDate() ? 'text-gray-400' : ''}
                      `}
                      onClick={() => day && setSelectedDay(day)}
                    >
                      {day}
                      {events.length > 0 && (
                        <div className="flex flex-col gap-1 mt-1 w-full">
                          {events.slice(0, 2).map(event => (
                            <div
                              key={event.id}
                              className={`text-xs p-1 rounded text-white truncate group ${event.color}`}
                              title={event.title}
                            >
                              <div className="flex items-center justify-between">
                                <span className="truncate">{event.title}</span>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    deleteCalendarEvent(event.id);
                                  }}
                                  className="h-3 w-3 p-0 opacity-0 group-hover:opacity-100 text-white hover:bg-white/20"
                                >
                                  <X className="w-2 h-2" />
                                </Button>
                              </div>
                            </div>
                          ))}
                          {events.length > 2 && (
                            <div className="text-xs text-gray-500">+{events.length - 2} more</div>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Right Side Panel */}
        <div className="lg:col-span-5 space-y-6">
          {/* Daily Progress */}
          <Card className="relative bg-gradient-to-br from-green-50/70 to-emerald-50/70 dark:from-green-950/30 dark:to-emerald-950/30 border-green-200/50 dark:border-green-700/30 backdrop-blur-sm overflow-hidden">
            {/* Progress glow effect */}
            <div className="absolute inset-0 bg-gradient-to-br from-green-200/20 via-emerald-200/20 to-teal-200/20 dark:from-green-500/10 dark:via-emerald-500/10 dark:to-teal-500/10 rounded-lg blur-lg animate-pulse" />
            
            <CardHeader>
              <CardTitle className="flex items-center gap-3 text-green-700 dark:text-green-400 relative z-10">
                <div className="relative">
                  <BarChart3 className="w-5 h-5 drop-shadow-md" />
                  <div className="absolute inset-0 w-5 h-5 bg-green-400/30 dark:bg-green-500/30 rounded-full blur-md -z-10" />
                </div>
                <span className="bg-gradient-to-r from-green-700 to-emerald-700 dark:from-green-300 dark:to-emerald-300 bg-clip-text text-transparent">
                  Daily Progress
                </span>
              </CardTitle>
            </CardHeader>
            <CardContent className="relative z-10">
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Tasks Completed</span>
                  <span className="text-xl font-bold text-green-700 dark:text-green-400 drop-shadow-sm">
                    {completedTasks}/{totalTasks}
                  </span>
                </div>
                <div className="relative">
                  <Progress value={dailyProgress} className="h-4 shadow-lg" />
                  <div className="absolute inset-0 bg-gradient-to-r from-green-200/30 to-emerald-200/30 dark:from-green-500/20 dark:to-emerald-500/20 rounded-full blur-sm" />
                </div>
                <div className="text-sm text-gray-600 dark:text-gray-300 text-center font-medium">
                  ✨ {Math.round(dailyProgress)}% of daily goals achieved
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Health Trackers */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Hydration Tracker */}
            <Card className="relative bg-gradient-to-br from-blue-50/70 to-cyan-50/70 dark:from-blue-950/30 dark:to-cyan-950/30 border-blue-200/50 dark:border-blue-700/30 backdrop-blur-sm overflow-hidden">
              {/* Water wave effect */}
              <div className="absolute inset-0 bg-gradient-to-br from-blue-200/20 via-cyan-200/20 to-teal-200/20 dark:from-blue-500/10 dark:via-cyan-500/10 dark:to-teal-500/10 rounded-lg blur-lg animate-pulse" />
              
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-sm text-blue-700 dark:text-blue-400 relative z-10">
                  <div className="relative">
                    <Droplets className="w-4 h-4 drop-shadow-md" />
                    <div className="absolute inset-0 w-4 h-4 bg-blue-400/30 dark:bg-blue-500/30 rounded-full blur-md -z-10" />
                  </div>
                  <span className="bg-gradient-to-r from-blue-700 to-cyan-700 dark:from-blue-300 dark:to-cyan-300 bg-clip-text text-transparent font-semibold">
                    Hydration
                  </span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-xs">Water Intake</span>
                    <span className="text-sm font-bold text-blue-700">
                      {waterIntake}/{waterGoal} glasses
                    </span>
                  </div>
                  
                  {/* Water glasses visualization */}
                  <div className="grid grid-cols-4 gap-1">
                    {Array.from({ length: Math.max(8, waterGoal) }, (_, i) => (
                      <div
                        key={i}
                        className={`w-6 h-8 rounded-sm border-2 transition-all duration-200 ${
                          i < waterIntake 
                            ? 'bg-blue-400 border-blue-500' 
                            : 'bg-blue-50 border-blue-200'
                        }`}
                      />
                    ))}
                  </div>
                  
                  <div className="flex gap-2">
                    <Button 
                      size="sm" 
                      className="flex-1 bg-blue-600 hover:bg-blue-700"
                      onClick={addWater}
                      disabled={waterIntake >= waterGoal + 4}
                    >
                      <Plus className="w-3 h-3 mr-1" />
                      Add
                    </Button>
                    <Button 
                      size="sm" 
                      variant="outline"
                      className="flex-1"
                      onClick={removeWater}
                      disabled={waterIntake <= 0}
                    >
                      <Minus className="w-3 h-3 mr-1" />
                      Remove
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Steps Tracker */}
            <Card className="relative bg-gradient-to-br from-orange-50/70 to-red-50/70 dark:from-orange-950/30 dark:to-red-950/30 border-orange-200/50 dark:border-orange-700/30 backdrop-blur-sm overflow-hidden">
              {/* Walking trail effect */}
              <div className="absolute inset-0 bg-gradient-to-br from-orange-200/20 via-red-200/20 to-pink-200/20 dark:from-orange-500/10 dark:via-red-500/10 dark:to-pink-500/10 rounded-lg blur-lg animate-pulse" />
              
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-sm text-orange-700 dark:text-orange-400 relative z-10">
                  <div className="relative">
                    <Footprints className="w-4 h-4 drop-shadow-md" />
                    <div className="absolute inset-0 w-4 h-4 bg-orange-400/30 dark:bg-orange-500/30 rounded-full blur-md -z-10" />
                  </div>
                  <span className="bg-gradient-to-r from-orange-700 to-red-700 dark:from-orange-300 dark:to-red-300 bg-clip-text text-transparent font-semibold">
                    Steps
                  </span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="text-center">
                    <Input
                      type="number"
                      value={steps}
                      onChange={(e) => updateSteps(parseInt(e.target.value) || 0)}
                      className="text-center text-lg font-bold border-none bg-transparent"
                      min="0"
                    />
                    <div className="text-xs text-gray-600">steps today</div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between text-xs">
                      <span>Goal: {stepsGoal.toLocaleString()}</span>
                      <span>{Math.round((steps / stepsGoal) * 100)}%</span>
                    </div>
                    <Progress value={(steps / stepsGoal) * 100} className="h-2" />
                  </div>
                  
                  <div className="text-xs text-center text-gray-600">
                    {stepsGoal - steps > 0 ? `${(stepsGoal - steps).toLocaleString()} steps to go!` : 'Goal achieved! 🎉'}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Today's Schedule */}
      <Card className="relative bg-gradient-to-br from-pink-50/70 to-rose-50/70 dark:from-pink-950/30 dark:to-rose-950/30 border-pink-200/50 dark:border-pink-700/30 backdrop-blur-sm overflow-hidden">
        {/* Schedule glow effect */}
        <div className="absolute inset-0 bg-gradient-to-br from-pink-200/20 via-rose-200/20 to-red-200/20 dark:from-pink-500/10 dark:via-rose-500/10 dark:to-red-500/10 rounded-lg blur-xl animate-pulse" />
        
        <CardHeader>
          <div className="flex items-center justify-between relative z-10">
            <CardTitle className="flex items-center gap-3">
              <div className="relative">
                <Clock className="w-6 h-6 text-pink-600 dark:text-pink-400 drop-shadow-lg" />
                <div className="absolute inset-0 w-6 h-6 bg-pink-400/30 dark:bg-pink-500/30 rounded-full blur-md -z-10" />
              </div>
              <span className="text-xl bg-gradient-to-r from-pink-700 to-rose-700 dark:from-pink-300 dark:to-rose-300 bg-clip-text text-transparent">
                Today's Schedule
              </span>
              <Badge className="bg-gradient-to-r from-pink-100 to-rose-100 dark:from-pink-800/50 dark:to-rose-800/50 text-pink-700 dark:text-pink-200 border-pink-200/50 dark:border-pink-600/30 shadow-lg backdrop-blur-sm">
                {dailyTasks.length} tasks
              </Badge>
            </CardTitle>
            <AddTaskModal
              onAdd={addDailyTask}
              triggerText="Add Task"
              triggerIcon={<Plus className="w-4 h-4" />}
              modalTitle="Add Daily Task"
              modalDescription="Add a new task to today's schedule"
              defaultType="Task"
              predefinedTypes={["Task", "Meeting", "Study Session", "Exercise", "Personal", "Work"]}
              predefinedCategories={["Academic", "Health", "Professional", "Wellness", "Personal"]}
              colorTheme="pink"
              showAdvancedOptions={true}
            />
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {dailyTasks.map(task => (
              <div key={task.id}>
                <div
                  className={`relative p-5 rounded-xl border transition-all duration-300 hover:shadow-2xl hover:scale-[1.02] group backdrop-blur-sm overflow-hidden ${
                    task.completed 
                      ? 'bg-green-50/80 dark:bg-green-950/30 border-green-200/50 dark:border-green-700/30' 
                      : 'bg-white/80 dark:bg-gray-900/50 border-gray-200/50 dark:border-gray-700/30'
                  }`}
                >
                  {/* Task card glow effect */}
                  <div className={`absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-xl blur-sm ${
                    task.completed 
                      ? 'bg-gradient-to-br from-green-200/20 via-emerald-200/20 to-teal-200/20 dark:from-green-500/10 dark:via-emerald-500/10 dark:to-teal-500/10' 
                      : 'bg-gradient-to-br from-purple-200/20 via-pink-200/20 to-blue-200/20 dark:from-purple-500/10 dark:via-pink-500/10 dark:to-blue-500/10'
                  }`} />
                  <div className="flex items-start gap-3">
                    <div 
                      className={`w-5 h-5 rounded-full border-2 flex items-center justify-center cursor-pointer transition-all duration-200 ${
                        task.completed 
                          ? 'bg-green-600 border-green-600' 
                          : 'border-gray-300 hover:border-pink-400'
                      }`}
                      onClick={() => toggleTask(task.id)}
                    >
                      {task.completed && <CheckCircle className="w-3 h-3 text-white" />}
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-2">
                        <h4 className={`font-medium ${task.completed ? 'line-through text-gray-500' : ''}`}>
                          {task.title}
                        </h4>
                        <Badge className={getPriorityColor(task.priority)} size="sm">
                          {task.priority}
                        </Badge>
                        <div className="flex items-center gap-1 text-xs text-gray-500">
                          {getCategoryIcon(task.category)}
                          {task.category}
                        </div>
                      </div>
                      
                      {task.description && (
                        <p className={`text-sm mb-2 ${task.completed ? 'text-gray-400' : 'text-gray-600'}`}>
                          {task.description}
                        </p>
                      )}
                      
                      <div className="flex items-center gap-4 text-xs text-gray-500">
                        {task.estimatedTime && (
                          <div className="flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            Est: {task.estimatedTime}min
                          </div>
                        )}
                        {task.timeSpent && (
                          <div className="flex items-center gap-1">
                            <Activity className="w-3 h-3" />
                            Spent: {task.timeSpent}min
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setEditingTask(task.id)}
                        className="h-8 w-8 p-0"
                      >
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => deleteTask(task.id)}
                        className="h-8 w-8 p-0 text-red-500 hover:text-red-700"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </div>
                <TaskEditDialog task={task} />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}