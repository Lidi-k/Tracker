import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { Badge } from "./ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "./ui/dialog";
import { Plus, Edit, Trash2, Calendar, Users, BookOpen, Target } from "lucide-react";

interface NetworkingEvent {
  id: string;
  eventName: string;
  date: string;
  peopleMet: string[];
  lessonsLearned: string;
  followUpActions: string[];
  category: string;
}

interface ReadingItem {
  id: string;
  title: string;
  author: string;
  type: string; // book, article, paper
  status: string; // to-read, reading, completed
  keyTakeaways: string;
  relevance: string;
}

export function PersonalGrowth() {
  const [networkingEvents, setNetworkingEvents] = useState<NetworkingEvent[]>([
    {
      id: '1',
      eventName: 'APHA Annual Meeting 2024',
      date: 'November 2024',
      peopleMet: ['Dr. Sarah Johnson - CDC', 'Maria Rodriguez - Local Health Dept', 'James Kim - WHO'],
      lessonsLearned: 'Importance of building relationships early in career. Most opportunities come through personal connections.',
      followUpActions: ['LinkedIn connections sent', 'Coffee meeting scheduled with Dr. Johnson', 'Follow up on WHO internship info'],
      category: 'Professional Conference'
    },
    {
      id: '2',
      eventName: 'UGA MPH Student Mixer',
      date: 'September 2024',
      peopleMet: ['Alex Thompson - Epidemiology', 'Priya Patel - Global Health', 'Michael Chen - Health Policy'],
      lessonsLearned: 'Peer connections are valuable for study groups and future collaborations.',
      followUpActions: ['Study group formed', 'Shared notes and resources', 'Plan to attend SOPHE together'],
      category: 'Student Networking'
    }
  ]);

  const [readingList, setReadingList] = useState<ReadingItem[]>([
    {
      id: '1',
      title: 'The Spirit Catches You and You Fall Down',
      author: 'Anne Fadiman',
      type: 'Book',
      status: 'completed',
      keyTakeaways: 'Cultural competency is essential in public health. Need to understand community perspectives.',
      relevance: 'Critical for working with diverse populations in global health'
    },
    {
      id: '2',
      title: 'Mountains Beyond Mountains',
      author: 'Tracy Kidder',
      type: 'Book',
      status: 'reading',
      keyTakeaways: 'Persistence and advocacy can create systemic change in health equity.',
      relevance: 'Inspiration for career in global health and health equity work'
    },
    {
      id: '3',
      title: 'Social Determinants of Health: The Canadian Facts',
      author: 'Juha Mikkonen & Dennis Raphael',
      type: 'Report',
      status: 'to-read',
      keyTakeaways: '',
      relevance: 'Understanding upstream factors for health disparities research'
    }
  ]);

  const [showEventDialog, setShowEventDialog] = useState(false);
  const [showReadingDialog, setShowReadingDialog] = useState(false);
  const [newEvent, setNewEvent] = useState<Partial<NetworkingEvent>>({});
  const [newReading, setNewReading] = useState<Partial<ReadingItem>>({});

  const addNetworkingEvent = () => {
    if (newEvent.eventName && newEvent.date) {
      const event: NetworkingEvent = {
        id: `event-${Date.now()}`,
        eventName: newEvent.eventName,
        date: newEvent.date,
        peopleMet: newEvent.peopleMet || [],
        lessonsLearned: newEvent.lessonsLearned || '',
        followUpActions: newEvent.followUpActions || [],
        category: newEvent.category || 'Professional'
      };
      setNetworkingEvents(prev => [...prev, event]);
      setNewEvent({});
      setShowEventDialog(false);
    }
  };

  const addReadingItem = () => {
    if (newReading.title && newReading.author) {
      const reading: ReadingItem = {
        id: `reading-${Date.now()}`,
        title: newReading.title,
        author: newReading.author,
        type: newReading.type || 'Book',
        status: newReading.status || 'to-read',
        keyTakeaways: newReading.keyTakeaways || '',
        relevance: newReading.relevance || ''
      };
      setReadingList(prev => [...prev, reading]);
      setNewReading({});
      setShowReadingDialog(false);
    }
  };

  const deleteNetworkingEvent = (id: string) => {
    setNetworkingEvents(prev => prev.filter(event => event.id !== id));
  };

  const deleteReadingItem = (id: string) => {
    setReadingList(prev => prev.filter(item => item.id !== id));
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-700 border-green-200 dark:bg-green-900/30 dark:text-green-300 dark:border-green-700/30';
      case 'reading': return 'bg-blue-100 text-blue-700 border-blue-200 dark:bg-blue-900/30 dark:text-blue-300 dark:border-blue-700/30';
      case 'to-read': return 'bg-gray-100 text-gray-700 border-gray-200 dark:bg-gray-900/30 dark:text-gray-300 dark:border-gray-700/30';
      default: return 'bg-gray-100 text-gray-700 border-gray-200 dark:bg-gray-900/30 dark:text-gray-300 dark:border-gray-700/30';
    }
  };

  return (
    <section className="py-16 px-6 bg-gradient-to-r from-purple-50 via-pink-50 to-indigo-50 dark:from-purple-950/20 dark:via-pink-950/20 dark:to-indigo-950/20 transition-all duration-500">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-3xl font-bold mb-8 text-center bg-gradient-to-r from-purple-600 to-indigo-600 dark:from-purple-400 dark:to-indigo-400 bg-clip-text text-transparent">
          Personal Growth & Learning Log
        </h2>
        
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Networking Events */}
          <div className="space-y-6">
            <Card className="bg-purple-100/80 dark:bg-purple-900/20 border-purple-200/50 dark:border-purple-700/30 backdrop-blur-sm">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2 text-purple-800 dark:text-purple-300">
                    <Users className="w-5 h-5" />
                    Networking & Events
                  </CardTitle>
                  <Dialog open={showEventDialog} onOpenChange={setShowEventDialog}>
                    <DialogTrigger asChild>
                      <Button variant="outline" size="sm" className="bg-white/50 dark:bg-gray-800/50">
                        <Plus className="w-4 h-4 mr-1" />
                        Add Event
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="bg-white/95 dark:bg-gray-900/95 backdrop-blur-xl">
                      <DialogHeader>
                        <DialogTitle>Add Networking Event</DialogTitle>
                        <DialogDescription>
                          Track your networking activities and lessons learned
                        </DialogDescription>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div>
                          <label className="text-sm font-medium">Event Name</label>
                          <Input
                            value={newEvent.eventName || ''}
                            onChange={(e) => setNewEvent(prev => ({ ...prev, eventName: e.target.value }))}
                            placeholder="Conference, meetup, etc."
                          />
                        </div>
                        <div>
                          <label className="text-sm font-medium">Date</label>
                          <Input
                            value={newEvent.date || ''}
                            onChange={(e) => setNewEvent(prev => ({ ...prev, date: e.target.value }))}
                            placeholder="Month Year"
                          />
                        </div>
                        <div>
                          <label className="text-sm font-medium">People Met (comma separated)</label>
                          <Input
                            value={newEvent.peopleMet?.join(', ') || ''}
                            onChange={(e) => setNewEvent(prev => ({ ...prev, peopleMet: e.target.value.split(', ').filter(p => p.trim()) }))}
                            placeholder="Name - Title/Organization"
                          />
                        </div>
                        <div>
                          <label className="text-sm font-medium">Lessons Learned</label>
                          <Textarea
                            value={newEvent.lessonsLearned || ''}
                            onChange={(e) => setNewEvent(prev => ({ ...prev, lessonsLearned: e.target.value }))}
                            placeholder="Key insights and takeaways"
                            rows={3}
                          />
                        </div>
                        <div>
                          <label className="text-sm font-medium">Category</label>
                          <Input
                            value={newEvent.category || ''}
                            onChange={(e) => setNewEvent(prev => ({ ...prev, category: e.target.value }))}
                            placeholder="Professional Conference, Student Event, etc."
                          />
                        </div>
                        <Button onClick={addNetworkingEvent} className="w-full">
                          Add Event
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {networkingEvents.map(event => (
                    <Card key={event.id} className="bg-white/60 dark:bg-gray-800/30 border-purple-200/30 dark:border-purple-700/20 group">
                      <CardContent className="p-4">
                        <div className="space-y-3">
                          <div className="flex items-start justify-between">
                            <div>
                              <h4 className="font-semibold text-purple-700 dark:text-purple-300">{event.eventName}</h4>
                              <p className="text-sm text-gray-600 dark:text-gray-400 flex items-center gap-1">
                                <Calendar className="w-3 h-3" />
                                {event.date}
                              </p>
                              <Badge variant="outline" className="mt-1 text-xs">
                                {event.category}
                              </Badge>
                            </div>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => deleteNetworkingEvent(event.id)}
                              className="opacity-0 group-hover:opacity-100 transition-opacity text-red-500 hover:text-red-700"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                          
                          {event.peopleMet.length > 0 && (
                            <div>
                              <p className="text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">People Met:</p>
                              <div className="flex flex-wrap gap-1">
                                {event.peopleMet.map((person, i) => (
                                  <Badge key={i} variant="outline" className="text-xs">
                                    {person}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                          )}
                          
                          {event.lessonsLearned && (
                            <div>
                              <p className="text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">Lessons Learned:</p>
                              <p className="text-xs text-gray-600 dark:text-gray-400 italic">
                                {event.lessonsLearned}
                              </p>
                            </div>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Reading List */}
          <div className="space-y-6">
            <Card className="bg-indigo-100/80 dark:bg-indigo-900/20 border-indigo-200/50 dark:border-indigo-700/30 backdrop-blur-sm">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2 text-indigo-800 dark:text-indigo-300">
                    <BookOpen className="w-5 h-5" />
                    Reading & Learning
                  </CardTitle>
                  <Dialog open={showReadingDialog} onOpenChange={setShowReadingDialog}>
                    <DialogTrigger asChild>
                      <Button variant="outline" size="sm" className="bg-white/50 dark:bg-gray-800/50">
                        <Plus className="w-4 h-4 mr-1" />
                        Add Reading
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="bg-white/95 dark:bg-gray-900/95 backdrop-blur-xl">
                      <DialogHeader>
                        <DialogTitle>Add Reading Item</DialogTitle>
                        <DialogDescription>
                          Track books, articles, and papers for your professional development
                        </DialogDescription>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div>
                          <label className="text-sm font-medium">Title</label>
                          <Input
                            value={newReading.title || ''}
                            onChange={(e) => setNewReading(prev => ({ ...prev, title: e.target.value }))}
                            placeholder="Book, article, or paper title"
                          />
                        </div>
                        <div>
                          <label className="text-sm font-medium">Author</label>
                          <Input
                            value={newReading.author || ''}
                            onChange={(e) => setNewReading(prev => ({ ...prev, author: e.target.value }))}
                            placeholder="Author name"
                          />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <label className="text-sm font-medium">Type</label>
                            <Input
                              value={newReading.type || ''}
                              onChange={(e) => setNewReading(prev => ({ ...prev, type: e.target.value }))}
                              placeholder="Book, Article, Paper"
                            />
                          </div>
                          <div>
                            <label className="text-sm font-medium">Status</label>
                            <Input
                              value={newReading.status || ''}
                              onChange={(e) => setNewReading(prev => ({ ...prev, status: e.target.value }))}
                              placeholder="to-read, reading, completed"
                            />
                          </div>
                        </div>
                        <div>
                          <label className="text-sm font-medium">Relevance to Career</label>
                          <Textarea
                            value={newReading.relevance || ''}
                            onChange={(e) => setNewReading(prev => ({ ...prev, relevance: e.target.value }))}
                            placeholder="How this relates to your MPH/career goals"
                            rows={2}
                          />
                        </div>
                        <Button onClick={addReadingItem} className="w-full">
                          Add Reading
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {readingList.map(item => (
                    <Card key={item.id} className="bg-white/60 dark:bg-gray-800/30 border-indigo-200/30 dark:border-indigo-700/20 group">
                      <CardContent className="p-4">
                        <div className="space-y-3">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <h4 className="font-semibold text-indigo-700 dark:text-indigo-300">{item.title}</h4>
                              <p className="text-sm text-gray-600 dark:text-gray-400">
                                by {item.author}
                              </p>
                              <div className="flex gap-2 mt-2">
                                <Badge variant="outline" className="text-xs">
                                  {item.type}
                                </Badge>
                                <Badge className={`text-xs ${getStatusColor(item.status)}`}>
                                  {item.status}
                                </Badge>
                              </div>
                            </div>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => deleteReadingItem(item.id)}
                              className="opacity-0 group-hover:opacity-100 transition-opacity text-red-500 hover:text-red-700"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                          
                          {item.relevance && (
                            <div>
                              <p className="text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">Relevance:</p>
                              <p className="text-xs text-gray-600 dark:text-gray-400 italic">
                                {item.relevance}
                              </p>
                            </div>
                          )}
                          
                          {item.keyTakeaways && (
                            <div>
                              <p className="text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">Key Takeaways:</p>
                              <p className="text-xs text-gray-600 dark:text-gray-400">
                                {item.keyTakeaways}
                              </p>
                            </div>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Growth Goals */}
        <div className="mt-8 bg-white/80 dark:bg-gray-900/50 p-6 rounded-xl shadow-lg backdrop-blur-sm border border-gray-200/50 dark:border-gray-700/30">
          <h3 className="font-semibold mb-4 text-gray-800 dark:text-gray-200 text-lg flex items-center gap-2">
            <Target className="w-5 h-5" />
            Personal Development Goals
          </h3>
          <div className="grid md:grid-cols-3 gap-6 text-sm">
            <div>
              <h4 className="font-medium text-purple-600 dark:text-purple-400 mb-2">Professional Skills</h4>
              <ul className="space-y-1 text-gray-600 dark:text-gray-400">
                <li>• Public speaking confidence</li>
                <li>• Grant writing proficiency</li>
                <li>• Data visualization mastery</li>
                <li>• Leadership experience</li>
              </ul>
            </div>
            <div>
              <h4 className="font-medium text-indigo-600 dark:text-indigo-400 mb-2">Personal Growth</h4>
              <ul className="space-y-1 text-gray-600 dark:text-gray-400">
                <li>• Cultural competency development</li>
                <li>• Language skills (Spanish)</li>
                <li>• Global health perspective</li>
                <li>• Work-life integration</li>
              </ul>
            </div>
            <div>
              <h4 className="font-medium text-pink-600 dark:text-pink-400 mb-2">Network Building</h4>
              <ul className="space-y-1 text-gray-600 dark:text-gray-400">
                <li>• Monthly networking events</li>
                <li>• Informational interviews</li>
                <li>• Mentorship relationships</li>
                <li>• Professional organization involvement</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}