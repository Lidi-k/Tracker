export function ProjectsShowcase() {
  const projects = [
    {
      title: "Vaccines for Children (VFC) Program Evaluation",
      date: "Spring 2025",
      course: "Health Program Planning & Evaluation",
      skills: ["Data Collection", "CDC/GA DPH Analysis", "Stakeholder Interviewing"],
      learned: "Program evaluation integrating data & field insights."
    },
    {
      title: "MERS-CoV Surveillance Gap Analysis (Oman)",
      date: "Spring 2025",
      course: "Public Health Surveillance",
      skills: ["Surveillance Evaluation", "Gap Analysis", "Timeliness Assessment"],
      learned: "Importance of early detection in global health security."
    },
    {
      title: "ATL Cares Clinic SWOT & HR Strategy",
      date: "Fall 2024",
      course: "Healthcare Management",
      skills: ["SWOT", "HR", "Culture", "Change Management"],
      learned: "Applied leadership to a community clinic."
    },
    {
      title: "Health Disparities Research Project",
      date: "Fall 2024",
      course: "Epidemiology Methods",
      skills: ["Statistical Analysis", "R Programming", "Data Visualization"],
      learned: "Evidence-based approaches to addressing health inequities."
    }
  ];

  return (
    <section className="py-16 px-6 bg-gradient-to-b from-gray-50 to-white dark:from-gray-900 dark:to-gray-800 transition-all duration-500">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-3xl font-bold mb-8 text-center bg-gradient-to-r from-blue-600 to-purple-600 dark:from-blue-400 dark:to-purple-400 bg-clip-text text-transparent">
          Projects Showcase
        </h2>
        <div className="grid md:grid-cols-2 gap-6">
          {projects.map((project, i) => (
            <div key={i} className="group bg-white/80 dark:bg-gray-900/50 border border-gray-200/50 dark:border-gray-700/30 rounded-xl shadow-lg p-6 backdrop-blur-sm hover:shadow-2xl hover:scale-105 transition-all duration-300">
              <div className="space-y-4">
                <div>
                  <h3 className="text-xl font-semibold text-gray-800 dark:text-gray-100 group-hover:text-purple-600 dark:group-hover:text-purple-400 transition-colors">
                    {project.title}
                  </h3>
                  <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                    {project.date} – {project.course}
                  </p>
                </div>
                
                <div>
                  <p className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    <span className="text-purple-600 dark:text-purple-400">Skills:</span>
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {project.skills.map((skill, idx) => (
                      <span key={idx} className="px-2 py-1 bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-300 text-xs rounded-full border border-purple-200/50 dark:border-purple-700/30">
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>
                
                <div>
                  <p className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    <span className="text-green-600 dark:text-green-400">Key Learning:</span>
                  </p>
                  <p className="text-sm text-gray-600 dark:text-gray-400 italic">
                    {project.learned}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}