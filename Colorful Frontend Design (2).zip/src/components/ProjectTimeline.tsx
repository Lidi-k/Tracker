import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";
import { Checkbox } from "./ui/checkbox";
import { 
  CheckCircle, 
  Circle, 
  AlertTriangle, 
  Calendar, 
  Award,
  FileText,
  Users,
  Shield,
  User
} from "lucide-react";

interface ProjectTask {
  title: string;
  status: string;
  score: number | null;
  completed: boolean;
  type: 'group' | 'individual';
}

interface ProjectCheckpoint {
  id: string;
  category: string;
  due_date: string;
  tasks: ProjectTask[];
}

interface ParticipationTask {
  title: string;
  due_date: string;
  status: string;
  completed: boolean;
}

export function ProjectTimeline() {
  const [checkpoints, setCheckpoints] = useState<ProjectCheckpoint[]>([
    {
      id: "checkpoint1",
      category: "Checkpoint 01",
      due_date: "2025-09-21 23:59",
      tasks: [
        { title: "Rabun County: County Assessment (Module 02)", status: "Not Submitted", score: null, completed: false, type: 'group' },
        { title: "Rabun County: Hazard Vulnerability Analysis (Module 04)", status: "Not Submitted", score: null, completed: false, type: 'group' }
      ]
    },
    {
      id: "checkpoint2", 
      category: "Checkpoint 02",
      due_date: "2025-10-19 23:59",
      tasks: [
        { title: "Rabun County: Communication Hub Framework for Local Emergency Management (Module 06)", status: "Not Submitted", score: null, completed: false, type: 'individual' },
        { title: "Rabun County: County Event Action Plan (Module 07)", status: "Not Submitted", score: null, completed: false, type: 'group' }
      ]
    },
    {
      id: "checkpoint3",
      category: "Checkpoint 03", 
      due_date: "2025-11-23 23:59",
      tasks: [
        { title: "Rabun County: Continuity of Operations Plan (COOP) (Module 10)", status: "Not Submitted", score: null, completed: false, type: 'group' },
        { title: "Rabun County: County Mitigation Proposal (Module 11)", status: "Not Submitted", score: null, completed: false, type: 'group' }
      ]
    }
  ]);

  const [finalProject, setFinalProject] = useState({
    title: "Rabun County: County Emergency Management Final Semester Project",
    due_date: "2025-12-07 23:59",
    status: "Not Submitted",
    score: null,
    completed: false
  });

  const [femaCertificates, setFemaCertificates] = useState([
    { code: "IS-100.C", title: "Introduction to the Incident Command System", due_date: "2025-12-08 00:01", status: "Not Submitted", score: null, completed: false },
    { code: "IS-200.C", title: "Basic Incident Command System for Initial Response", due_date: "2025-12-08 00:01", status: "Not Submitted", score: null, completed: false },
    { code: "IS-700.B", title: "An Introduction to the National Incident Management System", due_date: "2025-12-08 00:01", status: "Not Submitted", score: null, completed: false },
    { code: "IS-800.D", title: "National Response Framework, An Introduction", due_date: "2025-12-08 00:01", status: "Not Submitted", score: null, completed: false }
  ]);

  const [participationTasks, setParticipationTasks] = useState<ParticipationTask[]>([
    { title: "Personal Hazard Vulnerability Analysis (Module 04)", due_date: "2025-09-21 23:59", status: "Not Submitted", completed: false },
    { title: "ESF Individual Work (Module 09)", due_date: "2025-10-29 23:59", status: "Not Submitted", completed: false },
    { title: "ESF Group Work (Module 09)", due_date: "2025-11-02 23:59", status: "Not Submitted", completed: false },
    { title: "Alternative Assignment (08/23)", due_date: "2025-08-30 23:59", status: "Not Submitted", completed: false }
  ]);

  const toggleTaskCompletion = (checkpointId: string, taskIndex: number) => {
    setCheckpoints(prev => prev.map(checkpoint => 
      checkpoint.id === checkpointId 
        ? {
            ...checkpoint,
            tasks: checkpoint.tasks.map((task, index) => 
              index === taskIndex ? { ...task, completed: !task.completed, status: !task.completed ? "Completed" : "Not Submitted" } : task
            )
          }
        : checkpoint
    ));
  };

  const toggleFemaCompletion = (certIndex: number) => {
    setFemaCertificates(prev => prev.map((cert, index) => 
      index === certIndex ? { ...cert, completed: !cert.completed, status: !cert.completed ? "Completed" : "Not Submitted" } : cert
    ));
  };

  const toggleParticipationCompletion = (taskIndex: number) => {
    setParticipationTasks(prev => prev.map((task, index) => 
      index === taskIndex ? { ...task, completed: !task.completed, status: !task.completed ? "Completed" : "Not Submitted" } : task
    ));
  };

  const getDaysUntilDue = (dueDate: string): number => {
    const today = new Date();
    const due = new Date(dueDate);
    const diffTime = due.getTime() - today.getTime();
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  };

  const formatDate = (dateStr: string): string => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', { 
      weekday: 'short',
      month: 'short', 
      day: 'numeric',
      year: 'numeric'
    });
  };

  const getProgressColor = (daysUntil: number, completed: boolean) => {
    if (completed) return 'text-green-600';
    if (daysUntil < 0) return 'text-red-600';
    if (daysUntil <= 7) return 'text-orange-600';
    return 'text-blue-600';
  };

  const getCheckpointProgress = (checkpoint: ProjectCheckpoint) => {
    const completedTasks = checkpoint.tasks.filter(t => t.completed).length;
    return (completedTasks / checkpoint.tasks.length) * 100;
  };

  const overallProgress = () => {
    const totalTasks = checkpoints.reduce((acc, cp) => acc + cp.tasks.length, 0) + (finalProject.completed ? 1 : 0);
    const completedTasks = checkpoints.reduce((acc, cp) => 
      acc + cp.tasks.filter(t => t.completed).length, 0
    ) + (finalProject.completed ? 1 : 0);
    return totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0;
  };

  const completedFema = femaCertificates.filter(cert => cert.completed).length;
  const femaProgress = (completedFema / femaCertificates.length) * 100;

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Completed': return 'bg-green-100 text-green-700 border-green-200';
      case 'Not Submitted': return 'bg-gray-100 text-gray-700 border-gray-200';
      case 'In Progress': return 'bg-blue-100 text-blue-700 border-blue-200';
      default: return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  return (
    <div className="space-y-6">
      {/* Project Overview */}
      <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="w-6 h-6 text-blue-600" />
            DMAN7100E: County Disaster Management Project
          </CardTitle>
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Overall Project Progress</span>
              <span className="text-sm font-medium">{Math.round(overallProgress())}%</span>
            </div>
            <Progress value={overallProgress()} className="h-3" />
          </div>
        </CardHeader>
      </Card>

      {/* Project Checkpoints */}
      <div className="space-y-4">
        {checkpoints.map((checkpoint, index) => {
          const daysUntil = getDaysUntilDue(checkpoint.due_date);
          const progress = getCheckpointProgress(checkpoint);
          const isCompleted = checkpoint.tasks.every(task => task.completed);
          
          return (
            <Card key={checkpoint.id} className="border-l-4 border-l-blue-400">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    {isCompleted ? (
                      <CheckCircle className="w-6 h-6 text-green-600" />
                    ) : (
                      <Circle className="w-6 h-6 text-gray-400" />
                    )}
                    <div>
                      <CardTitle className="text-lg">{checkpoint.category}</CardTitle>
                      <div className="flex items-center gap-4 mt-2">
                        <div className="flex items-center gap-1 text-sm text-gray-600">
                          <Calendar className="w-4 h-4" />
                          {formatDate(checkpoint.due_date)}
                        </div>
                        <div className={`text-sm ${getProgressColor(daysUntil, isCompleted)}`}>
                          {daysUntil >= 0 && !isCompleted && (
                            daysUntil === 0 ? 'Due today' : 
                            daysUntil === 1 ? 'Due tomorrow' : 
                            `${daysUntil} days left`
                          )}
                          {daysUntil < 0 && !isCompleted && `${Math.abs(daysUntil)} days overdue`}
                          {isCompleted && 'Completed'}
                        </div>
                      </div>
                    </div>
                  </div>
                  <Badge variant="outline" className="bg-blue-50 text-blue-700">
                    {checkpoint.category}
                  </Badge>
                </div>
                
                <div className="mt-4">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm text-gray-600">Task Progress</span>
                    <span className="text-sm font-medium">{Math.round(progress)}%</span>
                  </div>
                  <Progress value={progress} className="h-2" />
                </div>
              </CardHeader>
              
              <CardContent>
                <div className="space-y-3">
                  {checkpoint.tasks.map((task, taskIndex) => (
                    <div key={taskIndex} className="p-4 rounded-lg bg-gray-50 border">
                      <div className="flex items-start gap-3">
                        <Checkbox
                          checked={task.completed}
                          onCheckedChange={() => toggleTaskCompletion(checkpoint.id, taskIndex)}
                          className="mt-1"
                        />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-2">
                            {task.type === 'group' ? (
                              <Users className="w-4 h-4 text-blue-500" />
                            ) : (
                              <User className="w-4 h-4 text-green-500" />
                            )}
                            <Badge 
                              variant="secondary" 
                              className={`text-xs ${task.type === 'group' ? 'bg-blue-100 text-blue-700' : 'bg-green-100 text-green-700'}`}
                            >
                              {task.type === 'group' ? 'Group Project' : 'Individual'}
                            </Badge>
                            <Badge className={getStatusColor(task.status)}>
                              {task.status}
                            </Badge>
                          </div>
                          <h4 className={`mb-1 ${task.completed ? 'line-through text-gray-500' : ''}`}>
                            {task.title}
                          </h4>
                          <div className="text-sm text-gray-600">
                            Score: {task.score ? `${task.score}/100` : "- / 100"}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Final Submission */}
      <Card className="border-l-4 border-l-purple-400 bg-gradient-to-r from-purple-50 to-pink-50">
        <CardContent className="p-6">
          <div className="flex items-start gap-3">
            <Checkbox
              checked={finalProject.completed}
              onCheckedChange={() => setFinalProject(prev => ({ ...prev, completed: !prev.completed, status: !prev.completed ? "Completed" : "Not Submitted" }))}
            />
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-2">
                <Award className="w-5 h-5 text-purple-600" />
                <Badge className="bg-purple-200 text-purple-700">Final Project</Badge>
                <Badge className={getStatusColor(finalProject.status)}>
                  {finalProject.status}
                </Badge>
              </div>
              <h3 className={`font-medium text-purple-800 mb-2 ${finalProject.completed ? 'line-through' : ''}`}>
                {finalProject.title}
              </h3>
              <div className="flex items-center gap-4 text-sm text-purple-600">
                <div className="flex items-center gap-1">
                  <Calendar className="w-4 h-4" />
                  Due: {formatDate(finalProject.due_date)}
                </div>
                <div>Score: {finalProject.score ? `${finalProject.score}/100` : "- / 100"}</div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* FEMA Certificates */}
      <Card className="bg-gradient-to-r from-orange-50 to-red-50 border-orange-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="w-6 h-6 text-orange-600" />
            FEMA Professional Development Certificates
          </CardTitle>
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Certification Progress</span>
              <span className="text-sm font-medium">{Math.round(femaProgress)}%</span>
            </div>
            <Progress value={femaProgress} className="h-3" />
            <p className="text-sm text-gray-600">
              All certificates due by {formatDate(femaCertificates[0].due_date)}
            </p>
          </div>
        </CardHeader>
        
        <CardContent>
          <div className="space-y-3">
            {femaCertificates.map((cert, index) => (
              <div key={index} className="flex items-start gap-3 p-3 rounded-lg bg-white/60 border">
                <Checkbox 
                  checked={cert.completed} 
                  onCheckedChange={() => toggleFemaCompletion(index)}
                />
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <Shield className="w-4 h-4 text-orange-500" />
                    <Badge className={getStatusColor(cert.status)}>
                      {cert.status}
                    </Badge>
                  </div>
                  <div className={`font-medium mb-1 ${cert.completed ? 'line-through text-gray-500' : ''}`}>
                    {cert.code}
                  </div>
                  <p className={`text-sm text-gray-600 mb-1 ${cert.completed ? 'line-through' : ''}`}>
                    {cert.title}
                  </p>
                  <div className="text-sm text-gray-500">
                    Score: {cert.score ? `${cert.score}/100` : "- / 100"}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Participation & Practice */}
      <Card className="bg-gradient-to-r from-teal-50 to-cyan-50 border-teal-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="w-6 h-6 text-teal-600" />
            Participation & Practice Assignments
          </CardTitle>
        </CardHeader>
        
        <CardContent>
          <div className="space-y-3">
            {participationTasks.map((task, index) => {
              const daysUntil = getDaysUntilDue(task.due_date);
              
              return (
                <div key={index} className="flex items-start gap-3 p-3 rounded-lg bg-white/60 border">
                  <Checkbox 
                    checked={task.completed} 
                    onCheckedChange={() => toggleParticipationCompletion(index)}
                  />
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <Badge className={getStatusColor(task.status)}>
                        {task.status}
                      </Badge>
                      <div className={`text-sm ${getProgressColor(daysUntil, task.completed)}`}>
                        {daysUntil >= 0 && !task.completed && (
                          daysUntil === 0 ? 'Due today' : 
                          daysUntil === 1 ? 'Due tomorrow' : 
                          `${daysUntil} days left`
                        )}
                        {daysUntil < 0 && !task.completed && `${Math.abs(daysUntil)} days overdue`}
                        {task.completed && 'Completed'}
                      </div>
                    </div>
                    <div className={`font-medium mb-1 ${task.completed ? 'line-through text-gray-500' : ''}`}>
                      {task.title}
                    </div>
                    <div className="flex items-center gap-1 text-sm text-gray-600">
                      <Calendar className="w-4 h-4" />
                      Due: {formatDate(task.due_date)}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}