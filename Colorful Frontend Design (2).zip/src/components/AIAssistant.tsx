import { useState, useRef, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Badge } from "./ui/badge";
import { ScrollArea } from "./ui/scroll-area";
import { 
  MessageCircle, 
  Send, 
  Bot, 
  User, 
  Calendar, 
  CheckCircle,
  Clock,
  BookOpen,
  Target,
  HelpCircle
} from "lucide-react";

interface Message {
  id: string;
  type: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  suggestions?: string[];
}

export function AIAssistant() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      type: 'assistant',
      content: "Hi! I'm your academic assistant. I can help you manage your Fall 2025 goals and assignments. Try asking me things like:",
      timestamp: new Date(),
      suggestions: [
        "What's due this week?",
        "Mark Case Study 02 as complete",
        "How many FEMA certificates are left?",
        "Add study session for Exam 02",
        "Show me my academic progress"
      ]
    }
  ]);
  const [inputMessage, setInputMessage] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const processNaturalLanguage = (input: string): string => {
    const lowerInput = input.toLowerCase();
    
    // Check for completion requests
    if (lowerInput.includes('mark') && lowerInput.includes('complete')) {
      return "✅ I've marked that assignment as complete! Your progress has been updated automatically.";
    }
    
    // Check for due date queries
    if (lowerInput.includes('due this week') || lowerInput.includes("what's due")) {
      return "📅 **This week's assignments:**\n\n• Journal 02 (HPAM7700E) - Due Sep 14\n• Exam 01 (DMAN7100E) - Due Sep 17\n• Multiple Rabun County project components - Due Sep 21\n\nWould you like me to create study reminders for any of these?";
    }
    
    // Check for FEMA certificate queries
    if (lowerInput.includes('fema') && (lowerInput.includes('left') || lowerInput.includes('remaining'))) {
      return "🛡️ **FEMA Certificates Remaining:** 4 out of 4\n\n• IS-100.C: Intro to ICS\n• IS-200.C: Basic ICS for Initial Response\n• IS-700.B: Intro to NIMS  \n• IS-800.D: National Response Framework\n\nAll due December 8th. I can help you create a study schedule!";
    }
    
    // Check for HPAM course queries
    if (lowerInput.includes('hpam') || lowerInput.includes('leadership')) {
      return "👔 **HPAM7700E Leadership Course Status:**\n\n• Journal 01: ✅ Completed (100/100)\n• Journal 02: Due Sep 14 (Emotional Intelligence)\n• Case Study 01: Due Sep 7 (Systems Thinking)\n• Peer Feedback 01: ✅ Submitted\n\n**Upcoming Focus:** Leadership models & theories for Journal 03. Great start with that perfect score! 🌟";
    }
    
    // Check for progress queries
    if (lowerInput.includes('progress') || lowerInput.includes('how am i doing')) {
      return "📊 **Your Academic Progress:**\n\n• Overall goal completion: 39%\n• Health goals: 100% complete! 🎉\n• HPAM7700E: 2/14 assignments complete (Journal 01: 100%!)\n• DMAN7100E: Project checkpoints upcoming\n• Total assignments: 33 across both courses\n\nYou're crushing your health goals and off to a great start academically! 🚀";
    }
    
    // Check for notebook queries
    if (lowerInput.includes('notebook') || lowerInput.includes('notes')) {
      return "📝 **Notebook Features:**\n\n• Capture study insights and reflections\n• Tag notes by course (HPAM7700E, DMAN7100E)\n• AI analysis for deeper insights\n• Search and filter your academic thoughts\n\nTry creating notes for your upcoming assignments - the AI can help connect concepts across your courses!";
    }
    
    // Check for study session requests
    if (lowerInput.includes('study') && (lowerInput.includes('add') || lowerInput.includes('schedule'))) {
      return "📚 I'd love to help you schedule study sessions! However, I need calendar integration to set up specific times. For now, I recommend:\n\n• Block 2-3 hours for Exam 01 prep\n• Review Modules 1-4 for DMAN7100E\n• Practice with MCQs and short answers\n\nWould you like me to remind you about this later?";
    }
    
    // Check for help with concepts
    if (lowerInput.includes('hva') || lowerInput.includes('hazard vulnerability')) {
      return "🔍 **Hazard Vulnerability Analysis (HVA)** is a systematic process to:\n\n• Identify potential hazards in your county\n• Assess the risk and impact of each hazard\n• Prioritize preparedness and mitigation efforts\n\nFor your Rabun County project, you'll need to analyze 5 natural hazards, 3 technological hazards, and 2 terrorism threats. Need help brainstorming specific hazards?";
    }
    
    // Check for rescheduling requests
    if (lowerInput.includes('reschedule') || lowerInput.includes('postpone')) {
      return "📅 I understand you need to reschedule something. While I can't directly modify your calendar, I can help you prioritize:\n\n• What specifically needs to be rescheduled?\n• What's your new target date?\n• Should I adjust your study plan accordingly?\n\nLet me know the details and I'll help you reorganize!";
    }
    
    // Generic helpful response
    return "🤖 I'm here to help with your Fall 2025 goals and academic tasks! I can:\n\n• Track assignment due dates\n• Update completion status\n• Explain course concepts\n• Suggest study schedules\n• Provide progress updates\n\nTry asking me about specific assignments, due dates, or concepts you're studying!";
  };

  const handleSendMessage = () => {
    if (!inputMessage.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: inputMessage,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputMessage("");
    setIsTyping(true);

    // Simulate AI processing time
    setTimeout(() => {
      const assistantResponse: Message = {
        id: (Date.now() + 1).toString(),
        type: 'assistant',
        content: processNaturalLanguage(inputMessage),
        timestamp: new Date()
      };

      setMessages(prev => [...prev, assistantResponse]);
      setIsTyping(false);
    }, 1500);
  };

  const handleSuggestionClick = (suggestion: string) => {
    setInputMessage(suggestion);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <Card className="h-[600px] flex flex-col bg-gradient-to-br from-indigo-50 to-purple-50 border-indigo-200">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2">
          <Bot className="w-6 h-6 text-indigo-600" />
          AI Academic Assistant
          <Badge className="bg-indigo-100 text-indigo-700 ml-auto">Beta</Badge>
        </CardTitle>
        <p className="text-sm text-gray-600">
          Natural language interface for managing your goals and assignments
        </p>
      </CardHeader>
      
      <CardContent className="flex-1 flex flex-col p-4 gap-4">
        <ScrollArea className="flex-1">
          <div className="space-y-4 pr-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex gap-3 ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                {message.type === 'assistant' && (
                  <div className="w-8 h-8 rounded-full bg-indigo-200 flex items-center justify-center flex-shrink-0">
                    <Bot className="w-4 h-4 text-indigo-600" />
                  </div>
                )}
                
                <div className={`max-w-[80%] rounded-lg p-3 ${
                  message.type === 'user' 
                    ? 'bg-indigo-600 text-white' 
                    : 'bg-white border shadow-sm'
                }`}>
                  <div className="whitespace-pre-wrap text-sm">
                    {message.content}
                  </div>
                  
                  {message.suggestions && (
                    <div className="mt-3 flex flex-wrap gap-2">
                      {message.suggestions.map((suggestion, index) => (
                        <Button
                          key={index}
                          variant="outline"
                          size="sm"
                          onClick={() => handleSuggestionClick(suggestion)}
                          className="text-xs h-7 bg-gray-50 hover:bg-gray-100"
                        >
                          {suggestion}
                        </Button>
                      ))}
                    </div>
                  )}
                  
                  <div className="text-xs opacity-60 mt-2">
                    {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </div>
                </div>
                
                {message.type === 'user' && (
                  <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center flex-shrink-0">
                    <User className="w-4 h-4 text-gray-600" />
                  </div>
                )}
              </div>
            ))}
            
            {isTyping && (
              <div className="flex gap-3 justify-start">
                <div className="w-8 h-8 rounded-full bg-indigo-200 flex items-center justify-center flex-shrink-0">
                  <Bot className="w-4 h-4 text-indigo-600" />
                </div>
                <div className="bg-white border shadow-sm rounded-lg p-3">
                  <div className="flex space-x-1">
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
        </ScrollArea>
        
        <div className="flex gap-2">
          <Input
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Ask me about your goals, assignments, or deadlines..."
            className="flex-1"
          />
          <Button 
            onClick={handleSendMessage} 
            disabled={!inputMessage.trim() || isTyping}
            className="bg-indigo-600 hover:bg-indigo-700"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
        
        <div className="text-xs text-gray-500 text-center">
          💡 Try: "What's due this week?" or "Mark Journal 02 as complete"
        </div>
      </CardContent>
    </Card>
  );
}