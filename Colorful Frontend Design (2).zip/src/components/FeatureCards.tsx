import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export function FeatureCards() {
  const features = [
    {
      title: "Gentle Design",
      description: "Soft, calming designs that create a peaceful and elegant user experience",
      gradient: "from-pink-200 to-rose-200",
      bgGradient: "from-pink-50 to-rose-50",
      badge: "Design",
      badgeColor: "bg-pink-200 text-pink-700",
      image: "https://images.unsplash.com/photo-1646038572816-04ab3ff22b1f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2xvcmZ1bCUyMGFic3RyYWN0JTIwZ3JhZGllbnR8ZW58MXx8fHwxNzU3NTg2OTM4fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
    },
    {
      title: "Smooth Interactions",
      description: "Delicate components that respond gracefully with subtle, refined animations",
      gradient: "from-blue-200 to-cyan-200",
      bgGradient: "from-blue-50 to-cyan-50",
      badge: "Interactive",
      badgeColor: "bg-blue-200 text-blue-700",
      image: "https://images.unsplash.com/photo-1652212976547-16d7e2841b8c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2aWJyYW50JTIwdGVjaG5vbG9neXxlbnwxfHx8fDE3NTc2MzA2MzN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
    },
    {
      title: "Serene Aesthetics",
      description: "Minimalist, tranquil designs that embrace modern simplicity and grace",
      gradient: "from-green-200 to-emerald-200",
      bgGradient: "from-green-50 to-emerald-50",
      badge: "Modern",
      badgeColor: "bg-green-200 text-green-700",
      image: "https://images.unsplash.com/photo-1745077299971-98ac7fb78d63?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2xvcmZ1bCUyMGRlc2lnbiUyMHdvcmtzcGFjZXxlbnwxfHx8fDE3NTc2MzA2MzV8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
    }
  ];

  return (
    <section className="py-20 px-6 bg-gradient-to-b from-gray-50 to-white">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl mb-4 bg-gradient-to-r from-purple-300 to-pink-300 bg-clip-text text-transparent">
            Gentle Features
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Discover what makes our pastel frontend so soothing and elegant
          </p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <Card 
              key={index} 
              className={`group hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2 bg-gradient-to-br ${feature.bgGradient} border-0 overflow-hidden`}
            >
              <CardHeader className="pb-4">
                <div className="relative h-48 mb-4 rounded-lg overflow-hidden">
                  <ImageWithFallback
                    src={feature.image}
                    alt={feature.title}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className={`absolute inset-0 bg-gradient-to-t ${feature.gradient} opacity-70`}></div>
                </div>
                <Badge className={`${feature.badgeColor} w-fit`}>
                  {feature.badge}
                </Badge>
                <CardTitle className="text-xl">{feature.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-gray-600">
                  {feature.description}
                </CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}