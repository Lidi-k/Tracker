export function HealthAndPersonal() {
  const dailyWellness = [
    "Meal prep with balanced proteins & vegetables",
    "Hydration goal: 2-3 liters per day",
    "Morning skincare routine",
    "30 minutes of physical activity",
    "8 hours of quality sleep",
    "Mindfulness/meditation practice"
  ];

  const growthHabits = [
    "Daily journaling and reflection",
    "Reading list - academic & personal development", 
    "Financial planning: credit score improvement",
    "Savings goal until January 2026",
    "Language learning (Spanish for global health)",
    "Professional networking activities"
  ];

  const fitnessGoals = [
    { activity: "Cardio", frequency: "4x/week", duration: "30 min" },
    { activity: "Strength Training", frequency: "3x/week", duration: "45 min" },
    { activity: "Yoga/Stretching", frequency: "Daily", duration: "15 min" },
    { activity: "Walking/Hiking", frequency: "Weekend", duration: "60+ min" }
  ];

  const nutritionPlan = [
    "Breakfast: Protein + whole grains + fruit",
    "Lunch: Lean protein + vegetables + complex carbs",
    "Dinner: Light protein + vegetables",
    "Snacks: Nuts, fruits, Greek yogurt",
    "Meal prep on Sundays",
    "Limit processed foods and added sugars"
  ];

  return (
    <section className="py-16 px-6 bg-gradient-to-r from-pink-50 via-yellow-50 to-green-50 dark:from-pink-950/20 dark:via-yellow-950/20 dark:to-green-950/20 transition-all duration-500">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-3xl font-bold mb-8 text-center bg-gradient-to-r from-pink-600 via-yellow-600 to-green-600 dark:from-pink-400 dark:via-yellow-400 dark:to-green-400 bg-clip-text text-transparent">
          Health & Personal Wellness
        </h2>
        
        <div className="grid md:grid-cols-2 gap-8 mb-8">
          <div className="bg-pink-100/80 dark:bg-pink-900/20 p-6 rounded-xl shadow-lg backdrop-blur-sm border border-pink-200/50 dark:border-pink-700/30">
            <h3 className="font-semibold mb-4 text-pink-800 dark:text-pink-300 text-lg">Daily Wellness Routine</h3>
            <ul className="space-y-3 text-sm">
              {dailyWellness.map((item, i) => (
                <li key={i} className="flex items-start gap-2 text-gray-700 dark:text-gray-300">
                  <span className="w-1.5 h-1.5 bg-pink-500 rounded-full mt-2 flex-shrink-0"></span>
                  {item}
                </li>
              ))}
            </ul>
          </div>
          
          <div className="bg-yellow-100/80 dark:bg-yellow-900/20 p-6 rounded-xl shadow-lg backdrop-blur-sm border border-yellow-200/50 dark:border-yellow-700/30">
            <h3 className="font-semibold mb-4 text-yellow-800 dark:text-yellow-300 text-lg">Personal Growth Habits</h3>
            <ul className="space-y-3 text-sm">
              {growthHabits.map((habit, i) => (
                <li key={i} className="flex items-start gap-2 text-gray-700 dark:text-gray-300">
                  <span className="w-1.5 h-1.5 bg-yellow-500 rounded-full mt-2 flex-shrink-0"></span>
                  {habit}
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          <div className="bg-green-100/80 dark:bg-green-900/20 p-6 rounded-xl shadow-lg backdrop-blur-sm border border-green-200/50 dark:border-green-700/30">
            <h3 className="font-semibold mb-4 text-green-800 dark:text-green-300 text-lg">Fitness Goals</h3>
            <div className="space-y-4">
              {fitnessGoals.map((goal, i) => (
                <div key={i} className="bg-white/60 dark:bg-gray-800/30 p-3 rounded-lg border border-green-200/30 dark:border-green-700/20">
                  <div className="flex justify-between items-center">
                    <span className="font-medium text-green-700 dark:text-green-300">{goal.activity}</span>
                    <span className="text-xs bg-green-200 dark:bg-green-800 text-green-800 dark:text-green-200 px-2 py-1 rounded-full">
                      {goal.duration}
                    </span>
                  </div>
                  <div className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                    {goal.frequency}
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          <div className="bg-blue-100/80 dark:bg-blue-900/20 p-6 rounded-xl shadow-lg backdrop-blur-sm border border-blue-200/50 dark:border-blue-700/30">
            <h3 className="font-semibold mb-4 text-blue-800 dark:text-blue-300 text-lg">Nutrition Plan</h3>
            <ul className="space-y-3 text-sm">
              {nutritionPlan.map((item, i) => (
                <li key={i} className="flex items-start gap-2 text-gray-700 dark:text-gray-300">
                  <span className="w-1.5 h-1.5 bg-blue-500 rounded-full mt-2 flex-shrink-0"></span>
                  {item}
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="mt-8 bg-white/80 dark:bg-gray-900/50 p-6 rounded-xl shadow-lg backdrop-blur-sm border border-gray-200/50 dark:border-gray-700/30">
          <h3 className="font-semibold mb-4 text-gray-800 dark:text-gray-200 text-lg">Wellness Tracking & Goals</h3>
          <div className="grid md:grid-cols-3 gap-6 text-sm">
            <div>
              <h4 className="font-medium text-purple-600 dark:text-purple-400 mb-2">Mental Health</h4>
              <ul className="space-y-1 text-gray-600 dark:text-gray-400">
                <li>• Stress management techniques</li>
                <li>• Work-life balance strategies</li>
                <li>• Social connection maintenance</li>
                <li>• Regular mental health check-ins</li>
              </ul>
            </div>
            <div>
              <h4 className="font-medium text-orange-600 dark:text-orange-400 mb-2">Physical Health</h4>
              <ul className="space-y-1 text-gray-600 dark:text-gray-400">
                <li>• Annual health screenings</li>
                <li>• Preventive care appointments</li>
                <li>• Sleep quality optimization</li>
                <li>• Movement throughout the day</li>
              </ul>
            </div>
            <div>
              <h4 className="font-medium text-teal-600 dark:text-teal-400 mb-2">Financial Wellness</h4>
              <ul className="space-y-1 text-gray-600 dark:text-gray-400">
                <li>• Monthly budget tracking</li>
                <li>• Emergency fund building</li>
                <li>• Credit score monitoring</li>
                <li>• Post-graduation financial plan</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}