import { Moon, Sun, Palette } from "lucide-react";
import { Button } from "./ui/button";
import { usePlanner } from "../contexts/PlannerContext";

interface DarkModeToggleProps {
  onToggle?: (isDark: boolean) => void;
}

export function DarkModeToggle({ onToggle }: DarkModeToggleProps) {
  const { theme, toggleTheme } = usePlanner();
  const isDark = theme === 'dark';

  const handleToggle = () => {
    toggleTheme();
    onToggle?.(theme === 'light'); // Will be opposite after toggle
  };

  return (
    <Button
      variant="outline"
      size="sm"
      onClick={handleToggle}
      className={`
        relative overflow-hidden transition-all duration-500 group
        ${isDark 
          ? 'bg-gradient-to-r from-purple-900/20 to-pink-900/20 border-purple-400/30 text-purple-200 hover:border-purple-300' 
          : 'bg-gradient-to-r from-purple-100 to-pink-100 border-purple-200 text-purple-700 hover:border-purple-300'
        }
      `}
    >
      <div className="flex items-center gap-2">
        <div className="relative">
          <Sun className={`w-4 h-4 transition-all duration-300 ${isDark ? 'rotate-90 scale-0' : 'rotate-0 scale-100'}`} />
          <Moon className={`w-4 h-4 absolute inset-0 transition-all duration-300 ${isDark ? 'rotate-0 scale-100' : '-rotate-90 scale-0'}`} />
        </div>
        <span className="text-xs font-medium">
          {isDark ? 'Dark' : 'Light'}
        </span>
        <Palette className="w-3 h-3 opacity-60 group-hover:opacity-100 transition-opacity" />
      </div>
      
      {/* Animated background */}
      <div className={`
        absolute inset-0 transition-all duration-500 opacity-0 group-hover:opacity-100
        ${isDark 
          ? 'bg-gradient-to-r from-purple-800/10 to-pink-800/10' 
          : 'bg-gradient-to-r from-purple-200/50 to-pink-200/50'
        }
      `} />
    </Button>
  );
}