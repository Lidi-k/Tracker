import { Button } from "./ui/button";

export function ColorfulFooter() {
  return (
    <footer className="relative overflow-hidden">
      {/* Gradient Background */}
      <div className="absolute inset-0 bg-gradient-to-r from-purple-200 via-blue-200 to-teal-200"></div>
      
      {/* Floating Elements */}
      <div className="absolute top-10 left-10 w-20 h-20 bg-gradient-to-r from-pink-200 to-rose-200 rounded-full opacity-30 blur-xl"></div>
      <div className="absolute bottom-10 right-10 w-24 h-24 bg-gradient-to-r from-yellow-200 to-orange-200 rounded-full opacity-30 blur-xl"></div>
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-32 h-32 bg-gradient-to-r from-green-200 to-blue-200 rounded-full opacity-20 blur-2xl"></div>
      
      <div className="relative z-10 py-16 px-6">
        <div className="max-w-4xl mx-auto text-center text-gray-700">
          <h3 className="text-3xl md:text-4xl mb-4">
            Ready to Embrace Serenity?
          </h3>
          <p className="text-xl mb-8 text-gray-600 max-w-2xl mx-auto">
            Join thousands of designers and developers who are already creating beautiful, peaceful experiences
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Button className="bg-white text-purple-600 hover:bg-purple-50 border border-purple-200 px-8 py-3 text-lg transition-all duration-300 transform hover:scale-105">
              Get Started Now
            </Button>
            <Button 
              variant="outline" 
              className="border-purple-300 text-purple-600 hover:bg-purple-50 px-8 py-3 text-lg transition-all duration-300 transform hover:scale-105"
            >
              View Documentation
            </Button>
          </div>
          
          {/* Color Bars */}
          <div className="flex justify-center gap-2 mb-8">
            <div className="w-16 h-2 bg-gradient-to-r from-red-200 to-pink-200 rounded-full"></div>
            <div className="w-16 h-2 bg-gradient-to-r from-orange-200 to-yellow-200 rounded-full"></div>
            <div className="w-16 h-2 bg-gradient-to-r from-green-200 to-teal-200 rounded-full"></div>
            <div className="w-16 h-2 bg-gradient-to-r from-blue-200 to-purple-200 rounded-full"></div>
            <div className="w-16 h-2 bg-gradient-to-r from-purple-200 to-pink-200 rounded-full"></div>
          </div>
          
          <div className="flex justify-center gap-6 text-sm text-gray-500">
            <a href="#" className="hover:text-gray-700 transition-colors">Privacy</a>
            <a href="#" className="hover:text-gray-700 transition-colors">Terms</a>
            <a href="#" className="hover:text-gray-700 transition-colors">Support</a>
            <a href="#" className="hover:text-gray-700 transition-colors">Contact</a>
          </div>
          
          <div className="mt-8 pt-8 border-t border-gray-300/50 text-gray-500">
            <p>&copy; 2025 Pastel Frontend. Made with 🤍 and gentle colors.</p>
          </div>
        </div>
      </div>
    </footer>
  );
}