export function ProfessionalDevelopment() {
  const elevatorPitch = `I'm an MPH student specializing in health informatics & surveillance, 
    passionate about using data to address disparities and improve global health systems. 
    My experience spans program evaluation, epidemiological analysis, and health policy research.`;

  const behavioralQuestions = [
    {
      question: "Tell me about a time you worked on a team project.",
      example: "VFC Program Evaluation - collaborated with CDC and GA DPH stakeholders"
    },
    {
      question: "How do you handle data challenges under tight deadlines?",
      example: "MERS-CoV surveillance analysis - prioritized key metrics and automated workflows"
    },
    {
      question: "Describe a time you had to adapt to unexpected changes.",
      example: "ATL Cares project pivot - shifted from operational to strategic HR focus"
    },
    {
      question: "Give an example of when you improved a process or system.",
      example: "Streamlined data collection protocols for surveillance gap analysis"
    }
  ];

  const careerGoals = [
    "Public Health Informatics Specialist",
    "Epidemiologist (State/Federal Level)",
    "Global Health Program Manager",
    "Health Policy Analyst",
    "Research Scientist (Academic/NGO)"
  ];

  return (
    <section className="py-16 px-6 bg-gradient-to-r from-green-50 via-teal-50 to-blue-50 dark:from-green-950/20 dark:via-teal-950/20 dark:to-blue-950/20 transition-all duration-500">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-3xl font-bold mb-8 text-center bg-gradient-to-r from-green-600 to-blue-600 dark:from-green-400 dark:to-blue-400 bg-clip-text text-transparent">
          Professional Development
        </h2>
        
        <div className="grid md:grid-cols-2 gap-8 mb-8">
          <div className="bg-green-100/80 dark:bg-green-900/20 p-6 rounded-xl shadow-lg backdrop-blur-sm border border-green-200/50 dark:border-green-700/30">
            <h3 className="font-semibold mb-4 text-green-800 dark:text-green-300 text-lg">Elevator Pitch</h3>
            <div className="bg-white/60 dark:bg-gray-800/30 p-4 rounded-lg border border-green-200/30 dark:border-green-700/20">
              <p className="text-sm text-gray-700 dark:text-gray-300 italic leading-relaxed">
                "{elevatorPitch}"
              </p>
            </div>
          </div>
          
          <div className="bg-teal-100/80 dark:bg-teal-900/20 p-6 rounded-xl shadow-lg backdrop-blur-sm border border-teal-200/50 dark:border-teal-700/30">
            <h3 className="font-semibold mb-4 text-teal-800 dark:text-teal-300 text-lg">Career Aspirations</h3>
            <ul className="space-y-3 text-sm">
              {careerGoals.map((goal, i) => (
                <li key={i} className="flex items-center gap-2 text-gray-700 dark:text-gray-300">
                  <span className="w-1.5 h-1.5 bg-teal-500 rounded-full"></span>
                  {goal}
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="bg-blue-100/80 dark:bg-blue-900/20 p-6 rounded-xl shadow-lg backdrop-blur-sm border border-blue-200/50 dark:border-blue-700/30">
          <h3 className="font-semibold mb-6 text-blue-800 dark:text-blue-300 text-lg">Behavioral Interview Preparation</h3>
          <div className="grid gap-6">
            {behavioralQuestions.map((item, i) => (
              <div key={i} className="bg-white/60 dark:bg-gray-800/30 p-4 rounded-lg border border-blue-200/30 dark:border-blue-700/20">
                <h4 className="font-medium text-blue-700 dark:text-blue-300 mb-2">
                  {item.question}
                </h4>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  <span className="font-medium text-green-600 dark:text-green-400">Example:</span> {item.example}
                </p>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-8 grid md:grid-cols-3 gap-6">
          <div className="bg-purple-100/80 dark:bg-purple-900/20 p-6 rounded-xl shadow-lg backdrop-blur-sm border border-purple-200/50 dark:border-purple-700/30">
            <h3 className="font-semibold mb-3 text-purple-800 dark:text-purple-300">Key Strengths</h3>
            <ul className="text-sm space-y-2 text-gray-700 dark:text-gray-300">
              <li>• Data analysis & visualization</li>
              <li>• Cross-cultural communication</li>
              <li>• Project management</li>
              <li>• Systems thinking</li>
            </ul>
          </div>
          
          <div className="bg-orange-100/80 dark:bg-orange-900/20 p-6 rounded-xl shadow-lg backdrop-blur-sm border border-orange-200/50 dark:border-orange-700/30">
            <h3 className="font-semibold mb-3 text-orange-800 dark:text-orange-300">Growth Areas</h3>
            <ul className="text-sm space-y-2 text-gray-700 dark:text-gray-300">
              <li>• Public speaking confidence</li>
              <li>• Grant writing experience</li>
              <li>• Leadership opportunities</li>
              <li>• Technical certifications</li>
            </ul>
          </div>
          
          <div className="bg-pink-100/80 dark:bg-pink-900/20 p-6 rounded-xl shadow-lg backdrop-blur-sm border border-pink-200/50 dark:border-pink-700/30">
            <h3 className="font-semibold mb-3 text-pink-800 dark:text-pink-300">Action Items</h3>
            <ul className="text-sm space-y-2 text-gray-700 dark:text-gray-300">
              <li>• Complete LinkedIn profile</li>
              <li>• Practice elevator pitch</li>
              <li>• Schedule informational interviews</li>
              <li>• Update portfolio regularly</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}