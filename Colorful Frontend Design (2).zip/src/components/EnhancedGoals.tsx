import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Progress } from "./ui/progress";
import { Checkbox } from "./ui/checkbox";
import { Badge } from "./ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "./ui/dialog";
import { Textarea } from "./ui/textarea";
import { Input } from "./ui/input";
import { AddTaskModal, BasicTask } from "./AddTaskModal";
import { 
  Target, 
  Calendar, 
  Plus, 
  CheckCircle,
  Clock,
  Repeat,
  Edit,
  Trash2,
  Zap
} from "lucide-react";

interface OneTimeTask {
  id: string;
  text: string;
  done: boolean;
  details?: string;
}

interface RepeatableTask {
  id: string;
  text: string;
  frequency: string;
  progress: number;
  total: number;
  details?: string;
  instances?: TaskInstance[];
}

interface TaskInstance {
  id: string;
  date: string;
  completed: boolean;
  notes?: string;
}

interface GoalCategory {
  id: string;
  name: string;
  icon: string;
  progress: number;
  total: number;
  color: string;
  description?: string;
  oneTime: OneTimeTask[];
  repeatable: RepeatableTask[];
}

export function EnhancedGoals() {
  const [selectedTask, setSelectedTask] = useState<OneTimeTask | RepeatableTask | null>(null);
  const [taskType, setTaskType] = useState<'oneTime' | 'repeatable'>('oneTime');
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [isModalOpen, setIsModalOpen] = useState(false);

  const [categories, setCategories] = useState<GoalCategory[]>([
    {
      id: '1',
      name: "Academic / MPH",
      icon: "🎓",
      progress: 5,
      total: 8,
      color: "from-blue-50 to-indigo-50 border-blue-200",
      description: "Master's program requirements and academic excellence",
      oneTime: [
        { id: '1', text: "Build a comprehensive study system in OneNote", done: false, details: "Create organized sections for each course, templates for notes" },
        { id: '2', text: "Attend key class events (Aug 23 demo, live sessions)", done: true, details: "Completed orientation and first live session" },
        { id: '3', text: "Set up academic calendar with all assignment due dates", done: false }
      ],
      repeatable: [
        { 
          id: '4', 
          text: "Stay on top of weekly assignments, quizzes, journals", 
          frequency: "weekly", 
          progress: 8, 
          total: 16,
          details: "Weekly review and completion of coursework across both classes",
          instances: [
            { id: '4a', date: '2024-09-02', completed: true, notes: "Completed Journal 01 - got 100%!" },
            { id: '4b', date: '2024-09-09', completed: true, notes: "Journal 02 in progress" },
            { id: '4c', date: '2024-09-16', completed: false, notes: "Focus on Case Study 01" }
          ]
        },
        { 
          id: '5', 
          text: "Complete group projects with strong notes + participation", 
          frequency: "per project", 
          progress: 1, 
          total: 4,
          details: "Active participation in all group assignments and collaborative work"
        }
      ]
    },
    {
      id: '2',
      name: "Professional Development",
      icon: "💼",
      progress: 3,
      total: 7,
      color: "from-green-50 to-emerald-50 border-green-200",
      description: "Building professional network and skills for public health career",
      oneTime: [
        { id: '6', text: "Revamp LinkedIn profile with MPH projects, skills, certifications", done: false, details: "Update with current coursework, add skills section" },
        { id: '7', text: "Create professional portfolio website", done: false },
        { id: '8', text: "Join 3 professional public health organizations", done: true }
      ],
      repeatable: [
        { 
          id: '9', 
          text: "Post 2x per month on LinkedIn", 
          frequency: "monthly", 
          progress: 3, 
          total: 8,
          details: "Share insights about coursework, volunteering experiences, and public health topics",
          instances: [
            { id: '9a', date: '2024-08-15', completed: true, notes: "Posted about starting MPH program" },
            { id: '9b', date: '2024-08-30', completed: true, notes: "Shared volunteer experience insights" },
            { id: '9c', date: '2024-09-15', completed: false, notes: "Plan to share leadership learning" }
          ]
        },
        { 
          id: '10', 
          text: "Email professors for office hours (2 per semester)", 
          frequency: "semester", 
          progress: 1, 
          total: 2,
          details: "Build relationships with faculty, discuss career goals and research opportunities"
        }
      ]
    },
    {
      id: '3',
      name: "Health & Personal",
      icon: "🏃‍♀️",
      progress: 6,
      total: 6,
      color: "from-pink-50 to-rose-50 border-pink-200",
      description: "Maintaining physical and mental wellness during academic program",
      oneTime: [
        { id: '11', text: "Establish morning routine with exercise", done: true },
        { id: '12', text: "Set up meal prep system for busy weeks", done: true }
      ],
      repeatable: [
        { 
          id: '13', 
          text: "Exercise 4x per week (cardio + strength)", 
          frequency: "weekly", 
          progress: 12, 
          total: 16,
          details: "Maintain fitness routine throughout semester despite heavy coursework"
        },
        { 
          id: '14', 
          text: "Practice mindfulness/meditation 15 min daily", 
          frequency: "daily", 
          progress: 25, 
          total: 30,
          details: "Stress management and mental clarity during intense academic period"
        }
      ]
    }
  ]);

  const openTaskModal = (task: OneTimeTask | RepeatableTask, type: 'oneTime' | 'repeatable', categoryId: string) => {
    setSelectedTask(task);
    setTaskType(type);
    setSelectedCategory(categoryId);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setSelectedTask(null);
    setIsModalOpen(false);
  };

  const updateTaskProgress = (categoryId: string, taskId: string, type: 'oneTime' | 'repeatable') => {
    setCategories(prev => prev.map(category => {
      if (category.id !== categoryId) return category;
      
      if (type === 'oneTime') {
        const updatedOneTime = category.oneTime.map(task => 
          task.id === taskId ? { ...task, done: !task.done } : task
        );
        const completedOneTime = updatedOneTime.filter(task => task.done).length;
        const completedRepeatable = category.repeatable.filter(task => task.progress >= task.total).length;
        
        return {
          ...category,
          oneTime: updatedOneTime,
          progress: completedOneTime + completedRepeatable,
          total: category.oneTime.length + category.repeatable.length
        };
      } else {
        const updatedRepeatable = category.repeatable.map(task => 
          task.id === taskId ? { ...task, progress: Math.min(task.progress + 1, task.total) } : task
        );
        const completedOneTime = category.oneTime.filter(task => task.done).length;
        const completedRepeatable = updatedRepeatable.filter(task => task.progress >= task.total).length;
        
        return {
          ...category,
          repeatable: updatedRepeatable,
          progress: completedOneTime + completedRepeatable,
          total: category.oneTime.length + category.repeatable.length
        };
      }
    }));
  };

  const addTaskInstance = (categoryId: string, taskId: string, notes: string) => {
    setCategories(prev => prev.map(category => {
      if (category.id !== categoryId) return category;
      
      return {
        ...category,
        repeatable: category.repeatable.map(task => {
          if (task.id !== taskId) return task;
          
          const newInstance: TaskInstance = {
            id: `${taskId}_${Date.now()}`,
            date: new Date().toISOString().split('T')[0],
            completed: true,
            notes
          };
          
          return {
            ...task,
            progress: Math.min(task.progress + 1, task.total),
            instances: [...(task.instances || []), newInstance]
          };
        })
      };
    }));
  };

  const addNewGoal = (task: BasicTask) => {
    setCategories(prev => {
      const updated = [...prev];
      let targetCategory = updated.find(c => c.name === task.category);
      
      if (!targetCategory) {
        // If category doesn't exist, add to first category
        targetCategory = updated[0];
      }
      
      if (targetCategory) {
        const newOneTimeTask: OneTimeTask = {
          id: `goal-${Date.now()}`,
          text: task.title,
          done: false,
          details: task.description
        };
        
        targetCategory.oneTime.push(newOneTimeTask);
        // Update totals
        targetCategory.total = targetCategory.oneTime.length + targetCategory.repeatable.length;
      }
      
      return updated;
    });
  };

  const addNewRepeatableGoal = (task: BasicTask) => {
    setCategories(prev => {
      const updated = [...prev];
      let targetCategory = updated.find(c => c.name === task.category);
      
      if (!targetCategory) {
        targetCategory = updated[0];
      }
      
      if (targetCategory) {
        const newRepeatableTask: RepeatableTask = {
          id: `repeatable-${Date.now()}`,
          text: task.title,
          frequency: task.type.toLowerCase(),
          progress: 0,
          total: task.estimatedTime || 10,
          details: task.description,
          instances: []
        };
        
        targetCategory.repeatable.push(newRepeatableTask);
        // Update totals
        targetCategory.total = targetCategory.oneTime.length + targetCategory.repeatable.length;
      }
      
      return updated;
    });
  };

  const getProgressPercentage = (progress: number, total: number) => {
    return (progress / total) * 100;
  };

  const formatFrequency = (frequency: string) => {
    return frequency.charAt(0).toUpperCase() + frequency.slice(1);
  };

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h1 className="text-3xl font-bold mb-2">🎯 Fall 2025 Enhanced Goals</h1>
        <p className="text-gray-600">Track progress on one-time tasks and recurring objectives with detailed insights</p>
        <div className="flex justify-center gap-4 mt-6">
          <AddTaskModal
            onAdd={addNewGoal}
            triggerText="Add One-Time Goal"
            triggerIcon={<CheckCircle className="w-4 h-4" />}
            modalTitle="Add One-Time Goal"
            modalDescription="Create a goal that needs to be completed once"
            defaultType="Goal"
            predefinedTypes={["Goal", "Milestone", "Achievement", "Task", "Project"]}
            predefinedCategories={["Academic/MPH", "Professional Development", "Volunteering", "Skill Building", "Applied Practice", "Health & Personal", "Financial", "Personal Growth"]}
            colorTheme="purple"
            showAdvancedOptions={true}
          />
          <AddTaskModal
            onAdd={addNewRepeatableGoal}
            triggerText="Add Recurring Goal"
            triggerIcon={<Repeat className="w-4 h-4" />}
            triggerVariant="outline"
            modalTitle="Add Recurring Goal"
            modalDescription="Create a goal that needs to be completed multiple times"
            defaultType="Weekly"
            predefinedTypes={["Daily", "Weekly", "Monthly", "Semester", "Per Project"]}
            predefinedCategories={["Academic/MPH", "Professional Development", "Volunteering", "Skill Building", "Applied Practice", "Health & Personal", "Financial", "Personal Growth"]}
            colorTheme="indigo"
            showAdvancedOptions={true}
            customFields={[
              {
                name: 'targetCompletions',
                label: 'Target Completions',
                type: 'number',
                required: true
              }
            ]}
          />
        </div>
      </div>

      <div className="grid gap-6">
        {categories.map((category) => {
          const progressPercentage = getProgressPercentage(category.progress, category.total);
          
          return (
            <Card key={category.id} className={`bg-gradient-to-br ${category.color}`}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">{category.icon}</span>
                    <div>
                      <CardTitle className="text-xl">{category.name}</CardTitle>
                      <p className="text-sm text-gray-600 mt-1">{category.description}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold text-gray-700">
                      {Math.round(progressPercentage)}%
                    </div>
                    <div className="text-sm text-gray-500">
                      {category.progress}/{category.total} complete
                    </div>
                  </div>
                </div>
                
                <div className="mt-4">
                  <Progress value={progressPercentage} className="h-3" />
                </div>
              </CardHeader>
              
              <CardContent className="space-y-6">
                {/* One-time Tasks */}
                <div>
                  <h3 className="font-semibold mb-3 flex items-center gap-2">
                    <CheckCircle className="w-5 h-5" />
                    One-time Tasks
                  </h3>
                  <div className="space-y-2">
                    {category.oneTime.map(task => (
                      <div 
                        key={task.id} 
                        className="flex items-center gap-3 p-3 bg-white/60 rounded-lg hover:bg-white/80 transition-colors cursor-pointer"
                        onClick={() => openTaskModal(task, 'oneTime', category.id)}
                      >
                        <Checkbox
                          checked={task.done}
                          onCheckedChange={() => updateTaskProgress(category.id, task.id, 'oneTime')}
                          onClick={(e) => e.stopPropagation()}
                        />
                        <span className={`flex-1 ${task.done ? 'line-through text-gray-500' : ''}`}>
                          {task.text}
                        </span>
                        {task.done && (
                          <Badge className="bg-green-100 text-green-700">
                            <CheckCircle className="w-3 h-3 mr-1" />
                            Done
                          </Badge>
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Repeatable Tasks */}
                <div>
                  <h3 className="font-semibold mb-3 flex items-center gap-2">
                    <Repeat className="w-5 h-5" />
                    Recurring Tasks
                  </h3>
                  <div className="space-y-4">
                    {category.repeatable.map(task => {
                      const taskProgressPercentage = getProgressPercentage(task.progress, task.total);
                      const isCompleted = task.progress >= task.total;
                      
                      return (
                        <div 
                          key={task.id} 
                          className="p-4 bg-white/60 rounded-lg hover:bg-white/80 transition-colors cursor-pointer"
                          onClick={() => openTaskModal(task, 'repeatable', category.id)}
                        >
                          <div className="flex justify-between items-start mb-3">
                            <div className="flex-1">
                              <div className="font-medium mb-1">{task.text}</div>
                              <div className="flex items-center gap-4 text-sm text-gray-600">
                                <span className="flex items-center gap-1">
                                  <Repeat className="w-4 h-4" />
                                  {formatFrequency(task.frequency)}
                                </span>
                                <span>
                                  Progress: {task.progress}/{task.total}
                                </span>
                              </div>
                            </div>
                            {isCompleted && (
                              <Badge className="bg-green-100 text-green-700">
                                <CheckCircle className="w-3 h-3 mr-1" />
                                Complete
                              </Badge>
                            )}
                          </div>
                          
                          <div className="space-y-2">
                            <Progress value={taskProgressPercentage} className="h-2" />
                            <div className="text-xs text-gray-500">
                              {Math.round(taskProgressPercentage)}% complete
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Task Details Modal */}
      <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
        <DialogContent className="max-w-2xl">
          {selectedTask && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  {taskType === 'oneTime' ? (
                    <CheckCircle className="w-5 h-5" />
                  ) : (
                    <Repeat className="w-5 h-5" />
                  )}
                  {selectedTask.text}
                </DialogTitle>
                <DialogDescription>
                  {taskType === 'oneTime' 
                    ? 'Manage details and completion status for this one-time task'
                    : 'Track progress and add completion instances for this recurring task'
                  }
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-6">
                {/* Task Details */}
                <div>
                  <label className="text-sm font-medium">Details & Context</label>
                  <Textarea
                    value={selectedTask.details || ''}
                    onChange={(e) => {
                      const updatedDetails = e.target.value;
                      setCategories(prev => prev.map(category => {
                        if (category.id !== selectedCategory) return category;
                        
                        if (taskType === 'oneTime') {
                          return {
                            ...category,
                            oneTime: category.oneTime.map(task => 
                              task.id === selectedTask.id ? { ...task, details: updatedDetails } : task
                            )
                          };
                        } else {
                          return {
                            ...category,
                            repeatable: category.repeatable.map(task => 
                              task.id === selectedTask.id ? { ...task, details: updatedDetails } : task
                            )
                          };
                        }
                      }));
                      setSelectedTask(prev => prev ? { ...prev, details: updatedDetails } : null);
                    }}
                    placeholder="Add context, objectives, or notes about this task..."
                    rows={3}
                    className="mt-1"
                  />
                </div>

                {/* Progress Section for Repeatable Tasks */}
                {taskType === 'repeatable' && 'progress' in selectedTask && (
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="text-sm font-medium">Current Progress</label>
                        <div className="mt-1 p-3 bg-gray-50 rounded">
                          <div className="text-2xl font-bold">{selectedTask.progress}</div>
                          <div className="text-sm text-gray-600">out of {selectedTask.total}</div>
                        </div>
                      </div>
                      <div>
                        <label className="text-sm font-medium">Frequency</label>
                        <div className="mt-1 p-3 bg-gray-50 rounded">
                          <div className="font-medium">{formatFrequency(selectedTask.frequency)}</div>
                          <div className="text-sm text-gray-600">completion target</div>
                        </div>
                      </div>
                    </div>

                    <div>
                      <Progress 
                        value={getProgressPercentage(selectedTask.progress, selectedTask.total)} 
                        className="h-3"
                      />
                    </div>

                    {/* Add New Instance */}
                    <div className="border-t pt-4">
                      <h4 className="font-medium mb-3">Add New Completion</h4>
                      <div className="space-y-3">
                        <Textarea
                          placeholder="Add notes about this completion (what you accomplished, lessons learned, etc.)"
                          rows={2}
                          id="instance-notes"
                        />
                        <Button 
                          onClick={() => {
                            const notesElement = document.getElementById('instance-notes') as HTMLTextAreaElement;
                            const notes = notesElement?.value || '';
                            addTaskInstance(selectedCategory, selectedTask.id, notes);
                            if (notesElement) notesElement.value = '';
                            closeModal();
                          }}
                          disabled={selectedTask.progress >= selectedTask.total}
                          className="w-full"
                        >
                          <Plus className="w-4 h-4 mr-2" />
                          {selectedTask.progress >= selectedTask.total ? 'Task Complete!' : 'Mark as Done & Add Notes'}
                        </Button>
                      </div>
                    </div>

                    {/* Recent Instances */}
                    {selectedTask.instances && selectedTask.instances.length > 0 && (
                      <div className="border-t pt-4">
                        <h4 className="font-medium mb-3">Recent Completions</h4>
                        <div className="space-y-2 max-h-40 overflow-y-auto">
                          {selectedTask.instances.slice(-5).reverse().map(instance => (
                            <div key={instance.id} className="p-3 bg-green-50 rounded border-l-4 border-green-400">
                              <div className="flex items-center justify-between mb-1">
                                <span className="text-sm font-medium text-green-800">
                                  {new Date(instance.date).toLocaleDateString()}
                                </span>
                                <CheckCircle className="w-4 h-4 text-green-600" />
                              </div>
                              {instance.notes && (
                                <p className="text-sm text-green-700">{instance.notes}</p>
                              )}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* Actions */}
                <div className="flex gap-2 justify-end pt-4 border-t">
                  <Button variant="outline" onClick={closeModal}>
                    Close
                  </Button>
                  {taskType === 'oneTime' && 'done' in selectedTask && !selectedTask.done && (
                    <Button 
                      onClick={() => {
                        updateTaskProgress(selectedCategory, selectedTask.id, 'oneTime');
                        closeModal();
                      }}
                      className="bg-green-600 hover:bg-green-700"
                    >
                      <CheckCircle className="w-4 h-4 mr-2" />
                      Mark Complete
                    </Button>
                  )}
                  <Button onClick={() => {
                    // Add to calendar functionality would go here
                    alert('Calendar integration coming soon!');
                  }}>
                    <Calendar className="w-4 h-4 mr-2" />
                    Add to Calendar
                  </Button>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}