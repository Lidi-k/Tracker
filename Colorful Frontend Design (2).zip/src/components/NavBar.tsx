import { DarkModeToggle } from "./DarkModeToggle";

export function NavBar() {
  return (
    <nav className="bg-gradient-to-r from-purple-100 via-pink-100 to-blue-100 dark:from-purple-900/30 dark:via-pink-900/30 dark:to-blue-900/30 shadow-md transition-all duration-500">
      <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
        <div className="text-lg font-semibold text-purple-700 dark:text-purple-300">
          🌸 Lidiya Kassahun | MPH Goal Planner
        </div>
        <div className="flex items-center gap-6">
          <div className="flex gap-6">
            <a
              href="https://www.linkedin.com/in/lidiya-kassahun"
              target="_blank"
              className="text-sm font-medium text-gray-700 dark:text-gray-300 hover:text-purple-600 dark:hover:text-purple-400 transition-colors"
            >
              LinkedIn
            </a>
            <a
              href="https://github.com/Lidi-k"
              target="_blank"
              className="text-sm font-medium text-gray-700 dark:text-gray-300 hover:text-purple-600 dark:hover:text-purple-400 transition-colors"
            >
              GitHub
            </a>
          </div>
          <DarkModeToggle />
        </div>
      </div>
    </nav>
  );
}