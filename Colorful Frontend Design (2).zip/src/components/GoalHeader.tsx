import { Calendar, Target } from "lucide-react";
import { DarkModeToggle } from "./DarkModeToggle";

export function GoalHeader() {
  return (
    <header className="relative bg-gradient-to-r from-purple-200 via-pink-200 to-blue-200 dark:from-purple-900/30 dark:via-pink-900/30 dark:to-blue-900/30 py-12 transition-all duration-500">
      {/* Dark mode toggle in top right */}
      <div className="absolute top-4 right-6">
        <DarkModeToggle />
      </div>
      
      <div className="max-w-7xl mx-auto px-6 text-center">
        <div className="flex items-center justify-center gap-3 mb-4">
          <Target className="w-8 h-8 text-purple-600 dark:text-purple-400" />
          <h1 className="text-4xl md:text-5xl bg-gradient-to-r from-purple-600 to-pink-600 dark:from-purple-400 dark:to-pink-400 bg-clip-text text-transparent">
            Fall 2025 Goals
          </h1>
        </div>
        <div className="flex items-center justify-center gap-2 text-gray-600 dark:text-gray-300">
          <Calendar className="w-5 h-5" />
          <p className="text-lg">
            Track your progress through Fall 2025
          </p>
        </div>
        <div className="mt-6 text-sm text-gray-500 dark:text-gray-400">
          <p>✨ By January 2026, you'll have achieved all your goals!</p>
        </div>
      </div>
    </header>
  );
}