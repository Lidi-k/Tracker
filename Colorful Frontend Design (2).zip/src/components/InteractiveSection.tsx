import { useState } from "react";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";

export function InteractiveSection() {
  const [activeColor, setActiveColor] = useState("purple");
  
  const colorSchemes = {
    purple: {
      gradient: "from-purple-200 to-pink-200",
      bg: "from-purple-50 to-pink-50",
      accent: "bg-purple-200 text-purple-700",
      name: "Lavender Mist"
    },
    blue: {
      gradient: "from-blue-200 to-cyan-200",
      bg: "from-blue-50 to-cyan-50",
      accent: "bg-blue-200 text-blue-700",
      name: "Sky Whisper"
    },
    green: {
      gradient: "from-green-200 to-emerald-200",
      bg: "from-green-50 to-emerald-50",
      accent: "bg-green-200 text-green-700",
      name: "Mint Breeze"
    },
    orange: {
      gradient: "from-orange-200 to-rose-200",
      bg: "from-orange-50 to-rose-50",
      accent: "bg-orange-200 text-orange-700",
      name: "Peach Glow"
    }
  };

  return (
    <section className="py-20 px-6 bg-white">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl mb-4 bg-gradient-to-r from-gray-400 to-gray-500 bg-clip-text text-transparent">
            Pastel Color Palette
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto mb-8">
            Click the buttons below to see how different pastel schemes create gentle transformations
          </p>
          
          <div className="flex flex-wrap gap-4 justify-center mb-12">
            {Object.entries(colorSchemes).map(([key, scheme]) => (
              <Button
                key={key}
                onClick={() => setActiveColor(key)}
                className={`bg-gradient-to-r ${scheme.gradient} hover:shadow-lg transition-all duration-300 transform hover:scale-105 ${
                  activeColor === key ? 'ring-4 ring-gray-300' : ''
                }`}
              >
                {scheme.name}
              </Button>
            ))}
          </div>
        </div>
        
        <div className="grid md:grid-cols-2 gap-8">
          <Card className={`transition-all duration-500 bg-gradient-to-br ${colorSchemes[activeColor].bg} border-0 overflow-hidden`}>
            <CardHeader>
              <div className="flex items-center gap-3 mb-4">
                <Badge className={`${colorSchemes[activeColor].accent}`}>
                  Featured
                </Badge>
                <Badge variant="outline">
                  New
                </Badge>
              </div>
              <CardTitle className="text-2xl">Gentle Color Showcase</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-6">
                Watch how the entire design adapts to different pastel schemes with smooth transitions and soft gradients.
              </p>
              <div className={`h-20 bg-gradient-to-r ${colorSchemes[activeColor].gradient} rounded-lg mb-4 transition-all duration-500`}></div>
              <div className="flex gap-2">
                <div className={`w-8 h-8 bg-gradient-to-r ${colorSchemes[activeColor].gradient} rounded-full transition-all duration-500`}></div>
                <div className={`w-8 h-8 bg-gradient-to-r ${colorSchemes[activeColor].gradient} rounded-full transition-all duration-500 opacity-75`}></div>
                <div className={`w-8 h-8 bg-gradient-to-r ${colorSchemes[activeColor].gradient} rounded-full transition-all duration-500 opacity-50`}></div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-gray-50 to-gray-100 border-0">
            <CardHeader>
              <CardTitle className="text-2xl">Color Information</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <span className="text-sm text-gray-500">Active Scheme:</span>
                  <p className="text-lg">{colorSchemes[activeColor].name}</p>
                </div>
                <div>
                  <span className="text-sm text-gray-500">Gradient:</span>
                  <p className="text-sm font-mono bg-gray-200 p-2 rounded">
                    {colorSchemes[activeColor].gradient}
                  </p>
                </div>
                <div>
                  <span className="text-sm text-gray-500">Background:</span>
                  <p className="text-sm font-mono bg-gray-200 p-2 rounded">
                    {colorSchemes[activeColor].bg}
                  </p>
                </div>
                <Button 
                  variant="outline" 
                  className="w-full transition-all duration-300 hover:shadow-md"
                >
                  Copy Color Code
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}