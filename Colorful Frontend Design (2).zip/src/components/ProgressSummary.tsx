import { Progress } from "./ui/progress";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Trophy, TrendingUp, Clock, CheckCircle } from "lucide-react";

interface ProgressSummaryProps {
  selectedCategory: string;
}

export function ProgressSummary({ selectedCategory }: ProgressSummaryProps) {
  // Mock progress data - in a real app this would come from your data store
  const getProgressData = () => {
    if (selectedCategory === "all") {
      return {
        completed: 12,
        total: 31,
        percentage: 39,
        categories: 8
      };
    }
    
    const categoryData = {
      academic: { completed: 2, total: 4, percentage: 50 },
      professional: { completed: 1, total: 5, percentage: 20 },
      volunteering: { completed: 0, total: 4, percentage: 0 },
      skills: { completed: 1, total: 3, percentage: 33 },
      ape: { completed: 0, total: 3, percentage: 0 },
      health: { completed: 6, total: 6, percentage: 100 },
      financial: { completed: 1, total: 3, percentage: 33 },
      growth: { completed: 1, total: 3, percentage: 33 }
    };

    return categoryData[selectedCategory as keyof typeof categoryData] || { completed: 0, total: 0, percentage: 0 };
  };

  const progress = getProgressData();

  if (selectedCategory === "all") {
    return (
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <Card className="bg-gradient-to-br from-green-50 to-emerald-50 border-green-200">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm text-green-700">Completed Goals</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl text-green-800">{progress.completed}</div>
            <p className="text-xs text-green-600">out of {progress.total} total</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-blue-50 to-cyan-50 border-blue-200">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm text-blue-700">Overall Progress</CardTitle>
            <TrendingUp className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl text-blue-800">{progress.percentage}%</div>
            <Progress value={progress.percentage} className="mt-2" />
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-50 to-pink-50 border-purple-200">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm text-purple-700">Categories</CardTitle>
            <Trophy className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl text-purple-800">{progress.categories}</div>
            <p className="text-xs text-purple-600">goal categories</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-orange-50 to-rose-50 border-orange-200">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm text-orange-700">Time Remaining</CardTitle>
            <Clock className="h-4 w-4 text-orange-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl text-orange-800">4 months</div>
            <p className="text-xs text-orange-600">until January 2026</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <Card className="mb-8 bg-gradient-to-r from-purple-50 to-pink-50 border-purple-200">
      <CardHeader>
        <CardTitle className="text-purple-700">Category Progress</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex items-center justify-between mb-4">
          <span className="text-2xl text-purple-800">{progress.completed} / {progress.total}</span>
          <span className="text-lg text-purple-600">{progress.percentage}%</span>
        </div>
        <Progress value={progress.percentage} className="h-3" />
        <p className="text-sm text-purple-600 mt-2">
          {progress.completed} goals completed in this category
        </p>
      </CardContent>
    </Card>
  );
}