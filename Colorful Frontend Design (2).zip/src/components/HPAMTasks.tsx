import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Checkbox } from "./ui/checkbox";
import { Progress } from "./ui/progress";
import { Calendar, Users, FileText, PenTool, Presentation, CheckCircle, Plus } from "lucide-react";
import { AddTaskModal, BasicTask } from "./AddTaskModal";

interface HPAMTask {
  title: string;
  due_date: string;
  status: string;
  score?: number;
  completed: boolean;
}

interface HPAMCategory {
  category: string;
  tasks: HPAMTask[];
}

export function HPAMTasks() {
  const [categories, setCategories] = useState<HPAMCategory[]>([
    {
      category: "Case Studies",
      tasks: [
        { title: "Case Study 01 – Systems Thinking (Childhood Obesity)", due_date: "2025-09-07 23:59", status: "Not Submitted", completed: false },
        { title: "Case Study 02 – Leading Change (BUILD Health Challenge)", due_date: "2025-10-05 23:59", status: "Not Submitted", completed: false },
        { title: "Case Study 03 – Creating Effective Messengers", due_date: "2025-11-09 23:59", status: "Not Submitted", completed: false }
      ]
    },
    {
      category: "Peer Feedback",
      tasks: [
        { title: "Case Study 01 Peer Feedback", due_date: "2025-09-08 23:59", status: "Submitted", completed: true },
        { title: "Case Study 02 Peer Feedback", due_date: "2025-10-06 23:59", status: "Not Submitted", completed: false },
        { title: "Case Study 03 Peer Feedback", due_date: "2025-11-09 23:59", status: "Not Submitted", completed: false }
      ]
    },
    {
      category: "Journal Entries",
      tasks: [
        { title: "Journal 01 – Leadership & Your Why", due_date: "2025-08-24 23:59", status: "Submitted", score: 100, completed: true },
        { title: "Journal 02 – Emotional Intelligence", due_date: "2025-09-14 23:59", status: "Not Submitted", completed: false },
        { title: "Journal 03 – Leadership Models & Theories", due_date: "2025-09-21 23:59", status: "Not Submitted", completed: false },
        { title: "Journal 04 – DEI & Leadership", due_date: "2025-10-12 23:59", status: "Not Submitted", completed: false },
        { title: "Journal 05 – Managing Conflict", due_date: "2025-10-19 23:59", status: "Not Submitted", completed: false },
        { title: "Journal 06 – Building Teams", due_date: "2025-10-26 23:59", status: "Not Submitted", completed: false }
      ]
    },
    {
      category: "Final Project",
      tasks: [
        { title: "Leadership Framework – Written (6–9 pages)", due_date: "2025-12-07 23:59", status: "Not Submitted", completed: false },
        { title: "Leadership Framework – Presentation Recording", due_date: "2025-12-07 23:59", status: "Not Submitted", completed: false }
      ]
    }
  ]);

  const toggleTaskCompletion = (categoryIndex: number, taskIndex: number) => {
    setCategories(prev => prev.map((category, catIdx) => 
      catIdx === categoryIndex 
        ? {
            ...category,
            tasks: category.tasks.map((task, taskIdx) => 
              taskIdx === taskIndex 
                ? { 
                    ...task, 
                    completed: !task.completed, 
                    status: !task.completed ? "Submitted" : "Not Submitted" 
                  } 
                : task
            )
          }
        : category
    ));
  };

  const getDaysUntilDue = (dueDate: string): number => {
    const today = new Date();
    const due = new Date(dueDate);
    const diffTime = due.getTime() - today.getTime();
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  };

  const formatDate = (dateStr: string): string => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', { 
      weekday: 'short',
      month: 'short', 
      day: 'numeric',
      year: 'numeric'
    });
  };

  const getUrgencyColor = (daysUntil: number, completed: boolean) => {
    if (completed) return 'border-green-200 bg-green-50';
    if (daysUntil < 0) return 'border-red-300 bg-red-50';
    if (daysUntil <= 3) return 'border-orange-300 bg-orange-50';
    if (daysUntil <= 7) return 'border-yellow-300 bg-yellow-50';
    return 'border-blue-200 bg-blue-50';
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Submitted': return 'bg-green-100 text-green-700 border-green-200';
      case 'Not Submitted': return 'bg-gray-100 text-gray-700 border-gray-200';
      default: return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'Case Studies': return <FileText className="w-5 h-5 text-purple-600" />;
      case 'Peer Feedback': return <Users className="w-5 h-5 text-blue-600" />;
      case 'Journal Entries': return <PenTool className="w-5 h-5 text-green-600" />;
      case 'Final Project': return <Presentation className="w-5 h-5 text-orange-600" />;
      default: return <FileText className="w-5 h-5 text-gray-600" />;
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'Case Studies': return 'from-purple-50 to-indigo-50 border-purple-200';
      case 'Peer Feedback': return 'from-blue-50 to-cyan-50 border-blue-200';
      case 'Journal Entries': return 'from-green-50 to-emerald-50 border-green-200';
      case 'Final Project': return 'from-orange-50 to-red-50 border-orange-200';
      default: return 'from-gray-50 to-slate-50 border-gray-200';
    }
  };

  const getTotalProgress = () => {
    const totalTasks = categories.reduce((acc, cat) => acc + cat.tasks.length, 0);
    const completedTasks = categories.reduce((acc, cat) => 
      acc + cat.tasks.filter(task => task.completed).length, 0
    );
    return totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0;
  };

  const getCompletedCount = () => {
    return categories.reduce((acc, cat) => 
      acc + cat.tasks.filter(task => task.completed).length, 0
    );
  };

  const getTotalCount = () => {
    return categories.reduce((acc, cat) => acc + cat.tasks.length, 0);
  };

  const addTask = (task: BasicTask) => {
    setCategories(prev => {
      const updated = [...prev];
      const defaultCategory = updated.find(c => c.category === "Case Studies");
      if (defaultCategory) {
        defaultCategory.tasks.push({
          title: task.title,
          due_date: task.due_date,
          status: "Not Submitted",
          completed: false,
        });
      } else {
        updated.push({
          category: "New",
          tasks: [
            {
              title: task.title,
              due_date: task.due_date,
              status: "Not Submitted",
              completed: false,
            },
          ],
        });
      }
      return updated;
    });
  };

  return (
    <div className="space-y-6">
      {/* Course Overview */}
      <Card className="bg-gradient-to-r from-indigo-50 to-purple-50 border-indigo-200">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <PenTool className="w-6 h-6 text-indigo-600" />
              HPAM7700E: Leadership & Management of Public Health Organizations
            </CardTitle>
            <AddTaskModal
              onAdd={addTask}
              triggerText="Add HPAM Task"
              triggerIcon={<Plus className="w-4 h-4" />}
              modalTitle="Add HPAM Assignment"
              modalDescription="Add a new leadership course assignment"
              defaultCourse="HPAM7700E"
              predefinedTypes={["Journal", "Case Study", "Peer Feedback", "Final Project", "Presentation", "Reading", "Discussion"]}
              predefinedCategories={["Case Studies", "Peer Feedback", "Journal Entries", "Final Project"]}
              colorTheme="purple"
              showAdvancedOptions={true}
            />
          </div>
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Course Progress</span>
              <span className="text-sm font-medium">{Math.round(getTotalProgress())}%</span>
            </div>
            <Progress value={getTotalProgress()} className="h-3" />
            <div className="flex items-center gap-4 text-sm text-gray-600">
              <span>Completed: {getCompletedCount()}/{getTotalCount()}</span>
              <span>•</span>
              <span>Grade earned on Journal 01: 100/100 ✨</span>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Assignment Categories */}
      <div className="space-y-4">
        {categories.map((category, categoryIndex) => {
          const categoryProgress = (category.tasks.filter(task => task.completed).length / category.tasks.length) * 100;
          
          return (
            <Card key={categoryIndex} className={`bg-gradient-to-br ${getCategoryColor(category.category)}`}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    {getCategoryIcon(category.category)}
                    <CardTitle>{category.category}</CardTitle>
                  </div>
                  <Badge variant="outline" className="bg-white/60">
                    {category.tasks.filter(task => task.completed).length} / {category.tasks.length}
                  </Badge>
                </div>
                <div className="mt-4">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm text-gray-600">Category Progress</span>
                    <span className="text-sm font-medium">{Math.round(categoryProgress)}%</span>
                  </div>
                  <Progress value={categoryProgress} className="h-2" />
                </div>
              </CardHeader>
              
              <CardContent>
                <div className="space-y-3">
                  {category.tasks.map((task, taskIndex) => {
                    const daysUntil = getDaysUntilDue(task.due_date);
                    
                    return (
                      <div 
                        key={taskIndex} 
                        className={`p-4 rounded-lg border transition-all duration-200 hover:shadow-md ${getUrgencyColor(daysUntil, task.completed)}`}
                      >
                        <div className="flex items-start gap-3">
                          <Checkbox
                            checked={task.completed}
                            onCheckedChange={() => toggleTaskCompletion(categoryIndex, taskIndex)}
                            className="mt-1"
                          />
                          
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-2">
                              <Badge className={getStatusColor(task.status)}>
                                {task.status}
                              </Badge>
                              
                              <div className="flex items-center gap-1 text-sm text-gray-600">
                                <Calendar className="w-4 h-4" />
                                {formatDate(task.due_date)}
                              </div>
                              
                              {daysUntil >= 0 && !task.completed && (
                                <div className={`text-sm ${
                                  daysUntil <= 3 ? 'text-red-600' : 
                                  daysUntil <= 7 ? 'text-orange-600' : 
                                  'text-green-600'
                                }`}>
                                  {daysUntil === 0 ? 'Due today' : 
                                   daysUntil === 1 ? 'Due tomorrow' : 
                                   `${daysUntil} days left`}
                                </div>
                              )}
                              
                              {daysUntil < 0 && !task.completed && (
                                <div className="text-sm text-red-600">
                                  {Math.abs(daysUntil)} days overdue
                                </div>
                              )}
                              
                              {task.completed && (
                                <div className="flex items-center gap-1 text-sm text-green-600">
                                  <CheckCircle className="w-4 h-4" />
                                  Completed
                                </div>
                              )}
                            </div>
                            
                            <h4 className={`mb-1 ${task.completed ? 'line-through text-gray-500' : ''}`}>
                              {task.title}
                            </h4>
                            
                            {task.score && (
                              <div className="text-sm font-medium text-green-700">
                                Score: {task.score}/100
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}