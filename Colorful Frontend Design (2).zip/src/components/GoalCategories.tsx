import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Checkbox } from "./ui/checkbox";
import { Progress } from "./ui/progress";
import { Badge } from "./ui/badge";

interface Goal {
  id: string;
  text: string;
  completed: boolean;
}

interface Category {
  id: string;
  name: string;
  emoji: string;
  color: string;
  goals: Goal[];
}

interface GoalCategoriesProps {
  selectedCategory: string;
}

export function GoalCategories({ selectedCategory }: GoalCategoriesProps) {
  const [categories, setCategories] = useState<Category[]>([
    {
      id: "academic",
      name: "Academic / MPH",
      emoji: "🎓",
      color: "blue",
      goals: [
        { id: "ac1", text: "Stay on top of all weekly assignments, quizzes, and journals", completed: true },
        { id: "ac2", text: "Complete Case Studies & group projects with strong notes + participation", completed: false },
        { id: "ac3", text: "Build a study system in OneNote (modules, deadlines, weekly plan)", completed: true },
        { id: "ac4", text: "Decide on and attend important class events (e.g., Aug 23 demo, other live sessions)", completed: false }
      ]
    },
    {
      id: "professional",
      name: "Professional Development",
      emoji: "💼",
      color: "purple",
      goals: [
        { id: "pr1", text: "Revamp LinkedIn profile with MPH projects, skills, certifications", completed: false },
        { id: "pr2", text: "Post 2x per month (project updates, reflections, volunteering)", completed: false },
        { id: "pr3", text: "Grow your network: 20–30 new public health professionals", completed: false },
        { id: "pr4", text: "Apply for your school mentorship program and complete the 3-month cycle", completed: true },
        { id: "pr5", text: "Email/check in with at least 2 professors (1 Summer, 1 Fall)", completed: false }
      ]
    },
    {
      id: "volunteering",
      name: "Volunteering & Involvement",
      emoji: "🌍",
      color: "green",
      goals: [
        { id: "vo1", text: "Secure 1 consistent volunteer role in public health", completed: false },
        { id: "vo2", text: "Shortlist opportunities across fields (Epi, Env Health, Global, Policy, Community)", completed: false },
        { id: "vo3", text: "Join at least 1 student/professional organization (APHA, ASPPH, UGA groups)", completed: false },
        { id: "vo4", text: "Participate in 1 networking event per month (virtual or in person)", completed: false }
      ]
    },
    {
      id: "skills",
      name: "Skill Building & Certifications",
      emoji: "📚",
      color: "orange",
      goals: [
        { id: "sk1", text: "Learn core technical tools: R, SQL, Python, Tableau, Power BI, ArcGIS", completed: false },
        { id: "sk2", text: "Complete 2–3 certifications before January 2026", completed: false },
        { id: "sk3", text: "Build mini-projects in R/Python/Tableau and share on LinkedIn", completed: true }
      ]
    },
    {
      id: "ape",
      name: "Applied Practice Experience (APE)",
      emoji: "🧑‍🔬",
      color: "teal",
      goals: [
        { id: "ap1", text: "Contact APE coordinator and secure APE site for Spring", completed: false },
        { id: "ap2", text: "Log pre-APE hours (Slack webinars, volunteering, training)", completed: false },
        { id: "ap3", text: "Explore potential fellowship/internship pathways aligned with APE", completed: false }
      ]
    },
    {
      id: "health",
      name: "Health & Personal",
      emoji: "🏃‍♀️",
      color: "pink",
      goals: [
        { id: "he1", text: "Consistently hit 7–10k steps daily", completed: true },
        { id: "he2", text: "Gym/workout 3x per week", completed: true },
        { id: "he3", text: "Meal prep weekly and track diet", completed: true },
        { id: "he4", text: "Maintain skincare, supplements, and night routine", completed: true },
        { id: "he5", text: "Read 101 Careers in Public Health + at least 1 self-help and 1 fiction book", completed: true },
        { id: "he6", text: "Practice mindfulness and stress management techniques", completed: true }
      ]
    },
    {
      id: "financial",
      name: "Financial",
      emoji: "💰",
      color: "emerald",
      goals: [
        { id: "fi1", text: "Save $4–5k by January 2026", completed: false },
        { id: "fi2", text: "Make steady debt repayments", completed: true },
        { id: "fi3", text: "Improve credit score through on-time payments + low utilization", completed: false }
      ]
    },
    {
      id: "growth",
      name: "Personal Growth",
      emoji: "🌟",
      color: "indigo",
      goals: [
        { id: "gr1", text: "Strengthen social skills, networking, leadership, and confidence", completed: false },
        { id: "gr2", text: "Practice public speaking in class or networking groups", completed: false },
        { id: "gr3", text: "Journal/reflection writing on growth and progress monthly", completed: true }
      ]
    }
  ]);

  const handleGoalToggle = (categoryId: string, goalId: string) => {
    setCategories(prev => 
      prev.map(category => 
        category.id === categoryId
          ? {
              ...category,
              goals: category.goals.map(goal => 
                goal.id === goalId ? { ...goal, completed: !goal.completed } : goal
              )
            }
          : category
      )
    );
  };

  const filteredCategories = selectedCategory === "all" 
    ? categories 
    : categories.filter(cat => cat.id === selectedCategory);

  const getColorClasses = (color: string) => {
    const colorMap = {
      blue: "from-blue-50 to-cyan-50 border-blue-200",
      purple: "from-purple-50 to-pink-50 border-purple-200",
      green: "from-green-50 to-emerald-50 border-green-200",
      orange: "from-orange-50 to-rose-50 border-orange-200",
      teal: "from-teal-50 to-cyan-50 border-teal-200",
      pink: "from-pink-50 to-rose-50 border-pink-200",
      emerald: "from-emerald-50 to-green-50 border-emerald-200",
      indigo: "from-indigo-50 to-purple-50 border-indigo-200"
    };
    return colorMap[color as keyof typeof colorMap] || "from-gray-50 to-slate-50 border-gray-200";
  };

  const getBadgeColor = (color: string) => {
    const colorMap = {
      blue: "bg-blue-200 text-blue-700",
      purple: "bg-purple-200 text-purple-700",
      green: "bg-green-200 text-green-700",
      orange: "bg-orange-200 text-orange-700",
      teal: "bg-teal-200 text-teal-700",
      pink: "bg-pink-200 text-pink-700",
      emerald: "bg-emerald-200 text-emerald-700",
      indigo: "bg-indigo-200 text-indigo-700"
    };
    return colorMap[color as keyof typeof colorMap] || "bg-gray-200 text-gray-700";
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {filteredCategories.map(category => {
        const completedCount = category.goals.filter(goal => goal.completed).length;
        const progress = (completedCount / category.goals.length) * 100;

        return (
          <Card key={category.id} className={`bg-gradient-to-br ${getColorClasses(category.color)}`}>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <span className="text-2xl">{category.emoji}</span>
                  <span>{category.name}</span>
                </CardTitle>
                <Badge className={getBadgeColor(category.color)}>
                  {completedCount}/{category.goals.length}
                </Badge>
              </div>
              <div className="mt-4">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm text-gray-600">Progress</span>
                  <span className="text-sm font-medium">{Math.round(progress)}%</span>
                </div>
                <Progress value={progress} className="h-2" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {category.goals.map(goal => (
                  <div key={goal.id} className="flex items-start gap-3 p-3 rounded-lg bg-white/50 hover:bg-white/70 transition-colors">
                    <Checkbox
                      id={goal.id}
                      checked={goal.completed}
                      onCheckedChange={() => handleGoalToggle(category.id, goal.id)}
                      className="mt-0.5"
                    />
                    <label
                      htmlFor={goal.id}
                      className={`text-sm cursor-pointer flex-1 ${
                        goal.completed ? 'line-through text-gray-500' : 'text-gray-700'
                      }`}
                    >
                      {goal.text}
                    </label>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}