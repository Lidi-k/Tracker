export function SkillsAndAdvice() {
  const skills = [
    "SQL", "R", "Python", "SAS", "Tableau", "Power BI", "ArcGIS",
    "Epidemiology", "Surveillance", "Program Evaluation",
    "Health Informatics", "Policy", "Grant Writing", "CAPM/PMP"
  ];
  
  const advice = [
    "Network consistently – follow up with APHA, LinkedIn groups, and mentors.",
    "Document your projects with clear outcomes and skills gained.",
    "Use your APE to align with PHIFP or similar fellowships.",
    "Balance academics with health and personal routines."
  ];
  
  const certifications = [
    { name: "SQL & Tableau", source: "LinkedIn Learning", status: "In Progress" },
    { name: "Python for Data Science", source: "edX Verizon", status: "In Progress" },
    { name: "CDC TRAIN Modules", source: "CDC TRAIN", status: "In Progress" },
    { name: "PMP / CAPM Prep", source: "Coursera / Udemy", status: "Researching" },
    { name: "ArcGIS Training", source: "Esri / LinkedIn Learning", status: "Planned" },
    { name: "Grant Writing", source: "LinkedIn / edX", status: "Planned" }
  ];

  return (
    <section id="features" className="py-16 px-6 bg-gradient-to-r from-yellow-50 via-pink-50 to-purple-50 dark:from-yellow-950/20 dark:via-pink-950/20 dark:to-purple-950/20 transition-all duration-500">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-3xl font-bold mb-8 text-center bg-gradient-to-r from-yellow-600 via-pink-600 to-purple-600 dark:from-yellow-400 dark:via-pink-400 dark:to-purple-400 bg-clip-text text-transparent">
          Skills & Professional Development
        </h2>
        <div className="grid md:grid-cols-3 gap-6">
          <div className="bg-yellow-100/80 dark:bg-yellow-900/20 p-6 rounded-xl shadow-lg backdrop-blur-sm border border-yellow-200/50 dark:border-yellow-700/30">
            <h3 className="font-semibold mb-4 text-yellow-800 dark:text-yellow-300 text-lg">Core Skills</h3>
            <ul className="space-y-2 text-sm">
              {skills.map((skill, i) => (
                <li key={i} className="flex items-center gap-2 text-gray-700 dark:text-gray-300">
                  <span className="w-1.5 h-1.5 bg-yellow-500 rounded-full"></span>
                  {skill}
                </li>
              ))}
            </ul>
          </div>
          
          <div className="bg-pink-100/80 dark:bg-pink-900/20 p-6 rounded-xl shadow-lg backdrop-blur-sm border border-pink-200/50 dark:border-pink-700/30">
            <h3 className="font-semibold mb-4 text-pink-800 dark:text-pink-300 text-lg">Career Advice</h3>
            <ul className="space-y-3 text-sm">
              {advice.map((item, i) => (
                <li key={i} className="flex items-start gap-2 text-gray-700 dark:text-gray-300">
                  <span className="w-1.5 h-1.5 bg-pink-500 rounded-full mt-2 flex-shrink-0"></span>
                  {item}
                </li>
              ))}
            </ul>
          </div>
          
          <div className="bg-purple-100/80 dark:bg-purple-900/20 p-6 rounded-xl shadow-lg backdrop-blur-sm border border-purple-200/50 dark:border-purple-700/30">
            <h3 className="font-semibold mb-4 text-purple-800 dark:text-purple-300 text-lg">Certifications</h3>
            <ul className="space-y-3 text-sm">
              {certifications.map((cert, i) => (
                <li key={i} className="text-gray-700 dark:text-gray-300">
                  <div className="font-medium text-purple-700 dark:text-purple-300">{cert.name}</div>
                  <div className="text-xs text-gray-600 dark:text-gray-400">{cert.source}</div>
                  <div className="text-xs text-purple-600 dark:text-purple-400 font-medium">({cert.status})</div>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}