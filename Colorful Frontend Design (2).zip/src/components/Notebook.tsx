import { useState, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Textarea } from "./ui/textarea";
import { Input } from "./ui/input";
import { Badge } from "./ui/badge";
import { ScrollArea } from "./ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "./ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Progress } from "./ui/progress";
import { Separator } from "./ui/separator";
import { AddTaskModal, BasicTask } from "./AddTaskModal";
import { 
  BookOpen, 
  Upload, 
  Plus, 
  Bot, 
  FileText, 
  Calendar,
  Tag,
  Search,
  Sparkles,
  Save,
  Trash2,
  Target,
  Heart,
  Users,
  Star,
  Palette,
  Camera,
  Mic,
  Video,
  Download,
  Share2,
  Edit,
  Eye,
  Clock,
  CheckSquare,
  ArrowRight,
  Lightbulb,
  TrendingUp,
  Brain,
  Music,
  Coffee,
  Sunrise,
  Moon,
  Zap,
  Bookmark,
  Filter,
  Grid,
  List,
  Folder,
  Archive,
  Pin,
  Copy,
  Shuffle,
  RefreshCw,
  Settings,
  Image as ImageIcon,
  PenTool,
  Type,
  Layers,
  Layout,
  Maximize,
  Minimize
} from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import exampleVision1 from 'figma:asset/e411553bb7fafaf8547bc57d9d36db0aead869e3.png';
import exampleVision2 from 'figma:asset/ce965b21b64d4978f91205c67b940384efb166b2.png';

interface Note {
  id: string;
  title: string;
  content: string;
  tags: string[];
  createdAt: Date;
  courseRelated?: string;
  aiInsights?: string;
  noteType: 'text' | 'journal' | 'research' | 'idea' | 'goal' | 'reflection';
  mood?: string;
  priority?: 'low' | 'medium' | 'high';
  category?: string;
  attachments?: string[];
  linkedGoals?: string[];
  isPrivate?: boolean;
  wordCount?: number;
}

interface VisionBoardItem {
  id: string;
  type: 'image' | 'text' | 'quote' | 'goal';
  content: string;
  position: { x: number; y: number };
  size: { width: number; height: number };
  style?: {
    backgroundColor?: string;
    textColor?: string;
    fontSize?: number;
    fontWeight?: string;
  };
}

interface PlannerItem {
  id: string;
  type: 'task' | 'event' | 'reminder' | 'habit';
  title: string;
  description?: string;
  date: Date;
  completed?: boolean;
  priority?: 'low' | 'medium' | 'high';
  category?: string;
  timeSpent?: number;
  estimatedTime?: number;
}

interface AIInsight {
  id: string;
  type: 'pattern' | 'suggestion' | 'connection' | 'improvement' | 'mood';
  title: string;
  content: string;
  confidence: number;
  createdAt: Date;
  relatedNotes?: string[];
}

export function Notebook() {
  const [notes, setNotes] = useState<Note[]>([
    {
      id: '1',
      title: 'Leadership Theories - Journal 03 Prep',
      content: 'Key leadership models to explore:\n\n• Transformational Leadership - Bass & Riggio\n• Servant Leadership - Greenleaf\n• Situational Leadership - Hersey & Blanchard\n\nNeed to reflect on which resonates most with my leadership style and provide specific examples.',
      tags: ['HPAM7700E', 'leadership', 'journal'],
      createdAt: new Date('2024-09-15'),
      courseRelated: 'HPAM7700E',
      aiInsights: 'Consider connecting transformational leadership to your public health goals - this model emphasizes inspiring others toward collective objectives, which aligns well with population health initiatives.',
      noteType: 'research',
      priority: 'high',
      category: 'Academic',
      wordCount: 145,
      linkedGoals: ['Complete Journal 03', 'Develop Leadership Framework']
    },
    {
      id: '2',
      title: 'HVA Process Notes',
      content: 'Hazard Vulnerability Analysis for Rabun County:\n\nNatural Hazards to research:\n1. Flooding (frequent in mountain regions)\n2. Severe storms/tornadoes\n3. Winter storms/ice\n4. Wildfires\n5. Earthquakes (less likely but possible)\n\nTechnological:\n1. Chemical spills (transportation routes)\n2. Power grid failures\n3. Water system contamination',
      tags: ['DMAN7100E', 'rabun-county', 'research'],
      createdAt: new Date('2024-09-10'),
      courseRelated: 'DMAN7100E',
      noteType: 'research',
      priority: 'medium',
      category: 'Academic',
      wordCount: 98
    },
    {
      id: '3',
      title: 'Morning Reflection - September Goals',
      content: 'Feeling motivated today! The fall semester is in full swing and I can see real progress in my leadership development. Need to stay focused on:\n\n- Completing all academic assignments on time\n- Building my professional network\n- Maintaining work-life balance\n- Taking care of my mental health\n\nReminder: Self-care is not selfish. I need to be at my best to help others.',
      tags: ['reflection', 'goals', 'self-care', 'motivation'],
      createdAt: new Date('2024-09-13'),
      noteType: 'journal',
      mood: 'motivated',
      priority: 'medium',
      category: 'Personal',
      wordCount: 89,
      linkedGoals: ['Maintain Work-Life Balance', 'Academic Excellence']
    },
    {
      id: '4',
      title: 'Vision 2025 - Career & Impact',
      content: 'My vision for where I want to be by end of 2025:\n\n🎓 MPH completed with distinction\n💼 Secured meaningful role in public health leadership\n🌍 Making tangible impact in community health\n📚 Published research or policy work\n🤝 Strong professional network in public health\n💪 Maintained physical and mental wellness\n✈️ Travel opportunities for global health perspective\n🏡 Stable, inspiring living situation',
      tags: ['vision', '2025', 'career', 'goals', 'future'],
      createdAt: new Date('2024-09-08'),
      noteType: 'goal',
      priority: 'high',
      category: 'Life Vision',
      wordCount: 134,
      linkedGoals: ['Complete MPH Program', 'Career Development', 'Global Health Experience']
    }
  ]);

  const [visionBoard, setVisionBoard] = useState<VisionBoardItem[]>([
    {
      id: 'v1',
      type: 'image',
      content: exampleVision1,
      position: { x: 20, y: 20 },
      size: { width: 300, height: 400 }
    },
    {
      id: 'v2',
      type: 'image', 
      content: exampleVision2,
      position: { x: 340, y: 20 },
      size: { width: 300, height: 400 }
    },
    {
      id: 'v3',
      type: 'quote',
      content: '"When things change inside you, things change around you" - Anonymous',
      position: { x: 660, y: 100 },
      size: { width: 280, height: 120 },
      style: {
        backgroundColor: '#fef3c7',
        textColor: '#92400e',
        fontSize: 16,
        fontWeight: 'medium'
      }
    },
    {
      id: 'v4',
      type: 'goal',
      content: 'MPH Graduate 2025\n✨ Making Impact ✨',
      position: { x: 660, y: 240 },
      size: { width: 280, height: 100 },
      style: {
        backgroundColor: '#dbeafe',
        textColor: '#1e40af',
        fontSize: 18,
        fontWeight: 'bold'
      }
    }
  ]);

  const [plannerItems, setPlannerItems] = useState<PlannerItem[]>([
    {
      id: 'p1',
      type: 'task',
      title: 'Finish Leadership Journal 03',
      description: 'Reflect on leadership styles and personal growth',
      date: new Date(),
      priority: 'high',
      category: 'Academic',
      estimatedTime: 2
    },
    {
      id: 'p2',
      type: 'task',
      title: 'FEMA IS-100 Study Session',
      description: 'Review emergency management principles',
      date: new Date(),
      priority: 'medium',
      category: 'Professional',
      estimatedTime: 2
    },
    {
      id: 'p3',
      type: 'habit',
      title: 'Morning Meditation',
      description: '10 minutes mindfulness practice',
      date: new Date(),
      completed: true,
      category: 'Wellness'
    },
    {
      id: 'p4',
      type: 'event',
      title: 'Study Group - Leadership',
      description: 'Collaborative discussion on leadership theories',
      date: new Date(Date.now() + 86400000),
      category: 'Academic'
    }
  ]);

  const [aiInsights, setAIInsights] = useState<AIInsight[]>([
    {
      id: 'ai1',
      type: 'pattern',
      title: 'Learning Momentum',
      content: 'You\'ve been consistently engaging with leadership content. Your notes show deepening understanding of transformational leadership principles.',
      confidence: 0.85,
      createdAt: new Date(),
      relatedNotes: ['1', '3']
    },
    {
      id: 'ai2',
      type: 'suggestion',
      title: 'Connect Theory to Practice',
      content: 'Consider documenting real-world examples of leadership styles you observe. This will strengthen your journal reflections.',
      confidence: 0.78,
      createdAt: new Date(),
      relatedNotes: ['1']
    },
    {
      id: 'ai3',
      type: 'mood',
      title: 'Positive Growth Mindset',
      content: 'Your recent notes reflect strong motivation and self-awareness. This positive momentum supports your academic goals.',
      confidence: 0.92,
      createdAt: new Date(),
      relatedNotes: ['3', '4']
    }
  ]);

  const [currentNote, setCurrentNote] = useState({ 
    title: '', 
    content: '', 
    tags: '', 
    noteType: 'text' as Note['noteType'],
    mood: '',
    priority: 'medium' as Note['priority'],
    attachments: [] as string[]
  });
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('list');
  const [isAddingNote, setIsAddingNote] = useState(false);
  const [isVisionBoardOpen, setIsVisionBoardOpen] = useState(false);
  const [selectedInsight, setSelectedInsight] = useState<AIInsight | null>(null);
  const [activeTab, setActiveTab] = useState('notebook');

  const addNote = () => {
    if (!currentNote.title.trim() || !currentNote.content.trim()) return;

    const wordCount = currentNote.content.trim().split(/\s+/).length;
    const newNote: Note = {
      id: Date.now().toString(),
      title: currentNote.title,
      content: currentNote.content,
      tags: currentNote.tags.split(',').map(tag => tag.trim()).filter(tag => tag),
      createdAt: new Date(),
      courseRelated: currentNote.tags.includes('HPAM') ? 'HPAM7700E' : 
                    currentNote.tags.includes('DMAN') ? 'DMAN7100E' : undefined,
      noteType: currentNote.noteType,
      mood: currentNote.mood || undefined,
      priority: currentNote.priority,
      category: currentNote.tags.includes('academic') ? 'Academic' : 
               currentNote.tags.includes('personal') ? 'Personal' : 'General',
      wordCount,
      linkedGoals: [],
      attachments: currentNote.attachments
    };

    setNotes(prev => [newNote, ...prev]);
    setCurrentNote({ title: '', content: '', tags: '', noteType: 'text', mood: '', priority: 'medium', attachments: [] });
    setIsAddingNote(false);
  };

  const deleteNote = (id: string) => {
    setNotes(prev => prev.filter(note => note.id !== id));
  };

  const generateAIInsight = (note: Note) => {
    const insights = [
      "This connects well to your leadership framework development. Consider how these concepts apply to crisis leadership.",
      "Great research foundation! Make sure to include local data and demographics in your analysis.",
      "This reflection shows growth in your leadership thinking. Consider adding specific examples from your experience.",
      "Strong technical understanding. Connect this to community resilience and vulnerable populations.",
      "Consider the ethical implications and social justice aspects of this topic in your analysis.",
      "Your writing shows increasing confidence in academic discourse. Keep building on these analytical skills.",
      "This vision aligns well with current public health priorities. Consider how you can contribute to these areas.",
      "The mood in your reflection is very positive. This mindset will support your goal achievement."
    ];
    
    const randomInsight = insights[Math.floor(Math.random() * insights.length)];
    
    setNotes(prev => prev.map(n => 
      n.id === note.id ? { ...n, aiInsights: randomInsight } : n
    ));
  };

  const generateDailyInsights = () => {
    const newInsight: AIInsight = {
      id: Date.now().toString(),
      type: 'pattern',
      title: 'Daily Writing Pattern',
      content: `You've written ${notes.filter(n => new Date(n.createdAt).toDateString() === new Date().toDateString()).length} notes today. Your most common themes are leadership, research, and personal growth.`,
      confidence: 0.88,
      createdAt: new Date(),
      relatedNotes: notes.slice(0, 3).map(n => n.id)
    };

    setAIInsights(prev => [newInsight, ...prev]);
  };

  const filteredNotes = notes.filter(note => {
    const matchesSearch = !searchTerm || 
      note.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      note.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
      note.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
    
    const matchesCategory = selectedCategory === 'all' || 
      note.category === selectedCategory ||
      note.noteType === selectedCategory ||
      note.tags.some(tag => tag.toLowerCase().includes(selectedCategory.toLowerCase()));
    
    return matchesSearch && matchesCategory;
  });

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getPriorityColor = (priority?: string) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-700 border-red-200';
      case 'medium': return 'bg-yellow-100 text-yellow-700 border-yellow-200';
      case 'low': return 'bg-green-100 text-green-700 border-green-200';
      default: return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  const getMoodEmoji = (mood?: string) => {
    switch (mood) {
      case 'motivated': return '🚀';
      case 'focused': return '🎯';
      case 'grateful': return '🙏';
      case 'inspired': return '✨';
      case 'calm': return '🧘';
      case 'excited': return '🎉';
      default: return '📝';
    }
  };

  const toggleTaskComplete = (taskId: string) => {
    setPlannerItems(prev => prev.map(item => 
      item.id === taskId ? { ...item, completed: !item.completed } : item
    ));
  };

  const addNoteFromModal = (task: BasicTask) => {
    const wordCount = task.description.trim().split(/\s+/).length;
    const newNote: Note = {
      id: `note-${Date.now()}`,
      title: task.title,
      content: task.description,
      createdAt: new Date(),
      noteType: task.type.toLowerCase() as Note['noteType'] || 'text',
      category: task.course,
      tags: task.tags || [],
      priority: task.priority,
      mood: task.mood,
      wordCount,
      attachments: task.attachments
    };
    
    setNotes(prev => [newNote, ...prev]);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="bg-gradient-to-r from-purple-50 via-pink-50 to-indigo-50 border-purple-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BookOpen className="w-6 h-6 text-purple-600" />
            AI-Powered Digital Workspace
            <Badge className="bg-purple-100 text-purple-700 ml-auto">
              {notes.length} notes • {plannerItems.length} tasks
            </Badge>
          </CardTitle>
          <p className="text-sm text-gray-600">
            Your personal productivity sanctuary with AI insights, vision boarding, and aesthetic planning
          </p>
        </CardHeader>
      </Card>

      {/* Main Workspace */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="notebook" className="flex items-center gap-2">
            <PenTool className="w-4 h-4" />
            Smart Notes
          </TabsTrigger>
          <TabsTrigger value="planner" className="flex items-center gap-2">
            <Calendar className="w-4 h-4" />
            Daily Planner
          </TabsTrigger>
          <TabsTrigger value="vision" className="flex items-center gap-2">
            <Target className="w-4 h-4" />
            Vision Board
          </TabsTrigger>
          <TabsTrigger value="insights" className="flex items-center gap-2">
            <Brain className="w-4 h-4" />
            AI Insights
          </TabsTrigger>
          <TabsTrigger value="journal" className="flex items-center gap-2">
            <Heart className="w-4 h-4" />
            Reflection
          </TabsTrigger>
        </TabsList>

        {/* Smart Notes Tab */}
        <TabsContent value="notebook" className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="flex gap-4 flex-1">
              <div className="relative flex-1 max-w-md">
                <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <Input
                  placeholder="Search notes..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Filter" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Notes</SelectItem>
                  <SelectItem value="Academic">Academic</SelectItem>
                  <SelectItem value="Personal">Personal</SelectItem>
                  <SelectItem value="research">Research</SelectItem>
                  <SelectItem value="journal">Journal</SelectItem>
                  <SelectItem value="goal">Goals</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex gap-2">
              <Button
                variant={viewMode === 'list' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setViewMode('list')}
              >
                <List className="w-4 h-4" />
              </Button>
              <Button
                variant={viewMode === 'grid' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setViewMode('grid')}
              >
                <Grid className="w-4 h-4" />
              </Button>
              <Button onClick={() => setIsAddingNote(true)}>
                <Plus className="w-4 h-4 mr-2" />
                New Note
              </Button>
              <AddTaskModal
                onAdd={addNoteFromModal}
                triggerText="Quick Add"
                triggerIcon={<Zap className="w-4 h-4" />}
                triggerVariant="outline"
                modalTitle="Quick Add Note"
                modalDescription="Quickly capture ideas, thoughts, or reminders"
                defaultType="Text"
                predefinedTypes={["Text", "Journal", "Research", "Idea", "Goal", "Reflection"]}
                predefinedCourses={["HPAM7700E", "DMAN7100E", "Personal", "Academic", "Professional"]}
                colorTheme="purple"
                showAdvancedOptions={true}
              />
            </div>
          </div>

          {/* Notes Display */}
          {viewMode === 'list' ? (
            <div className="space-y-4">
              {filteredNotes.map(note => (
                <Card key={note.id} className="hover:shadow-md transition-all duration-200">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <span className="text-xl">{getMoodEmoji(note.mood)}</span>
                          <CardTitle className="text-lg">{note.title}</CardTitle>
                          {note.priority && (
                            <Badge className={getPriorityColor(note.priority)} size="sm">
                              {note.priority}
                            </Badge>
                          )}
                          <Badge variant="outline" className="text-xs">
                            {note.noteType}
                          </Badge>
                        </div>
                        <div className="flex items-center gap-2 mb-2">
                          <Calendar className="w-4 h-4 text-gray-400" />
                          <span className="text-sm text-gray-500">{formatDate(note.createdAt)}</span>
                          {note.wordCount && (
                            <Badge variant="secondary" className="text-xs">
                              {note.wordCount} words
                            </Badge>
                          )}
                        </div>
                        <div className="flex flex-wrap gap-1">
                          {note.tags.map((tag, index) => (
                            <Badge key={index} variant="outline" className="text-xs">
                              <Tag className="w-3 h-3 mr-1" />
                              {tag}
                            </Badge>
                          ))}
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button variant="ghost" size="sm">
                          <Pin className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="sm">
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => deleteNote(note.id)}
                          className="text-red-500 hover:text-red-700"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  
                  <CardContent>
                    <div className="space-y-4">
                      <ScrollArea className="max-h-32">
                        <div className="whitespace-pre-wrap text-sm text-gray-700 pr-4">
                          {note.content.length > 200 ? `${note.content.substring(0, 200)}...` : note.content}
                        </div>
                      </ScrollArea>
                      
                      {/* Note Attachments */}
                      {note.attachments && note.attachments.length > 0 && (
                        <div className="space-y-2">
                          <p className="text-xs font-medium text-gray-600">Attachments ({note.attachments.length})</p>
                          <div className="flex gap-2 overflow-x-auto">
                            {note.attachments.map((attachment, i) => (
                              <img 
                                key={i}
                                src={attachment} 
                                alt={`attachment ${i + 1}`} 
                                className="w-20 h-20 rounded-md object-cover border-2 border-gray-200 flex-shrink-0 hover:scale-105 transition-transform cursor-pointer" 
                              />
                            ))}
                          </div>
                        </div>
                      )}

                      {note.aiInsights && (
                        <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-lg p-3">
                          <div className="flex items-start gap-2">
                            <Sparkles className="w-4 h-4 text-blue-600 mt-0.5" />
                            <div>
                              <p className="text-sm font-medium text-blue-800 mb-1">AI Insight</p>
                              <p className="text-sm text-blue-700">{note.aiInsights}</p>
                            </div>
                          </div>
                        </div>
                      )}
                      
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => generateAIInsight(note)}
                          disabled={!!note.aiInsights}
                        >
                          <Bot className="w-4 h-4 mr-2" />
                          {note.aiInsights ? 'AI Analyzed' : 'Analyze with AI'}
                        </Button>
                        <Button variant="outline" size="sm">
                          <Share2 className="w-4 h-4 mr-2" />
                          Share
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredNotes.map(note => (
                <Card key={note.id} className="hover:shadow-md transition-shadow h-fit">
                  <CardContent className="p-4">
                    <div className="space-y-3">
                      <div className="flex items-center gap-2">
                        <span className="text-lg">{getMoodEmoji(note.mood)}</span>
                        <h3 className="font-medium text-sm line-clamp-2">{note.title}</h3>
                      </div>
                      <p className="text-xs text-gray-600 line-clamp-3">{note.content}</p>
                      <div className="flex flex-wrap gap-1">
                        {note.tags.slice(0, 2).map((tag, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                        {note.tags.length > 2 && (
                          <Badge variant="outline" className="text-xs">+{note.tags.length - 2}</Badge>
                        )}
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-xs text-gray-500">{formatDate(note.createdAt)}</span>
                        <div className="flex gap-1">
                          <Button variant="ghost" size="sm">
                            <Eye className="w-3 h-3" />
                          </Button>
                          <Button variant="ghost" size="sm">
                            <Edit className="w-3 h-3" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        {/* Daily Planner Tab */}
        <TabsContent value="planner" className="space-y-6">
          <div className="grid grid-cols-12 gap-6">
            {/* Today's Schedule */}
            <Card className="col-span-12 lg:col-span-8 bg-white/80 backdrop-blur-md shadow-xl rounded-2xl border border-purple-200">
              <CardHeader className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-t-2xl">
                <CardTitle className="flex items-center gap-2 text-purple-700">
                  <Calendar className="w-5 h-5" />
                  Today's Schedule
                  <Badge className="ml-auto bg-purple-100 text-purple-700">
                    {plannerItems.filter(item => item.date.toDateString() === new Date().toDateString()).length} items
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="space-y-4">
                  {plannerItems
                    .filter(item => item.date.toDateString() === new Date().toDateString())
                    .map(item => (
                      <div key={item.id} className="flex items-center gap-4 p-4 bg-gradient-to-r from-purple-50 to-pink-50 rounded-xl border border-purple-100 hover:shadow-md transition-all">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => toggleTaskComplete(item.id)}
                          className={`rounded-full w-8 h-8 ${item.completed ? 'text-green-600 bg-green-100' : 'text-purple-400 bg-purple-100'}`}
                        >
                          <CheckSquare className="w-4 h-4" />
                        </Button>
                        <div className="flex-1">
                          <div className={`font-medium text-gray-800 ${item.completed ? 'line-through text-gray-500' : ''}`}>
                            {item.title}
                          </div>
                          {item.description && (
                            <div className="text-sm text-gray-600 mt-1">{item.description}</div>
                          )}
                          <div className="flex items-center gap-2 mt-2">
                            <Badge variant="outline" className="text-xs bg-white/50">{item.type}</Badge>
                            {item.priority && (
                              <Badge className={`${getPriorityColor(item.priority)} text-xs`}>
                                {item.priority}
                              </Badge>
                            )}
                            {item.estimatedTime && (
                              <span className="text-xs text-purple-600 bg-purple-100 px-2 py-1 rounded-full">
                                {item.estimatedTime}h
                              </span>
                            )}
                          </div>
                        </div>
                        <Button variant="ghost" size="sm" className="text-purple-600 hover:bg-purple-100">
                          <Edit className="w-4 h-4" />
                        </Button>
                      </div>
                    ))}
                </div>
              </CardContent>
            </Card>

            {/* Quick Stats & Aesthetic Sections */}
            <div className="col-span-12 lg:col-span-4 space-y-4">
              <Card className="bg-white/80 backdrop-blur-md shadow-lg rounded-2xl border border-green-200">
                <CardHeader className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-t-2xl">
                  <CardTitle className="flex items-center gap-2 text-green-700">
                    <TrendingUp className="w-5 h-5" />
                    Progress Today
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-4">
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between text-sm mb-2 text-gray-700">
                        <span>Tasks Completed</span>
                        <span className="font-medium">{plannerItems.filter(i => i.completed).length}/{plannerItems.length}</span>
                      </div>
                      <Progress 
                        value={(plannerItems.filter(i => i.completed).length / plannerItems.length) * 100} 
                        className="h-3 bg-green-100"
                      />
                    </div>
                    <div>
                      <div className="flex justify-between text-sm mb-2 text-gray-700">
                        <span>Focus Time</span>
                        <span className="font-medium">4.5h / 6h</span>
                      </div>
                      <Progress value={75} className="h-3 bg-blue-100" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-white/80 backdrop-blur-md shadow-lg rounded-2xl border border-yellow-200">
                <CardHeader className="bg-gradient-to-r from-yellow-50 to-orange-50 rounded-t-2xl">
                  <CardTitle className="flex items-center gap-2 text-yellow-700">
                    <Zap className="w-5 h-5" />
                    Energy Level
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-4">
                  <div className="text-center">
                    <div className="text-4xl mb-3">⚡</div>
                    <div className="text-lg font-medium text-gray-800">High Energy</div>
                    <div className="text-sm text-gray-600">Perfect for deep work</div>
                  </div>
                </CardContent>
              </Card>

              {/* Aesthetic Mood Section */}
              <Card className="bg-white/80 backdrop-blur-md shadow-lg rounded-2xl border border-pink-200">
                <CardHeader className="bg-gradient-to-r from-pink-50 to-rose-50 rounded-t-2xl">
                  <CardTitle className="flex items-center gap-2 text-pink-700">
                    <Heart className="w-5 h-5" />
                    Aesthetic Mood
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-4">
                  <div className="grid grid-cols-2 gap-2">
                    <div className="aspect-square rounded-xl bg-gradient-to-br from-pink-200 to-purple-200 flex items-center justify-center text-2xl">
                      🌸
                    </div>
                    <div className="aspect-square rounded-xl bg-gradient-to-br from-blue-200 to-cyan-200 flex items-center justify-center text-2xl">
                      ✨
                    </div>
                    <div className="aspect-square rounded-xl bg-gradient-to-br from-purple-200 to-indigo-200 flex items-center justify-center text-2xl">
                      🦋
                    </div>
                    <div className="aspect-square rounded-xl bg-gradient-to-br from-yellow-200 to-orange-200 flex items-center justify-center text-2xl">
                      ☀️
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        {/* Vision Board Tab */}
        <TabsContent value="vision" className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold">Vision Board 2025</h2>
            <div className="flex gap-2">
              {/* Add Image Button */}
              <label htmlFor="vision-upload" className="cursor-pointer">
                <input
                  id="vision-upload"
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => {
                    if (e.target.files?.[0]) {
                      const file = e.target.files[0];
                      const reader = new FileReader();
                      reader.onload = () => {
                        const newItem: VisionBoardItem = {
                          id: Date.now().toString(),
                          type: "image",
                          content: reader.result as string, // base64
                          position: { x: 50, y: 50 },
                          size: { width: 250, height: 300 },
                        };
                        setVisionBoard((prev) => [...prev, newItem]);
                      };
                      reader.readAsDataURL(file);
                    }
                  }}
                />
                <Button variant="outline">
                  <Upload className="w-4 h-4 mr-2" />
                  Add Image
                </Button>
              </label>
              <Button
                variant="outline"
                onClick={() => {
                  const newText: VisionBoardItem = {
                    id: Date.now().toString(),
                    type: "quote",
                    content: "New inspiring quote ✨",
                    position: { x: 100, y: 100 },
                    size: { width: 200, height: 100 },
                    style: { backgroundColor: "#f0f9ff", textColor: "#1e3a8a", fontSize: 16 }
                  };
                  setVisionBoard((prev) => [...prev, newText]);
                }}
              >
                <Type className="w-4 h-4 mr-2" />
                Add Text
              </Button>
              <Button>
                <Save className="w-4 h-4 mr-2" />
                Save Board
              </Button>
            </div>
          </div>

          <Card className="min-h-[600px] bg-gradient-to-br from-pink-50 via-purple-50 to-indigo-50 border-2 border-dashed border-pink-200">
            <CardContent className="p-6 relative overflow-hidden">
              <div className="relative w-full h-[500px] rounded-xl bg-white/30 backdrop-blur-sm">
                {visionBoard.map(item => (
                  <div
                    key={item.id}
                    className="absolute cursor-move hover:shadow-xl transition-all duration-300 hover:scale-105 group"
                    style={{
                      left: item.position.x,
                      top: item.position.y,
                      width: item.size.width,
                      height: item.size.height
                    }}
                  >
                    {item.type === 'image' ? (
                      <div className="relative w-full h-full">
                        <img
                          src={item.content}
                          alt="Vision board item"
                          className="w-full h-full object-cover rounded-xl shadow-lg border-2 border-white"
                        />
                        <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => setVisionBoard(prev => prev.filter(i => i.id !== item.id))}
                          >
                            <Trash2 className="w-3 h-3" />
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <div className="relative w-full h-full">
                        <div
                          className="w-full h-full rounded-xl shadow-lg p-4 flex items-center justify-center text-center border-2 border-white backdrop-blur-sm"
                          style={{
                            backgroundColor: item.style?.backgroundColor,
                            color: item.style?.textColor,
                            fontSize: item.style?.fontSize,
                            fontWeight: item.style?.fontWeight
                          }}
                        >
                          <div className="whitespace-pre-line">{item.content}</div>
                        </div>
                        <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => setVisionBoard(prev => prev.filter(i => i.id !== item.id))}
                          >
                            <Trash2 className="w-3 h-3" />
                          </Button>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
                
                {/* Aesthetic Background Elements */}
                <div className="absolute inset-0 pointer-events-none">
                  <div className="absolute top-10 left-10 w-20 h-20 bg-pink-200/30 rounded-full blur-xl"></div>
                  <div className="absolute bottom-20 right-20 w-32 h-32 bg-purple-200/30 rounded-full blur-xl"></div>
                  <div className="absolute top-1/2 left-1/2 w-16 h-16 bg-blue-200/30 rounded-full blur-xl"></div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Vision Elements</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center p-4 bg-purple-50 rounded-lg">
                  <div className="text-2xl mb-2">🎓</div>
                  <div className="font-medium">Education</div>
                  <div className="text-sm text-gray-600">MPH Excellence</div>
                </div>
                <div className="text-center p-4 bg-blue-50 rounded-lg">
                  <div className="text-2xl mb-2">💼</div>
                  <div className="font-medium">Career</div>
                  <div className="text-sm text-gray-600">Public Health Leader</div>
                </div>
                <div className="text-center p-4 bg-green-50 rounded-lg">
                  <div className="text-2xl mb-2">🌍</div>
                  <div className="font-medium">Impact</div>
                  <div className="text-sm text-gray-600">Global Health</div>
                </div>
                <div className="text-center p-4 bg-pink-50 rounded-lg">
                  <div className="text-2xl mb-2">💪</div>
                  <div className="font-medium">Wellness</div>
                  <div className="text-sm text-gray-600">Mind & Body</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* AI Insights Tab */}
        <TabsContent value="insights" className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold">AI Insights & Patterns</h2>
            <Button onClick={generateDailyInsights}>
              <RefreshCw className="w-4 h-4 mr-2" />
              Generate New Insights
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {aiInsights.map(insight => (
              <Card key={insight.id} className="hover:shadow-md transition-shadow">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="text-base flex items-center gap-2">
                        {insight.type === 'pattern' && <TrendingUp className="w-4 h-4 text-blue-600" />}
                        {insight.type === 'suggestion' && <Lightbulb className="w-4 h-4 text-yellow-600" />}
                        {insight.type === 'mood' && <Heart className="w-4 h-4 text-pink-600" />}
                        {insight.title}
                      </CardTitle>
                      <Badge variant="secondary" className="text-xs mt-2">
                        {Math.round(insight.confidence * 100)}% confidence
                      </Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-700 mb-3">{insight.content}</p>
                  <div className="flex justify-between items-center">
                    <span className="text-xs text-gray-500">{formatDate(insight.createdAt)}</span>
                    <Button variant="outline" size="sm">
                      <Eye className="w-3 h-3 mr-1" />
                      Details
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Reflection Tab */}
        <TabsContent value="journal" className="space-y-6">
          <Card className="bg-gradient-to-r from-amber-50 to-orange-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Sunrise className="w-5 h-5 text-orange-600" />
                Daily Reflection Space
              </CardTitle>
              <p className="text-sm text-gray-600">
                Take a moment to reflect on your thoughts, feelings, and growth
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              <Textarea
                placeholder="How are you feeling today? What are you grateful for? What did you learn?"
                rows={6}
                className="resize-none"
              />
              <div className="flex justify-between items-center">
                <div className="flex gap-2">
                  {['🙏', '🚀', '🎯', '✨', '🧘', '💪'].map(emoji => (
                    <Button key={emoji} variant="outline" size="sm">
                      {emoji}
                    </Button>
                  ))}
                </div>
                <Button>
                  <Save className="w-4 h-4 mr-2" />
                  Save Reflection
                </Button>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="w-5 h-5 text-green-600" />
                  Weekly Goals Check-in
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Complete Journal 03</span>
                    <Progress value={75} className="w-24 h-2" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">FEMA Training</span>
                    <Progress value={50} className="w-24 h-2" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Self-care routine</span>
                    <Progress value={90} className="w-24 h-2" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Heart className="w-5 h-5 text-pink-600" />
                  Gratitude Log
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="text-sm p-2 bg-pink-50 rounded">
                    "Grateful for supportive classmates in my study group"
                  </div>
                  <div className="text-sm p-2 bg-pink-50 rounded">
                    "Thankful for my advisor's guidance on my research"
                  </div>
                  <div className="text-sm p-2 bg-pink-50 rounded">
                    "Appreciating my progress in leadership skills"
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      {/* Add Note Dialog */}
      <Dialog open={isAddingNote} onOpenChange={setIsAddingNote}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Create New Note</DialogTitle>
            <DialogDescription>
              Capture your thoughts with smart categorization and AI insights
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <Input
              placeholder="Note title..."
              value={currentNote.title}
              onChange={(e) => setCurrentNote(prev => ({ ...prev, title: e.target.value }))}
            />
            <div className="grid grid-cols-3 gap-4">
              <Select 
                value={currentNote.noteType} 
                onValueChange={(value) => setCurrentNote(prev => ({ ...prev, noteType: value as Note['noteType'] }))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Note type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="text">Text Note</SelectItem>
                  <SelectItem value="journal">Journal Entry</SelectItem>
                  <SelectItem value="research">Research</SelectItem>
                  <SelectItem value="idea">Idea</SelectItem>
                  <SelectItem value="goal">Goal</SelectItem>
                  <SelectItem value="reflection">Reflection</SelectItem>
                </SelectContent>
              </Select>
              <Select 
                value={currentNote.priority} 
                onValueChange={(value) => setCurrentNote(prev => ({ ...prev, priority: value as Note['priority'] }))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Priority" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                </SelectContent>
              </Select>
              <Input
                placeholder="Mood (optional)"
                value={currentNote.mood}
                onChange={(e) => setCurrentNote(prev => ({ ...prev, mood: e.target.value }))}
              />
            </div>
            <Textarea
              placeholder="Write your thoughts, insights, or ideas here..."
              value={currentNote.content}
              onChange={(e) => setCurrentNote(prev => ({ ...prev, content: e.target.value }))}
              rows={6}
              className="resize-none"
            />
            <Input
              placeholder="Tags (comma-separated): leadership, HPAM7700E, reflection..."
              value={currentNote.tags}
              onChange={(e) => setCurrentNote(prev => ({ ...prev, tags: e.target.value }))}
            />
            
            {/* File Attachments */}
            <div className="space-y-3">
              <label className="text-sm font-medium">Attachments</label>
              <div className="flex gap-2">
                <label htmlFor="note-attachments" className="cursor-pointer">
                  <input
                    id="note-attachments"
                    type="file"
                    multiple
                    accept="image/*,application/pdf,.doc,.docx"
                    className="hidden"
                    onChange={(e) => {
                      if (e.target.files) {
                        const files = Array.from(e.target.files);
                        const urls = files.map((f) => URL.createObjectURL(f));
                        setCurrentNote((prev) => ({
                          ...prev,
                          attachments: [...prev.attachments, ...urls],
                        }));
                      }
                    }}
                  />
                  <Button variant="outline" type="button">
                    <Upload className="w-4 h-4 mr-2" />
                    Add Files
                  </Button>
                </label>
                <Button variant="outline" type="button">
                  <Camera className="w-4 h-4 mr-2" />
                  Take Photo
                </Button>
                <Button variant="outline" type="button">
                  <Mic className="w-4 h-4 mr-2" />
                  Record Audio
                </Button>
              </div>
              
              {/* Display Current Attachments */}
              {currentNote.attachments && currentNote.attachments.length > 0 && (
                <div className="grid grid-cols-6 gap-2">
                  {currentNote.attachments.map((attachment, i) => (
                    <div key={i} className="relative group">
                      <img 
                        src={attachment} 
                        alt={`attachment ${i + 1}`} 
                        className="w-16 h-16 rounded-lg object-cover border-2 border-gray-200" 
                      />
                      <Button
                        variant="destructive"
                        size="sm"
                        className="absolute -top-2 -right-2 w-6 h-6 p-0 opacity-0 group-hover:opacity-100 transition-opacity"
                        onClick={() => {
                          setCurrentNote(prev => ({
                            ...prev,
                            attachments: prev.attachments.filter((_, index) => index !== i)
                          }));
                        }}
                      >
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </div>
            
            <div className="flex gap-2 justify-end">
              <Button variant="outline" onClick={() => setIsAddingNote(false)}>
                Cancel
              </Button>
              <Button onClick={addNote} disabled={!currentNote.title.trim() || !currentNote.content.trim()}>
                <Save className="w-4 h-4 mr-2" />
                Save Note
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}