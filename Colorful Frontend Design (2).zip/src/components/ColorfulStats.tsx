import { Card, CardContent } from "./ui/card";

export function ColorfulStats() {
  const stats = [
    {
      number: "100+",
      label: "Pastel Components",
      gradient: "from-purple-300 to-pink-300",
      bgGradient: "from-purple-50 to-pink-50"
    },
    {
      number: "50K+",
      label: "Happy Users",
      gradient: "from-blue-300 to-cyan-300",
      bgGradient: "from-blue-50 to-cyan-50"
    },
    {
      number: "99%",
      label: "Satisfaction Rate",
      gradient: "from-green-300 to-emerald-300",
      bgGradient: "from-green-50 to-emerald-50"
    },
    {
      number: "24/7",
      label: "Support Available",
      gradient: "from-orange-300 to-rose-300",
      bgGradient: "from-orange-50 to-rose-50"
    }
  ];

  return (
    <section className="py-20 px-6 bg-gradient-to-r from-indigo-100 via-purple-100 to-pink-100">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl mb-4 bg-gradient-to-r from-indigo-400 to-purple-400 bg-clip-text text-transparent">
            By the Numbers
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            See how our gentle approach delivers peaceful results
          </p>
        </div>
        
        <div className="grid md:grid-cols-4 gap-6">
          {stats.map((stat, index) => (
            <Card 
              key={index} 
              className={`group hover:shadow-2xl transition-all duration-300 transform hover:scale-105 bg-gradient-to-br ${stat.bgGradient} border-0 text-center`}
            >
              <CardContent className="pt-8 pb-8">
                <div className={`text-4xl md:text-5xl mb-2 bg-gradient-to-r ${stat.gradient} bg-clip-text text-transparent`}>
                  {stat.number}
                </div>
                <div className="text-gray-700">
                  {stat.label}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}