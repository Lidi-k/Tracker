export function APESection() {
  const targetOpportunities = [
    "CDC PHIFP 2026",
    "NASA DEVELOP Program",
    "AAMC Fellowship",
    "Carter Center Internship",
    "WHO Field Epidemiology",
    "Local Health Department"
  ];

  const networkingGroups = [
    "American Public Health Association (APHA)",
    "National Association of County & City Health Officials (NACCHO)",
    "LinkedIn Public Health Club",
    "Student Public Health Association",
    "Epidemic Intelligence Service (EIS) Alumni"
  ];

  const materials = [
    "APE Handbook & Guidelines",
    "UGA MPH Program Syllabus",
    "Competency Assessment Tools",
    "Supervisor Evaluation Forms",
    "Reflection Portfolio Template"
  ];

  return (
    <section className="py-16 px-6 bg-gradient-to-r from-blue-50 via-indigo-50 to-purple-50 dark:from-blue-950/30 dark:via-indigo-950/30 dark:to-purple-950/30 transition-all duration-500">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-3xl font-bold mb-8 text-center bg-gradient-to-r from-blue-600 to-indigo-600 dark:from-blue-400 dark:to-indigo-400 bg-clip-text text-transparent">
          Applied Practice Experience (APE)
        </h2>
        <div className="grid md:grid-cols-3 gap-6">
          <div className="bg-blue-100/80 dark:bg-blue-900/20 p-6 rounded-xl shadow-lg backdrop-blur-sm border border-blue-200/50 dark:border-blue-700/30">
            <h3 className="font-semibold mb-4 text-blue-800 dark:text-blue-300 text-lg">Target Opportunities</h3>
            <ul className="space-y-3 text-sm">
              {targetOpportunities.map((opportunity, i) => (
                <li key={i} className="flex items-center gap-2 text-gray-700 dark:text-gray-300">
                  <span className="w-1.5 h-1.5 bg-blue-500 rounded-full"></span>
                  {opportunity}
                </li>
              ))}
            </ul>
          </div>
          
          <div className="bg-indigo-100/80 dark:bg-indigo-900/20 p-6 rounded-xl shadow-lg backdrop-blur-sm border border-indigo-200/50 dark:border-indigo-700/30">
            <h3 className="font-semibold mb-4 text-indigo-800 dark:text-indigo-300 text-lg">Networking Groups</h3>
            <ul className="space-y-3 text-sm">
              {networkingGroups.map((group, i) => (
                <li key={i} className="flex items-start gap-2 text-gray-700 dark:text-gray-300">
                  <span className="w-1.5 h-1.5 bg-indigo-500 rounded-full mt-2 flex-shrink-0"></span>
                  {group}
                </li>
              ))}
            </ul>
          </div>
          
          <div className="bg-purple-100/80 dark:bg-purple-900/20 p-6 rounded-xl shadow-lg backdrop-blur-sm border border-purple-200/50 dark:border-purple-700/30">
            <h3 className="font-semibold mb-4 text-purple-800 dark:text-purple-300 text-lg">Resources & Materials</h3>
            <ul className="space-y-3 text-sm">
              {materials.map((material, i) => (
                <li key={i} className="flex items-start gap-2 text-gray-700 dark:text-gray-300">
                  <span className="w-1.5 h-1.5 bg-purple-500 rounded-full mt-2 flex-shrink-0"></span>
                  {material}
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="mt-8 p-6 bg-white/80 dark:bg-gray-900/50 rounded-xl shadow-lg backdrop-blur-sm border border-gray-200/50 dark:border-gray-700/30">
          <h3 className="font-semibold mb-3 text-gray-800 dark:text-gray-200 text-lg">APE Preparation Strategy</h3>
          <div className="grid md:grid-cols-2 gap-6 text-sm">
            <div>
              <h4 className="font-medium text-blue-600 dark:text-blue-400 mb-2">Timeline & Planning</h4>
              <ul className="space-y-1 text-gray-600 dark:text-gray-400">
                <li>• Start networking 6-12 months before APE</li>
                <li>• Submit applications 3-4 months early</li>
                <li>• Prepare competency portfolio continuously</li>
                <li>• Schedule informational interviews</li>
              </ul>
            </div>
            <div>
              <h4 className="font-medium text-purple-600 dark:text-purple-400 mb-2">Key Focus Areas</h4>
              <ul className="space-y-1 text-gray-600 dark:text-gray-400">
                <li>• Health informatics & surveillance systems</li>
                <li>• Program evaluation & assessment</li>
                <li>• Data analysis & visualization</li>
                <li>• Community health partnerships</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}