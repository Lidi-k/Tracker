import { Button } from "./ui/button";
import { Badge } from "./ui/badge";

interface CategoryFilterProps {
  selectedCategory: string;
  onCategoryChange: (category: string) => void;
}

export function CategoryFilter({ selectedCategory, onCategoryChange }: CategoryFilterProps) {
  const categories = [
    { id: "all", name: "All Categories", emoji: "🎯", count: 8 },
    { id: "academic", name: "Academic / MPH", emoji: "🎓", count: 4 },
    { id: "professional", name: "Professional", emoji: "💼", count: 5 },
    { id: "volunteering", name: "Volunteering", emoji: "🌍", count: 4 },
    { id: "skills", name: "Skills & Certs", emoji: "📚", count: 3 },
    { id: "ape", name: "APE", emoji: "🧑‍🔬", count: 3 },
    { id: "health", name: "Health & Personal", emoji: "🏃‍♀️", count: 6 },
    { id: "financial", name: "Financial", emoji: "💰", count: 3 },
    { id: "growth", name: "Personal Growth", emoji: "🌟", count: 3 }
  ];

  return (
    <div className="mb-8">
      <div className="flex flex-wrap gap-3 justify-center">
        {categories.map((category) => (
          <Button
            key={category.id}
            onClick={() => onCategoryChange(category.id)}
            variant={selectedCategory === category.id ? "default" : "outline"}
            className={`flex items-center gap-2 transition-all duration-200 ${
              selectedCategory === category.id
                ? "bg-purple-200 text-purple-700 border-purple-300 hover:bg-purple-300"
                : "hover:bg-purple-50 hover:border-purple-200"
            }`}
          >
            <span>{category.emoji}</span>
            <span>{category.name}</span>
            <Badge variant="secondary" className="ml-1 bg-gray-100 text-gray-600">
              {category.count}
            </Badge>
          </Button>
        ))}
      </div>
    </div>
  );
}