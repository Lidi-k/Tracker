import { useState } from 'react';
import { Progress } from '../ui/progress';
import { Input } from '../ui/input';
import { Button } from '../ui/button';
import { Slider } from '../ui/slider';
import { Edit3, Save, X, TrendingUp } from 'lucide-react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';

interface EditableProgressBarProps {
  value: number;
  max?: number;
  min?: number;
  label?: string;
  showValue?: boolean;
  showTarget?: boolean;
  target?: number;
  unit?: string;
  colorScheme?: 'default' | 'purple' | 'blue' | 'green' | 'pink' | 'yellow' | 'orange';
  size?: 'sm' | 'md' | 'lg';
  variant?: 'default' | 'circular' | 'linear';
  editable?: boolean;
  onValueChange?: (value: number) => void;
  onTargetChange?: (target: number) => void;
  className?: string;
  description?: string;
  milestones?: Array<{
    value: number;
    label: string;
    color?: string;
  }>;
}

const colorSchemes = {
  default: {
    progress: '',
    text: 'text-gray-700 dark:text-gray-300',
    accent: 'text-blue-600 dark:text-blue-400'
  },
  purple: {
    progress: '[&>div]:bg-gradient-to-r [&>div]:from-purple-500 [&>div]:to-indigo-500',
    text: 'text-purple-700 dark:text-purple-300',
    accent: 'text-purple-600 dark:text-purple-400'
  },
  blue: {
    progress: '[&>div]:bg-gradient-to-r [&>div]:from-blue-500 [&>div]:to-cyan-500',
    text: 'text-blue-700 dark:text-blue-300',
    accent: 'text-blue-600 dark:text-blue-400'
  },
  green: {
    progress: '[&>div]:bg-gradient-to-r [&>div]:from-green-500 [&>div]:to-emerald-500',
    text: 'text-green-700 dark:text-green-300',
    accent: 'text-green-600 dark:text-green-400'
  },
  pink: {
    progress: '[&>div]:bg-gradient-to-r [&>div]:from-pink-500 [&>div]:to-rose-500',
    text: 'text-pink-700 dark:text-pink-300',
    accent: 'text-pink-600 dark:text-pink-400'
  },
  yellow: {
    progress: '[&>div]:bg-gradient-to-r [&>div]:from-yellow-500 [&>div]:to-amber-500',
    text: 'text-yellow-700 dark:text-yellow-300',
    accent: 'text-yellow-600 dark:text-yellow-400'
  },
  orange: {
    progress: '[&>div]:bg-gradient-to-r [&>div]:from-orange-500 [&>div]:to-red-500',
    text: 'text-orange-700 dark:text-orange-300',
    accent: 'text-orange-600 dark:text-orange-400'
  }
};

const sizeClasses = {
  sm: 'h-1.5',
  md: 'h-2.5',
  lg: 'h-4'
};

export function EditableProgressBar({
  value,
  max = 100,
  min = 0,
  label,
  showValue = true,
  showTarget = false,
  target,
  unit = '%',
  colorScheme = 'default',
  size = 'md',
  variant = 'default',
  editable = false,
  onValueChange,
  onTargetChange,
  className = '',
  description,
  milestones = []
}: EditableProgressBarProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [editValue, setEditValue] = useState(value);
  const [editTarget, setEditTarget] = useState(target || max);

  const scheme = colorSchemes[colorScheme];
  const progressPercentage = ((value - min) / (max - min)) * 100;
  const targetPercentage = target ? ((target - min) / (max - min)) * 100 : undefined;

  const handleSave = () => {
    if (onValueChange) onValueChange(editValue);
    if (onTargetChange && showTarget) onTargetChange(editTarget);
    setIsEditing(false);
  };

  const handleCancel = () => {
    setEditValue(value);
    setEditTarget(target || max);
    setIsEditing(false);
  };

  if (variant === 'circular') {
    const radius = 45;
    const circumference = 2 * Math.PI * radius;
    const strokeDasharray = circumference;
    const strokeDashoffset = circumference - (progressPercentage / 100) * circumference;

    return (
      <div className={`relative ${className}`}>
        <div className="flex items-center justify-center">
          <svg className="w-32 h-32 transform -rotate-90" viewBox="0 0 100 100">
            {/* Background circle */}
            <circle
              cx="50"
              cy="50"
              r={radius}
              stroke="currentColor"
              strokeWidth="8"
              fill="transparent"
              className="text-gray-200 dark:text-gray-700"
            />
            {/* Progress circle */}
            <circle
              cx="50"
              cy="50"
              r={radius}
              stroke="currentColor"
              strokeWidth="8"
              fill="transparent"
              strokeDasharray={strokeDasharray}
              strokeDashoffset={strokeDashoffset}
              className={scheme.accent}
              strokeLinecap="round"
              style={{ transition: 'stroke-dashoffset 0.5s ease-in-out' }}
            />
            {/* Target indicator */}
            {showTarget && target && targetPercentage !== undefined && (
              <circle
                cx="50"
                cy="50"
                r={radius + 2}
                fill="transparent"
                stroke="currentColor"
                strokeWidth="2"
                strokeDasharray="4 4"
                className="text-yellow-500"
                transform={`rotate(${(targetPercentage / 100) * 360 - 90} 50 50)`}
              />
            )}
          </svg>
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center">
              <div className={`text-2xl font-bold ${scheme.text}`}>
                {Math.round(value)}{unit}
              </div>
              {label && (
                <div className="text-sm text-gray-600 dark:text-gray-400">{label}</div>
              )}
            </div>
            {editable && (
              <Button
                variant="ghost"
                size="sm"
                className="absolute top-0 right-0 opacity-0 hover:opacity-100 transition-opacity"
                onClick={() => setIsEditing(true)}
              >
                <Edit3 className="w-3 h-3" />
              </Button>
            )}
          </div>
        </div>
        
        {isEditing && (
          <Dialog open={isEditing} onOpenChange={setIsEditing}>
            <DialogContent className="bg-white/95 dark:bg-gray-900/95 backdrop-blur-xl">
              <DialogHeader>
                <DialogTitle>Edit Progress</DialogTitle>
                <DialogDescription>
                  Adjust the current value and target if needed.
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium">Current Value ({unit})</label>
                  <Slider
                    value={[editValue]}
                    onValueChange={(val) => setEditValue(val[0])}
                    min={min}
                    max={max}
                    step={1}
                    className="mt-2"
                  />
                  <div className="text-center text-sm text-gray-600 dark:text-gray-400 mt-1">
                    {editValue}{unit}
                  </div>
                </div>
                
                {showTarget && (
                  <div>
                    <label className="text-sm font-medium">Target ({unit})</label>
                    <Slider
                      value={[editTarget]}
                      onValueChange={(val) => setEditTarget(val[0])}
                      min={value}
                      max={max}
                      step={1}
                      className="mt-2"
                    />
                    <div className="text-center text-sm text-gray-600 dark:text-gray-400 mt-1">
                      {editTarget}{unit}
                    </div>
                  </div>
                )}
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={handleCancel}>
                  <X className="w-4 h-4 mr-2" />
                  Cancel
                </Button>
                <Button onClick={handleSave}>
                  <Save className="w-4 h-4 mr-2" />
                  Save
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </div>
    );
  }

  return (
    <div className={`space-y-2 ${className}`}>
      {/* Header */}
      <div className="flex items-center justify-between">
        {label && (
          <span className={`text-sm font-medium ${scheme.text}`}>
            {label}
          </span>
        )}
        <div className="flex items-center gap-2">
          {showValue && (
            <span className={`text-sm font-medium ${scheme.accent}`}>
              {Math.round(value)}{unit}
              {showTarget && target && ` / ${target}${unit}`}
            </span>
          )}
          {editable && (
            <Button
              variant="ghost"
              size="sm"
              className="h-6 w-6 p-0 opacity-60 hover:opacity-100 transition-opacity"
              onClick={() => setIsEditing(true)}
            >
              <Edit3 className="w-3 h-3" />
            </Button>
          )}
        </div>
      </div>

      {/* Progress Bar */}
      <div className="relative">
        <Progress
          value={progressPercentage}
          className={`${sizeClasses[size]} ${scheme.progress}`}
        />
        
        {/* Target Indicator */}
        {showTarget && target && targetPercentage !== undefined && (
          <div
            className="absolute top-0 h-full w-0.5 bg-yellow-500 dark:bg-yellow-400"
            style={{ left: `${targetPercentage}%` }}
          >
            <div className="absolute -top-1 -left-1 w-2 h-2 bg-yellow-500 dark:bg-yellow-400 rounded-full" />
          </div>
        )}
        
        {/* Milestones */}
        {milestones.map((milestone, i) => {
          const milestonePercentage = ((milestone.value - min) / (max - min)) * 100;
          return (
            <div
              key={i}
              className="absolute top-0 h-full w-0.5 bg-gray-400 dark:bg-gray-600"
              style={{ left: `${milestonePercentage}%` }}
              title={milestone.label}
            >
              <div className="absolute -top-1 -left-1 w-2 h-2 bg-gray-400 dark:bg-gray-600 rounded-full" />
            </div>
          );
        })}
      </div>

      {/* Description */}
      {description && (
        <p className="text-xs text-gray-600 dark:text-gray-400">
          {description}
        </p>
      )}

      {/* Milestones Legend */}
      {milestones.length > 0 && (
        <div className="flex flex-wrap gap-2 text-xs">
          {milestones.map((milestone, i) => (
            <span
              key={i}
              className="flex items-center gap-1 text-gray-600 dark:text-gray-400"
            >
              <div className={`w-2 h-2 rounded-full ${milestone.color || 'bg-gray-400'}`} />
              {milestone.label}
            </span>
          ))}
        </div>
      )}

      {/* Edit Dialog */}
      {isEditing && (
        <Dialog open={isEditing} onOpenChange={setIsEditing}>
          <DialogContent className="bg-white/95 dark:bg-gray-900/95 backdrop-blur-xl">
            <DialogHeader>
              <DialogTitle>Edit Progress</DialogTitle>
              <DialogDescription>
                Adjust the current value and target if needed.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium">Current Value ({unit})</label>
                <Slider
                  value={[editValue]}
                  onValueChange={(val) => setEditValue(val[0])}
                  min={min}
                  max={max}
                  step={1}
                  className="mt-2"
                />
                <div className="text-center text-sm text-gray-600 dark:text-gray-400 mt-1">
                  {editValue}{unit}
                </div>
              </div>
              
              {showTarget && (
                <div>
                  <label className="text-sm font-medium">Target ({unit})</label>
                  <Slider
                    value={[editTarget]}
                    onValueChange={(val) => setEditTarget(val[0])}
                    min={value}
                    max={max}
                    step={1}
                    className="mt-2"
                  />
                  <div className="text-center text-sm text-gray-600 dark:text-gray-400 mt-1">
                    {editTarget}{unit}
                  </div>
                </div>
              )}
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={handleCancel}>
                <X className="w-4 h-4 mr-2" />
                Cancel
              </Button>
              <Button onClick={handleSave}>
                <Save className="w-4 h-4 mr-2" />
                Save
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}