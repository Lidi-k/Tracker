import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Progress } from '../ui/progress';
import { Input } from '../ui/input';
import { Textarea } from '../ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { MoreVertical, Edit3, Trash2, Plus, Save, X } from 'lucide-react';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '../ui/dropdown-menu';

interface EditableCardProps {
  variant?: 'default' | 'compact' | 'detailed';
  colorScheme?: 'purple' | 'blue' | 'green' | 'pink' | 'yellow' | 'orange';
  title: string;
  subtitle?: string;
  description?: string;
  progress?: number;
  badges?: Array<{
    text: string;
    variant?: 'default' | 'secondary' | 'destructive' | 'outline';
    color?: string;
  }>;
  metadata?: Array<{
    label: string;
    value: string;
  }>;
  actions?: Array<{
    label: string;
    onClick: () => void;
    icon?: React.ReactNode;
    variant?: 'default' | 'secondary' | 'destructive';
  }>;
  onEdit?: (data: any) => void;
  onDelete?: () => void;
  editFields?: Array<{
    key: string;
    label: string;
    type: 'text' | 'textarea' | 'select' | 'number' | 'date' | 'progress';
    options?: string[];
    placeholder?: string;
  }>;
  data?: any;
  showProgressBar?: boolean;
  customContent?: React.ReactNode;
  className?: string;
}

const colorSchemes = {
  purple: {
    background: 'bg-gradient-to-br from-purple-50/70 to-indigo-50/70 dark:from-purple-950/30 dark:to-indigo-950/30',
    border: 'border-purple-200/50 dark:border-purple-700/30',
    text: 'text-purple-800 dark:text-purple-300',
    badge: 'bg-purple-100 text-purple-700 border-purple-200 dark:bg-purple-900/30 dark:text-purple-300 dark:border-purple-700/30'
  },
  blue: {
    background: 'bg-gradient-to-br from-blue-50/70 to-cyan-50/70 dark:from-blue-950/30 dark:to-cyan-950/30',
    border: 'border-blue-200/50 dark:border-blue-700/30',
    text: 'text-blue-800 dark:text-blue-300',
    badge: 'bg-blue-100 text-blue-700 border-blue-200 dark:bg-blue-900/30 dark:text-blue-300 dark:border-blue-700/30'
  },
  green: {
    background: 'bg-gradient-to-br from-green-50/70 to-emerald-50/70 dark:from-green-950/30 dark:to-emerald-950/30',
    border: 'border-green-200/50 dark:border-green-700/30',
    text: 'text-green-800 dark:text-green-300',
    badge: 'bg-green-100 text-green-700 border-green-200 dark:bg-green-900/30 dark:text-green-300 dark:border-green-700/30'
  },
  pink: {
    background: 'bg-gradient-to-br from-pink-50/70 to-rose-50/70 dark:from-pink-950/30 dark:to-rose-950/30',
    border: 'border-pink-200/50 dark:border-pink-700/30',
    text: 'text-pink-800 dark:text-pink-300',
    badge: 'bg-pink-100 text-pink-700 border-pink-200 dark:bg-pink-900/30 dark:text-pink-300 dark:border-pink-700/30'
  },
  yellow: {
    background: 'bg-gradient-to-br from-yellow-50/70 to-amber-50/70 dark:from-yellow-950/30 dark:to-amber-950/30',
    border: 'border-yellow-200/50 dark:border-yellow-700/30',
    text: 'text-yellow-800 dark:text-yellow-300',
    badge: 'bg-yellow-100 text-yellow-700 border-yellow-200 dark:bg-yellow-900/30 dark:text-yellow-300 dark:border-yellow-700/30'
  },
  orange: {
    background: 'bg-gradient-to-br from-orange-50/70 to-red-50/70 dark:from-orange-950/30 dark:to-red-950/30',
    border: 'border-orange-200/50 dark:border-orange-700/30',
    text: 'text-orange-800 dark:text-orange-300',
    badge: 'bg-orange-100 text-orange-700 border-orange-200 dark:bg-orange-900/30 dark:text-orange-300 dark:border-orange-700/30'
  }
};

export function EditableCard({
  variant = 'default',
  colorScheme = 'purple',
  title,
  subtitle,
  description,
  progress,
  badges = [],
  metadata = [],
  actions = [],
  onEdit,
  onDelete,
  editFields = [],
  data = {},
  showProgressBar = false,
  customContent,
  className = ''
}: EditableCardProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [editData, setEditData] = useState(data);
  const [showEditDialog, setShowEditDialog] = useState(false);

  const scheme = colorSchemes[colorScheme];

  const handleEdit = () => {
    if (onEdit) {
      onEdit(editData);
    }
    setIsEditing(false);
    setShowEditDialog(false);
  };

  const handleFieldChange = (key: string, value: any) => {
    setEditData(prev => ({ ...prev, [key]: value }));
  };

  const renderEditField = (field: any) => {
    const value = editData[field.key] || '';
    
    switch (field.type) {
      case 'textarea':
        return (
          <Textarea
            value={value}
            onChange={(e) => handleFieldChange(field.key, e.target.value)}
            placeholder={field.placeholder}
            rows={3}
          />
        );
      case 'select':
        return (
          <Select value={value} onValueChange={(val) => handleFieldChange(field.key, val)}>
            <SelectTrigger>
              <SelectValue placeholder={field.placeholder} />
            </SelectTrigger>
            <SelectContent>
              {field.options?.map(option => (
                <SelectItem key={option} value={option}>{option}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        );
      case 'number':
        return (
          <Input
            type="number"
            value={value}
            onChange={(e) => handleFieldChange(field.key, parseInt(e.target.value) || 0)}
            placeholder={field.placeholder}
          />
        );
      case 'progress':
        return (
          <div className="space-y-2">
            <Input
              type="range"
              min="0"
              max="100"
              value={value}
              onChange={(e) => handleFieldChange(field.key, parseInt(e.target.value))}
              className="w-full"
            />
            <div className="text-sm text-center text-gray-600 dark:text-gray-400">{value}%</div>
          </div>
        );
      case 'date':
        return (
          <Input
            type="date"
            value={value}
            onChange={(e) => handleFieldChange(field.key, e.target.value)}
          />
        );
      default:
        return (
          <Input
            value={value}
            onChange={(e) => handleFieldChange(field.key, e.target.value)}
            placeholder={field.placeholder}
          />
        );
    }
  };

  return (
    <Card className={`${scheme.background} ${scheme.border} backdrop-blur-sm group transition-all duration-300 hover:shadow-lg hover:scale-[1.02] ${className}`}>
      <CardHeader className={variant === 'compact' ? 'pb-2' : ''}>
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <CardTitle className={`${scheme.text} ${variant === 'compact' ? 'text-lg' : 'text-xl'}`}>
              {title}
            </CardTitle>
            {subtitle && (
              <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                {subtitle}
              </p>
            )}
          </div>
          
          {/* Actions Menu */}
          {(onEdit || onDelete || actions.length > 0) && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  size="sm"
                  className="opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <MoreVertical className="w-4 h-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                {onEdit && (
                  <DropdownMenuItem onClick={() => setShowEditDialog(true)}>
                    <Edit3 className="w-4 h-4 mr-2" />
                    Edit
                  </DropdownMenuItem>
                )}
                {actions.map((action, i) => (
                  <DropdownMenuItem key={i} onClick={action.onClick}>
                    {action.icon && <span className="w-4 h-4 mr-2">{action.icon}</span>}
                    {action.label}
                  </DropdownMenuItem>
                ))}
                {onDelete && (
                  <DropdownMenuItem onClick={onDelete} className="text-red-600 dark:text-red-400">
                    <Trash2 className="w-4 h-4 mr-2" />
                    Delete
                  </DropdownMenuItem>
                )}
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </div>
        
        {/* Badges */}
        {badges.length > 0 && (
          <div className="flex flex-wrap gap-2 mt-2">
            {badges.map((badge, i) => (
              <Badge
                key={i}
                variant={badge.variant || 'outline'}
                className={badge.color || scheme.badge}
              >
                {badge.text}
              </Badge>
            ))}
          </div>
        )}
      </CardHeader>
      
      <CardContent className="space-y-4">
        {/* Description */}
        {description && (
          <p className="text-sm text-gray-600 dark:text-gray-400">
            {description}
          </p>
        )}
        
        {/* Progress Bar */}
        {(showProgressBar && progress !== undefined) && (
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-gray-600 dark:text-gray-400">Progress</span>
              <span className={`font-medium ${scheme.text}`}>{progress}%</span>
            </div>
            <Progress value={progress} className="h-2" />
          </div>
        )}
        
        {/* Metadata */}
        {metadata.length > 0 && (
          <div className="grid grid-cols-2 gap-4 text-sm">
            {metadata.map((item, i) => (
              <div key={i}>
                <span className="font-medium text-gray-700 dark:text-gray-300">{item.label}: </span>
                <span className="text-gray-600 dark:text-gray-400">{item.value}</span>
              </div>
            ))}
          </div>
        )}
        
        {/* Custom Content */}
        {customContent}
      </CardContent>

      {/* Edit Dialog */}
      {onEdit && editFields.length > 0 && (
        <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
          <DialogContent className="bg-white/95 dark:bg-gray-900/95 backdrop-blur-xl max-w-2xl">
            <DialogHeader>
              <DialogTitle>Edit {title}</DialogTitle>
              <DialogDescription>
                Make changes to your item. Click save when you're done.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 max-h-96 overflow-y-auto">
              {editFields.map(field => (
                <div key={field.key} className="space-y-2">
                  <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    {field.label}
                  </label>
                  {renderEditField(field)}
                </div>
              ))}
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setShowEditDialog(false)}>
                <X className="w-4 h-4 mr-2" />
                Cancel
              </Button>
              <Button onClick={handleEdit}>
                <Save className="w-4 h-4 mr-2" />
                Save Changes
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </Card>
  );
}