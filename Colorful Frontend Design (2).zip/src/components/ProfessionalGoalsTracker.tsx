import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "./ui/dialog";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Separator } from "./ui/separator";
import { 
  Target, 
  Trophy, 
  BookOpen, 
  GraduationCap,
  Plus,
  TrendingUp,
  Award,
  Users,
  Briefcase
} from "lucide-react";
import { usePlanner } from "../contexts/PlannerContext";
import { EditableCard } from "./common/EditableCard";
import { EditableProgressBar } from "./common/EditableProgressBar";

export function ProfessionalGoalsTracker() {
  const {
    skills,
    projects,
    certifications,
    careerGoals,
    addSkill,
    updateSkill,
    deleteSkill,
    addProject,
    updateProject,
    deleteProject,
    addCertification,
    updateCertification,
    deleteCertification,
    addCareerGoal,
    updateCareerGoal,
    deleteCareerGoal
  } = usePlanner();

  const [showSkillDialog, setShowSkillDialog] = useState(false);
  const [showProjectDialog, setShowProjectDialog] = useState(false);
  const [showCertDialog, setShowCertDialog] = useState(false);
  const [showGoalDialog, setShowGoalDialog] = useState(false);

  // Form states
  const [newSkill, setNewSkill] = useState({
    name: '',
    category: 'Technical',
    proficiency: 50,
    status: 'learning' as const,
    priority: 'medium' as const,
    description: '',
    targetProficiency: 90
  });

  const [newProject, setNewProject] = useState({
    title: '',
    status: 'planned' as const,
    date: '',
    course: '',
    skills: [] as string[],
    impact: '',
    lessons: '',
    category: 'Academic',
    progress: 0
  });

  const [newCertification, setNewCertification] = useState({
    name: '',
    provider: '',
    status: 'planned' as const,
    priority: 'medium' as const,
    relevance: '',
    cost: 0,
    url: ''
  });

  const [newGoal, setNewGoal] = useState({
    title: '',
    description: '',
    targetDate: '',
    progress: 0,
    milestones: [] as string[],
    category: 'Career Development',
    priority: 'medium' as const,
    status: 'active' as const
  });

  const resetForms = () => {
    setNewSkill({
      name: '',
      category: 'Technical',
      proficiency: 50,
      status: 'learning',
      priority: 'medium',
      description: '',
      targetProficiency: 90
    });
    setNewProject({
      title: '',
      status: 'planned',
      date: '',
      course: '',
      skills: [],
      impact: '',
      lessons: '',
      category: 'Academic',
      progress: 0
    });
    setNewCertification({
      name: '',
      provider: '',
      status: 'planned',
      priority: 'medium',
      relevance: '',
      cost: 0,
      url: ''
    });
    setNewGoal({
      title: '',
      description: '',
      targetDate: '',
      progress: 0,
      milestones: [],
      category: 'Career Development',
      priority: 'medium',
      status: 'active'
    });
  };

  const handleAddSkill = () => {
    if (newSkill.name.trim()) {
      addSkill(newSkill);
      resetForms();
      setShowSkillDialog(false);
    }
  };

  const handleAddProject = () => {
    if (newProject.title.trim()) {
      addProject(newProject);
      resetForms();
      setShowProjectDialog(false);
    }
  };

  const handleAddCertification = () => {
    if (newCertification.name.trim()) {
      addCertification(newCertification);
      resetForms();
      setShowCertDialog(false);
    }
  };

  const handleAddGoal = () => {
    if (newGoal.title.trim()) {
      addCareerGoal(newGoal);
      resetForms();
      setShowGoalDialog(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return { text: 'Completed', color: 'bg-green-100 text-green-700 border-green-200 dark:bg-green-900/30 dark:text-green-300 dark:border-green-700/30' };
      case 'in-progress': return { text: 'In Progress', color: 'bg-blue-100 text-blue-700 border-blue-200 dark:bg-blue-900/30 dark:text-blue-300 dark:border-blue-700/30' };
      case 'planned': return { text: 'Planned', color: 'bg-yellow-100 text-yellow-700 border-yellow-200 dark:bg-yellow-900/30 dark:text-yellow-300 dark:border-yellow-700/30' };
      case 'learning': return { text: 'Learning', color: 'bg-purple-100 text-purple-700 border-purple-200 dark:bg-purple-900/30 dark:text-purple-300 dark:border-purple-700/30' };
      case 'intermediate': return { text: 'Intermediate', color: 'bg-blue-100 text-blue-700 border-blue-200 dark:bg-blue-900/30 dark:text-blue-300 dark:border-blue-700/30' };
      case 'advanced': return { text: 'Advanced', color: 'bg-green-100 text-green-700 border-green-200 dark:bg-green-900/30 dark:text-green-300 dark:border-green-700/30' };
      case 'expert': return { text: 'Expert', color: 'bg-purple-100 text-purple-700 border-purple-200 dark:bg-purple-900/30 dark:text-purple-300 dark:border-purple-700/30' };
      case 'active': return { text: 'Active', color: 'bg-green-100 text-green-700 border-green-200 dark:bg-green-900/30 dark:text-green-300 dark:border-green-700/30' };
      case 'paused': return { text: 'Paused', color: 'bg-gray-100 text-gray-700 border-gray-200 dark:bg-gray-900/30 dark:text-gray-300 dark:border-gray-700/30' };
      default: return { text: status, color: 'bg-gray-100 text-gray-700 border-gray-200 dark:bg-gray-900/30 dark:text-gray-300 dark:border-gray-700/30' };
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return { text: 'High', color: 'bg-red-100 text-red-700 border-red-200 dark:bg-red-900/30 dark:text-red-300 dark:border-red-700/30' };
      case 'medium': return { text: 'Medium', color: 'bg-yellow-100 text-yellow-700 border-yellow-200 dark:bg-yellow-900/30 dark:text-yellow-300 dark:border-yellow-700/30' };
      case 'low': return { text: 'Low', color: 'bg-green-100 text-green-700 border-green-200 dark:bg-green-900/30 dark:text-green-300 dark:border-green-700/30' };
      default: return { text: priority, color: 'bg-gray-100 text-gray-700 border-gray-200 dark:bg-gray-900/30 dark:text-gray-300 dark:border-gray-700/30' };
    }
  };

  // Calculate statistics
  const completedProjects = projects.filter(p => p.status === 'completed').length;
  const completedCerts = certifications.filter(c => c.status === 'completed').length;
  const avgGoalProgress = careerGoals.length > 0 
    ? Math.round(careerGoals.reduce((acc, goal) => acc + goal.progress, 0) / careerGoals.length)
    : 0;

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 via-pink-600 to-blue-600 dark:from-purple-400 dark:via-pink-400 dark:to-blue-400 bg-clip-text text-transparent">
          Professional Goals & Achievement Tracker
        </h1>
        <p className="text-lg text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
          Track your skills development, project accomplishments, certifications, and career milestones with full editing capabilities
        </p>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-950/30 dark:to-purple-900/30 border-purple-200/50 dark:border-purple-700/30">
          <CardContent className="p-4 text-center">
            <Target className="w-8 h-8 mx-auto mb-2 text-purple-600 dark:text-purple-400" />
            <div className="text-2xl font-bold text-purple-700 dark:text-purple-300">{skills.length}</div>
            <div className="text-sm text-purple-600 dark:text-purple-400">Skills Tracked</div>
          </CardContent>
        </Card>
        
        <Card className="bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-950/30 dark:to-blue-900/30 border-blue-200/50 dark:border-blue-700/30">
          <CardContent className="p-4 text-center">
            <Trophy className="w-8 h-8 mx-auto mb-2 text-blue-600 dark:text-blue-400" />
            <div className="text-2xl font-bold text-blue-700 dark:text-blue-300">{completedProjects}</div>
            <div className="text-sm text-blue-600 dark:text-blue-400">Projects Done</div>
          </CardContent>
        </Card>
        
        <Card className="bg-gradient-to-br from-green-50 to-green-100 dark:from-green-950/30 dark:to-green-900/30 border-green-200/50 dark:border-green-700/30">
          <CardContent className="p-4 text-center">
            <Award className="w-8 h-8 mx-auto mb-2 text-green-600 dark:text-green-400" />
            <div className="text-2xl font-bold text-green-700 dark:text-green-300">{completedCerts}</div>
            <div className="text-sm text-green-600 dark:text-green-400">Certifications</div>
          </CardContent>
        </Card>
        
        <Card className="bg-gradient-to-br from-pink-50 to-pink-100 dark:from-pink-950/30 dark:to-pink-900/30 border-pink-200/50 dark:border-pink-700/30">
          <CardContent className="p-4 text-center">
            <TrendingUp className="w-8 h-8 mx-auto mb-2 text-pink-600 dark:text-pink-400" />
            <div className="text-2xl font-bold text-pink-700 dark:text-pink-300">{avgGoalProgress}%</div>
            <div className="text-sm text-pink-600 dark:text-pink-400">Avg Goal Progress</div>
          </CardContent>
        </Card>
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        {/* Skills Development */}
        <Card className="bg-gradient-to-br from-purple-50/70 to-indigo-50/70 dark:from-purple-950/30 dark:to-indigo-950/30 border-purple-200/50 dark:border-purple-700/30 backdrop-blur-sm">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2 text-purple-800 dark:text-purple-300">
                <Target className="w-5 h-5" />
                Skills Development
              </CardTitle>
              <Dialog open={showSkillDialog} onOpenChange={setShowSkillDialog}>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm" className="bg-white/50 dark:bg-gray-800/50">
                    <Plus className="w-4 h-4 mr-1" />
                    Add Skill
                  </Button>
                </DialogTrigger>
                <DialogContent className="bg-white/95 dark:bg-gray-900/95 backdrop-blur-xl max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>Add New Skill</DialogTitle>
                    <DialogDescription>
                      Add a skill you want to track and develop over time.
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="text-sm font-medium">Skill Name</label>
                        <Input
                          value={newSkill.name}
                          onChange={(e) => setNewSkill(prev => ({ ...prev, name: e.target.value }))}
                          placeholder="e.g., Python, SQL, Public Speaking"
                        />
                      </div>
                      <div>
                        <label className="text-sm font-medium">Category</label>
                        <Select value={newSkill.category} onValueChange={(val) => setNewSkill(prev => ({ ...prev, category: val }))}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Technical">Technical</SelectItem>
                            <SelectItem value="Domain">Domain</SelectItem>
                            <SelectItem value="Professional">Professional</SelectItem>
                            <SelectItem value="Leadership">Leadership</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-3 gap-4">
                      <div>
                        <label className="text-sm font-medium">Current Level</label>
                        <Select value={newSkill.status} onValueChange={(val: any) => setNewSkill(prev => ({ ...prev, status: val }))}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="learning">Learning</SelectItem>
                            <SelectItem value="intermediate">Intermediate</SelectItem>
                            <SelectItem value="advanced">Advanced</SelectItem>
                            <SelectItem value="expert">Expert</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <label className="text-sm font-medium">Priority</label>
                        <Select value={newSkill.priority} onValueChange={(val: any) => setNewSkill(prev => ({ ...prev, priority: val }))}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="high">High</SelectItem>
                            <SelectItem value="medium">Medium</SelectItem>
                            <SelectItem value="low">Low</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <label className="text-sm font-medium">Current Proficiency (%)</label>
                        <Input
                          type="number"
                          min="0"
                          max="100"
                          value={newSkill.proficiency}
                          onChange={(e) => setNewSkill(prev => ({ ...prev, proficiency: parseInt(e.target.value) || 0 }))}
                        />
                      </div>
                    </div>
                    
                    <div>
                      <label className="text-sm font-medium">Target Proficiency (%)</label>
                      <Input
                        type="number"
                        min="0"
                        max="100"
                        value={newSkill.targetProficiency}
                        onChange={(e) => setNewSkill(prev => ({ ...prev, targetProficiency: parseInt(e.target.value) || 90 }))}
                      />
                    </div>
                    
                    <div>
                      <label className="text-sm font-medium">Description (Optional)</label>
                      <Textarea
                        value={newSkill.description}
                        onChange={(e) => setNewSkill(prev => ({ ...prev, description: e.target.value }))}
                        placeholder="Why is this skill important for your goals?"
                        rows={2}
                      />
                    </div>
                  </div>
                  <div className="flex justify-end gap-2">
                    <Button variant="outline" onClick={() => setShowSkillDialog(false)}>
                      Cancel
                    </Button>
                    <Button onClick={handleAddSkill}>
                      Add Skill
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {skills.map(skill => {
                const statusInfo = getStatusColor(skill.status);
                const priorityInfo = getPriorityColor(skill.priority);
                
                return (
                  <EditableCard
                    key={skill.id}
                    variant="compact"
                    colorScheme="purple"
                    title={skill.name}
                    subtitle={skill.category}
                    description={skill.description}
                    badges={[
                      { text: statusInfo.text, color: statusInfo.color },
                      { text: priorityInfo.text, color: priorityInfo.color }
                    ]}
                    showProgressBar={true}
                    progress={skill.proficiency}
                    customContent={
                      <EditableProgressBar
                        value={skill.proficiency}
                        target={skill.targetProficiency}
                        showTarget={true}
                        colorScheme="purple"
                        editable={true}
                        onValueChange={(value) => updateSkill(skill.id, { proficiency: value })}
                        onTargetChange={(target) => updateSkill(skill.id, { targetProficiency: target })}
                      />
                    }
                    onEdit={(data) => updateSkill(skill.id, data)}
                    onDelete={() => deleteSkill(skill.id)}
                    editFields={[
                      { key: 'name', label: 'Skill Name', type: 'text', placeholder: 'Skill name' },
                      { key: 'category', label: 'Category', type: 'select', options: ['Technical', 'Domain', 'Professional', 'Leadership'] },
                      { key: 'status', label: 'Current Level', type: 'select', options: ['learning', 'intermediate', 'advanced', 'expert'] },
                      { key: 'priority', label: 'Priority', type: 'select', options: ['high', 'medium', 'low'] },
                      { key: 'proficiency', label: 'Current Proficiency (%)', type: 'progress' },
                      { key: 'targetProficiency', label: 'Target Proficiency (%)', type: 'number' },
                      { key: 'description', label: 'Description', type: 'textarea', placeholder: 'Why is this skill important?' }
                    ]}
                    data={skill}
                  />
                );
              })}
              
              {skills.length === 0 && (
                <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                  <Target className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>No skills tracked yet. Add your first skill to get started!</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Career Goals */}
        <Card className="bg-gradient-to-br from-pink-50/70 to-rose-50/70 dark:from-pink-950/30 dark:to-rose-950/30 border-pink-200/50 dark:border-pink-700/30 backdrop-blur-sm">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2 text-pink-800 dark:text-pink-300">
                <Briefcase className="w-5 h-5" />
                Career Goals
              </CardTitle>
              <Dialog open={showGoalDialog} onOpenChange={setShowGoalDialog}>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm" className="bg-white/50 dark:bg-gray-800/50">
                    <Plus className="w-4 h-4 mr-1" />
                    Add Goal
                  </Button>
                </DialogTrigger>
                <DialogContent className="bg-white/95 dark:bg-gray-900/95 backdrop-blur-xl max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>Add Career Goal</DialogTitle>
                    <DialogDescription>
                      Set a new career milestone to work towards.
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <label className="text-sm font-medium">Goal Title</label>
                      <Input
                        value={newGoal.title}
                        onChange={(e) => setNewGoal(prev => ({ ...prev, title: e.target.value }))}
                        placeholder="e.g., Secure CDC Fellowship"
                      />
                    </div>
                    
                    <div>
                      <label className="text-sm font-medium">Description</label>
                      <Textarea
                        value={newGoal.description}
                        onChange={(e) => setNewGoal(prev => ({ ...prev, description: e.target.value }))}
                        placeholder="Detailed description of the goal"
                        rows={3}
                      />
                    </div>
                    
                    <div className="grid grid-cols-3 gap-4">
                      <div>
                        <label className="text-sm font-medium">Target Date</label>
                        <Input
                          type="date"
                          value={newGoal.targetDate}
                          onChange={(e) => setNewGoal(prev => ({ ...prev, targetDate: e.target.value }))}
                        />
                      </div>
                      <div>
                        <label className="text-sm font-medium">Priority</label>
                        <Select value={newGoal.priority} onValueChange={(val: any) => setNewGoal(prev => ({ ...prev, priority: val }))}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="high">High</SelectItem>
                            <SelectItem value="medium">Medium</SelectItem>
                            <SelectItem value="low">Low</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <label className="text-sm font-medium">Current Progress (%)</label>
                        <Input
                          type="number"
                          min="0"
                          max="100"
                          value={newGoal.progress}
                          onChange={(e) => setNewGoal(prev => ({ ...prev, progress: parseInt(e.target.value) || 0 }))}
                        />
                      </div>
                    </div>
                    
                    <div>
                      <label className="text-sm font-medium">Category</label>
                      <Select value={newGoal.category} onValueChange={(val) => setNewGoal(prev => ({ ...prev, category: val }))}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Career Development">Career Development</SelectItem>
                          <SelectItem value="Academic">Academic</SelectItem>
                          <SelectItem value="Research">Research</SelectItem>
                          <SelectItem value="Networking">Networking</SelectItem>
                          <SelectItem value="Skills">Skills</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="flex justify-end gap-2">
                    <Button variant="outline" onClick={() => setShowGoalDialog(false)}>
                      Cancel
                    </Button>
                    <Button onClick={handleAddGoal}>
                      Add Goal
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {careerGoals.map(goal => {
                const statusInfo = getStatusColor(goal.status);
                const priorityInfo = getPriorityColor(goal.priority);
                
                return (
                  <EditableCard
                    key={goal.id}
                    variant="detailed"
                    colorScheme="pink"
                    title={goal.title}
                    subtitle={`Target: ${goal.targetDate} • ${goal.category}`}
                    description={goal.description}
                    badges={[
                      { text: statusInfo.text, color: statusInfo.color },
                      { text: priorityInfo.text, color: priorityInfo.color }
                    ]}
                    showProgressBar={true}
                    progress={goal.progress}
                    customContent={
                      <div className="space-y-3">
                        <EditableProgressBar
                          value={goal.progress}
                          label="Overall Progress"
                          colorScheme="pink"
                          editable={true}
                          onValueChange={(value) => updateCareerGoal(goal.id, { progress: value })}
                        />
                        {goal.milestones.length > 0 && (
                          <div>
                            <p className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Milestones:</p>
                            <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                              {goal.milestones.map((milestone, i) => (
                                <li key={i} className="flex items-center gap-2">
                                  <span className="w-1.5 h-1.5 bg-pink-500 rounded-full flex-shrink-0"></span>
                                  {milestone}
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>
                    }
                    onEdit={(data) => updateCareerGoal(goal.id, data)}
                    onDelete={() => deleteCareerGoal(goal.id)}
                    editFields={[
                      { key: 'title', label: 'Goal Title', type: 'text', placeholder: 'Goal title' },
                      { key: 'description', label: 'Description', type: 'textarea', placeholder: 'Detailed description' },
                      { key: 'targetDate', label: 'Target Date', type: 'date' },
                      { key: 'category', label: 'Category', type: 'select', options: ['Career Development', 'Academic', 'Research', 'Networking', 'Skills'] },
                      { key: 'priority', label: 'Priority', type: 'select', options: ['high', 'medium', 'low'] },
                      { key: 'progress', label: 'Progress (%)', type: 'progress' },
                      { key: 'status', label: 'Status', type: 'select', options: ['active', 'completed', 'paused'] }
                    ]}
                    data={goal}
                  />
                );
              })}
              
              {careerGoals.length === 0 && (
                <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                  <Briefcase className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>No career goals set yet. Add your first goal to start tracking!</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Rest of sections can be similarly updated... */}
      {/* For brevity, I'll continue with a simplified version */}
      
      <Separator className="my-8" />
      
      {/* Professional Development Action Plan */}
      <Card className="bg-gradient-to-r from-yellow-50/70 via-orange-50/70 to-red-50/70 dark:from-yellow-950/20 dark:via-orange-950/20 dark:to-red-950/20 border-yellow-200/50 dark:border-yellow-700/30 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="text-center text-yellow-800 dark:text-yellow-300">
            Professional Development Action Plan
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="text-center space-y-3">
              <Users className="w-12 h-12 mx-auto text-yellow-600 dark:text-yellow-400" />
              <h3 className="font-semibold text-yellow-800 dark:text-yellow-300">Networking Goals</h3>
              <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                <li>• Attend 2+ conferences per semester</li>
                <li>• Conduct 5+ informational interviews</li>
                <li>• Join 3+ professional organizations</li>
                <li>• Build LinkedIn network to 500+ connections</li>
              </ul>
            </div>
            
            <div className="text-center space-y-3">
              <Target className="w-12 h-12 mx-auto text-orange-600 dark:text-orange-400" />
              <h3 className="font-semibold text-orange-800 dark:text-orange-300">Skill Development</h3>
              <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                <li>• Master Python for public health data</li>
                <li>• Complete advanced statistics training</li>
                <li>• Develop grant writing portfolio</li>
                <li>• Improve public speaking confidence</li>
              </ul>
            </div>
            
            <div className="text-center space-y-3">
              <Briefcase className="w-12 h-12 mx-auto text-red-600 dark:text-red-400" />
              <h3 className="font-semibold text-red-800 dark:text-red-300">Career Preparation</h3>
              <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                <li>• Complete competitive APE placement</li>
                <li>• Publish first-author research paper</li>
                <li>• Secure CDC PHIFP fellowship</li>
                <li>• Build professional portfolio</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}