import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Checkbox } from "./ui/checkbox";
import { Calendar, Clock, BookOpen, FileText, PenTool, Users, AlertCircle, Plus } from "lucide-react";
import { Button } from "./ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { AddTaskModal, BasicTask } from "./AddTaskModal";

interface AcademicTask {
  due_date: string;
  course: string;
  assignment: string;
  type: string;
  description: string;
  completed?: boolean;
}

export function AcademicTasks() {
  const [tasks, setTasks] = useState<AcademicTask[]>([
    {
      due_date: "2025-09-14",
      course: "HPAM7700E Leadership Mgmt of PH Org NGO",
      assignment: "Module 03 Journal Entry (Journal 02)",
      type: "Journal",
      description: "Complete two free EQ assessments, compare results, discuss EQ & leadership, identify strengths and growth opportunities.",
      completed: false
    },
    {
      due_date: "2025-09-17",
      course: "DMAN7100E Intro to Disaster Management",
      assignment: "Exam 01",
      type: "Exam",
      description: "Covers Modules 1–4. 25 MCQs, 5 short answers, 2 essays. 2-hour limit, requires LockDown Browser.",
      completed: false
    },
    {
      due_date: "2025-09-21",
      course: "HPAM7700E Leadership Mgmt of PH Org NGO",
      assignment: "Module 05 Journal Entry (Journal 03)",
      type: "Journal",
      description: "Reflect on leadership models/theories from Modules 4–5, case studies, and role models.",
      completed: false
    },
    {
      due_date: "2025-09-21",
      course: "DMAN7100E Intro to Disaster Management",
      assignment: "County Assessment (Module 02)",
      type: "Group Project",
      description: "Assess assigned county needs using metrics (population, health, infrastructure, etc.).",
      completed: false
    },
    {
      due_date: "2025-09-21",
      course: "DMAN7100E Intro to Disaster Management",
      assignment: "Hazard Vulnerability Analysis (Module 04)",
      type: "Group Project",
      description: "Conduct HVA with 5 natural, 3 technological, and 2 terrorism hazards.",
      completed: false
    },
    {
      due_date: "2025-09-21",
      course: "DMAN7100E Intro to Disaster Management",
      assignment: "Personal Hazard Vulnerability Analysis (Module 04)",
      type: "Individual Assignment",
      description: "Submit personal HVA as instructed in Module 04.",
      completed: false
    },
    {
      due_date: "2025-10-05",
      course: "HPAM7700E Leadership Mgmt of PH Org NGO",
      assignment: "Case Study 02 – Change Leadership",
      type: "Case Study",
      description: "Analyze BUILD Health Challenge: problem ID, environmental context, partners, implementation challenges, CHWs, systems change vs. service delivery.",
      completed: false
    },
    {
      due_date: "2025-10-12",
      course: "HPAM7700E Leadership Mgmt of PH Org NGO",  
      assignment: "Module 07 Journal Entry (Journal 04)",
      type: "Journal",
      description: "Reflect on DEI mistakes, personal experience, inclusive role models, and application to leadership practice.",
      completed: false
    },
    {
      due_date: "2025-10-15",
      course: "DMAN7100E Intro to Disaster Management",
      assignment: "Exam 02",
      type: "Exam",
      description: "Covers Modules 5–7. 2-hour exam, requires LockDown Browser.",
      completed: false
    },
    {
      due_date: "2025-10-19",
      course: "HPAM7700E Leadership Mgmt of PH Org NGO",
      assignment: "Module 08 Journal Entry (Journal 05)",
      type: "Journal",
      description: "Conflict management: respond to case, assess style, identify strengths/growth opportunities.",
      completed: false
    },
    {
      due_date: "2025-10-19",
      course: "DMAN7100E Intro to Disaster Management",
      assignment: "Communication Hub Framework (Module 06)",
      type: "Assignment",
      description: "Apply framework to county EMA, identify 5+ organizations/liaisons to reach vulnerable populations.",
      completed: false
    },
    {
      due_date: "2025-10-19",
      course: "DMAN7100E Intro to Disaster Management",
      assignment: "County Event Action Plan (Module 07)",
      type: "Group Project",
      description: "Prepare EAP for assigned county event using provided template.",
      completed: false
    },
    {
      due_date: "2025-10-26",
      course: "HPAM7700E Leadership Mgmt of PH Org NGO",
      assignment: "Module 09 Journal Entry (Journal 06)",
      type: "Journal",
      description: "Pick one cross-cutting teamwork concept, reflect on benefits/challenges, and leadership integration.",
      completed: false
    },
    {
      due_date: "2025-10-29",
      course: "DMAN7100E Intro to Disaster Management",
      assignment: "ESF Individual Work (Module 09)",
      type: "Individual Assignment",
      description: "Complete assignment as outlined in Module 09.",
      completed: false
    },
    {
      due_date: "2025-11-02",
      course: "DMAN7100E Intro to Disaster Management",
      assignment: "ESF Group Work (Module 09)",
      type: "Group Project",
      description: "Collaborative ESF assignment per Module 09 requirements.",
      completed: false
    },
    {
      due_date: "2025-11-09",
      course: "HPAM7700E Leadership Mgmt of PH Org NGO",
      assignment: "Case Study 03 – Childhood Vaccine Requirements",
      type: "Case Study",
      description: "Analyze vaccine policy case in GA using persuasion matrix, opposition analysis, moral framing, systems-focused messaging, and empathy.",
      completed: false
    },
    {
      due_date: "2025-11-23",
      course: "DMAN7100E Intro to Disaster Management",
      assignment: "Continuity of Operations Plan (Module 10)",
      type: "Group Project",
      description: "Develop COOP for county: key staff, essential functions, comms plan across safety, health, utilities, food, and education.",
      completed: false
    },
    {
      due_date: "2025-11-23",
      course: "DMAN7100E Intro to Disaster Management",
      assignment: "Mitigation Proposal (Module 11)",
      type: "Project Proposal",
      description: "Submit mitigation project proposal addressing top county hazard with cost-benefit analysis.",
      completed: false
    },
    {
      due_date: "2025-12-07",
      course: "HPAM7700E Leadership Mgmt of PH Org NGO",
      assignment: "Personal Leadership Framework",
      type: "Final Project",
      description: "Develop and submit personal leadership framework per course module instructions.",
      completed: false
    }
  ]);

  const [filter, setFilter] = useState<string>("all");
  const [sortBy, setSortBy] = useState<string>("date");

  const toggleTaskCompletion = (index: number) => {
    setTasks(prev => prev.map((task, i) => 
      i === index ? { ...task, completed: !task.completed } : task
    ));
  };

  const addTask = (task: BasicTask) => {
    setTasks(prev => [
      ...prev,
      {
        due_date: task.due_date,
        course: task.course,
        assignment: task.title,
        type: task.type,
        description: task.description,
        completed: false,
      },
    ]);
  };

  const getTypeIcon = (type: string) => {
    switch (type.toLowerCase()) {
      case 'journal': return <PenTool className="w-4 h-4" />;
      case 'exam': return <AlertCircle className="w-4 h-4" />;
      case 'group project': return <Users className="w-4 h-4" />;
      case 'case study': return <FileText className="w-4 h-4" />;
      case 'final project': return <BookOpen className="w-4 h-4" />;
      default: return <FileText className="w-4 h-4" />;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type.toLowerCase()) {
      case 'journal': return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'exam': return 'bg-red-100 text-red-700 border-red-200';
      case 'group project': return 'bg-green-100 text-green-700 border-green-200';
      case 'case study': return 'bg-purple-100 text-purple-700 border-purple-200';
      case 'final project': return 'bg-orange-100 text-orange-700 border-orange-200';
      default: return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  const getDaysUntilDue = (dueDate: string): number => {
    const today = new Date();
    const due = new Date(dueDate);
    const diffTime = due.getTime() - today.getTime();
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  };

  const getUrgencyColor = (daysUntil: number, completed: boolean) => {
    if (completed) return 'border-green-200 bg-green-50';
    if (daysUntil < 0) return 'border-red-300 bg-red-50';
    if (daysUntil <= 3) return 'border-orange-300 bg-orange-50';
    if (daysUntil <= 7) return 'border-yellow-300 bg-yellow-50';
    return 'border-blue-200 bg-blue-50';
  };

  const formatDate = (dateStr: string): string => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', { 
      weekday: 'short',
      month: 'short', 
      day: 'numeric',
      year: 'numeric'
    });
  };

  const getFilteredAndSortedTasks = () => {
    let filtered = tasks;
    
    if (filter === 'pending') {
      filtered = tasks.filter(task => !task.completed);
    } else if (filter === 'completed') {
      filtered = tasks.filter(task => task.completed);
    } else if (filter === 'urgent') {
      filtered = tasks.filter(task => !task.completed && getDaysUntilDue(task.due_date) <= 7);
    } else if (filter === 'hpam') {
      filtered = tasks.filter(task => task.course.includes('HPAM'));
    } else if (filter === 'dman') {
      filtered = tasks.filter(task => task.course.includes('DMAN'));
    }

    if (sortBy === 'date') {
      filtered.sort((a, b) => new Date(a.due_date).getTime() - new Date(b.due_date).getTime());
    } else if (sortBy === 'course') {
      filtered.sort((a, b) => a.course.localeCompare(b.course));
    } else if (sortBy === 'type') {
      filtered.sort((a, b) => a.type.localeCompare(b.type));
    }

    return filtered;
  };

  const filteredTasks = getFilteredAndSortedTasks();
  const completedCount = tasks.filter(task => task.completed).length;
  const urgentCount = tasks.filter(task => !task.completed && getDaysUntilDue(task.due_date) <= 7).length;

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <BookOpen className="w-6 h-6 text-blue-600" />
              Academic Tasks - Fall 2025
            </CardTitle>
            <AddTaskModal
              onAdd={addTask}
              triggerText="Add Assignment"
              triggerIcon={<Plus className="w-4 h-4" />}
              modalTitle="Add New Assignment"
              modalDescription="Add a new academic task or assignment"
              defaultCourse="HPAM7700E"
              predefinedTypes={["Assignment", "Exam", "Journal", "Case Study", "Group Project", "Final Project", "Quiz", "Discussion", "Reading", "Lab"]}
              predefinedCourses={["HPAM7700E Leadership Mgmt of PH Org NGO", "DMAN7100E Intro to Disaster Management", "BIOS7210", "EPID7001", "ENVH7005", "HLTH7015"]}
              colorTheme="blue"
              showAdvancedOptions={true}
            />
          </div>
          <div className="flex flex-wrap gap-4 mt-4">
            <div className="text-sm">
              <span className="text-blue-700">Total: </span>
              <span className="font-semibold">{tasks.length}</span>
            </div>
            <div className="text-sm">
              <span className="text-green-700">Completed: </span>
              <span className="font-semibold">{completedCount}</span>
            </div>
            <div className="text-sm">
              <span className="text-orange-700">Urgent (≤7 days): </span>
              <span className="font-semibold">{urgentCount}</span>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-3 mb-6">
            <Select value={filter} onValueChange={setFilter}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Filter tasks" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Tasks</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
                <SelectItem value="urgent">Urgent (≤7 days)</SelectItem>
                <SelectItem value="hpam">Leadership Course</SelectItem>
                <SelectItem value="dman">Disaster Management</SelectItem>
              </SelectContent>
            </Select>

            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="date">Due Date</SelectItem>
                <SelectItem value="course">Course</SelectItem>
                <SelectItem value="type">Assignment Type</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-4">
            {filteredTasks.map((task, index) => {
              const originalIndex = tasks.findIndex(t => t === task);
              const daysUntil = getDaysUntilDue(task.due_date);
              
              return (
                <Card 
                  key={originalIndex} 
                  className={`${getUrgencyColor(daysUntil, task.completed || false)} transition-all duration-200 hover:shadow-md`}
                >
                  <CardContent className="p-4">
                    <div className="flex items-start gap-3">
                      <Checkbox
                        checked={task.completed || false}
                        onCheckedChange={() => toggleTaskCompletion(originalIndex)}
                        className="mt-1"
                      />
                      
                      <div className="flex-1 min-w-0">
                        <div className="flex flex-wrap items-center gap-2 mb-2">
                          <Badge className={`${getTypeColor(task.type)} flex items-center gap-1`}>
                            {getTypeIcon(task.type)}
                            {task.type}
                          </Badge>
                          
                          <div className="flex items-center gap-1 text-sm text-gray-600">
                            <Calendar className="w-4 h-4" />
                            {formatDate(task.due_date)}
                          </div>
                          
                          {daysUntil >= 0 && !task.completed && (
                            <div className={`flex items-center gap-1 text-sm ${
                              daysUntil <= 3 ? 'text-red-600' : 
                              daysUntil <= 7 ? 'text-orange-600' : 
                              'text-green-600'
                            }`}>
                              <Clock className="w-4 h-4" />
                              {daysUntil === 0 ? 'Due today' : 
                               daysUntil === 1 ? 'Due tomorrow' : 
                               `${daysUntil} days left`}
                            </div>
                          )}
                          
                          {daysUntil < 0 && !task.completed && (
                            <div className="flex items-center gap-1 text-sm text-red-600">
                              <AlertCircle className="w-4 h-4" />
                              {Math.abs(daysUntil)} days overdue
                            </div>
                          )}
                        </div>
                        
                        <h4 className={`mb-1 ${task.completed ? 'line-through text-gray-500' : ''}`}>
                          {task.assignment}
                        </h4>
                        
                        <p className="text-sm text-gray-600 mb-2">
                          {task.course}
                        </p>
                        
                        <p className={`text-sm ${task.completed ? 'text-gray-400' : 'text-gray-700'}`}>
                          {task.description}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
          
          {filteredTasks.length === 0 && (
            <div className="text-center py-8 text-gray-500">
              No tasks match the current filter criteria.
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}