import { Button } from "./ui/button";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export function ColorfulHero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Gradient Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-purple-200 via-pink-200 to-peach-200 opacity-90"></div>
      
      {/* Floating Elements */}
      <div className="absolute top-20 left-10 w-32 h-32 bg-gradient-to-r from-cyan-200 to-blue-200 rounded-full opacity-70 blur-xl animate-pulse"></div>
      <div className="absolute bottom-20 right-10 w-40 h-40 bg-gradient-to-r from-green-200 to-teal-200 rounded-full opacity-60 blur-xl animate-pulse delay-1000"></div>
      <div className="absolute top-1/3 right-1/4 w-24 h-24 bg-gradient-to-r from-yellow-200 to-rose-200 rounded-full opacity-50 blur-xl animate-pulse delay-500"></div>
      
      {/* Content */}
      <div className="relative z-10 text-center text-white px-6 max-w-4xl mx-auto">
        <h1 className="text-5xl md:text-7xl mb-6 bg-gradient-to-r from-purple-400 via-pink-300 to-rose-300 bg-clip-text text-transparent">
          Pastel Frontend
        </h1>
        <p className="text-xl md:text-2xl mb-8 text-gray-700 max-w-2xl mx-auto">
          Experience the elegance of soft design with our beautiful, gentle components
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button className="bg-gradient-to-r from-pink-300 to-violet-300 hover:from-pink-400 hover:to-violet-400 text-gray-700 px-8 py-3 text-lg shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105">
            Get Started
          </Button>
          <Button 
            variant="outline" 
            className="border-purple-300 text-purple-400 hover:bg-purple-100 hover:text-purple-600 px-8 py-3 text-lg transition-all duration-300 transform hover:scale-105"
          >
            Learn More
          </Button>
        </div>
      </div>
    </section>
  );
}