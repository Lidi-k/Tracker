import { useState, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Badge } from "./ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "./ui/dialog";
import { Textarea } from "./ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Separator } from "./ui/separator";
import { Progress } from "./ui/progress";
import { 
  BookOpen, 
  Brain, 
  FileText, 
  Mic, 
  Video, 
  Plus, 
  Search,
  Filter,
  Users,
  Calendar,
  AlertCircle,
  CheckCircle,
  Clock,
  PlusCircle,
  ExternalLink,
  Download,
  Upload,
  Share2,
  Bookmark,
  Tag,
  GitBranch,
  TrendingUp,
  BarChart3,
  Network,
  Lightbulb,
  Archive,
  Star,
  Eye,
  Edit,
  Trash2,
  Copy,
  Move,
  Pin,
  Settings,
  RefreshCw,
  Zap
} from "lucide-react";

interface ResearchSource {
  id: string;
  title: string;
  type: 'Academic Paper' | 'Website' | 'Book' | 'Report' | 'Video' | 'Podcast' | 'Interview' | 'Dataset';
  url?: string;
  authors?: string[];
  year?: number;
  notes: string;
  tags: string[];
  credibility: 1 | 2 | 3 | 4 | 5;
  dateAdded: string;
  lastAccessed?: string;
}

interface ResearchTask {
  id: string;
  task: string;
  owner: string;
  status: 'To Do' | 'In Progress' | 'Review' | 'Done' | 'Stuck';
  due: string;
  priority: 'Low' | 'Medium' | 'High';
  notes: string;
  sources: ResearchSource[];
  workspace: string;
  tags: string[];
  dependencies: string[];
  estimatedHours?: number;
  actualHours?: number;
  createdAt: string;
  updatedAt: string;
}

interface AIStudioTool {
  id: string;
  name: string;
  description: string;
  icon: any;
  lastUsed?: string;
  isGenerating?: boolean;
}

export function ResearchWorkspace() {
  const [selectedWorkspace, setSelectedWorkspace] = useState("Academic Research");
  const [viewMode, setViewMode] = useState<'kanban' | 'table' | 'calendar'>('kanban');
  const [tasks, setTasks] = useState<ResearchTask[]>([
    { 
      id: '1',
      task: "Literature Review - Leadership Theories", 
      owner: "Lk", 
      status: "In Progress", 
      due: "2025-09-21", 
      priority: "High", 
      notes: "Focus on transformational vs servant leadership for Journal 03",
      sources: [
        {
          id: 's1',
          title: "Full Range Leadership Development",
          type: "Academic Paper",
          authors: ["Bass, B.M.", "Riggio, R.E."],
          year: 2006,
          notes: "Foundational text on transformational leadership theory",
          tags: ["leadership", "transformational", "theory"],
          credibility: 5,
          dateAdded: "2025-09-10",
          url: "https://example.com/bass-riggio-2006"
        }
      ],
      workspace: "Academic Research",
      tags: ["leadership", "literature-review", "journal-03"],
      dependencies: [],
      estimatedHours: 8,
      actualHours: 5,
      createdAt: "2025-09-10",
      updatedAt: "2025-09-12"
    },
    { 
      id: '2',
      task: "Rabun County Demographics Research", 
      owner: "Lk", 
      status: "To Do", 
      due: "2025-09-15", 
      priority: "Medium", 
      notes: "Need population data, vulnerable groups, infrastructure",
      sources: [
        {
          id: 's2',
          title: "US Census Bureau - Rabun County Data",
          type: "Dataset",
          notes: "Official demographic and economic data",
          tags: ["demographics", "census", "rabun-county"],
          credibility: 5,
          dateAdded: "2025-09-11",
          url: "https://census.gov/rabun-county"
        }
      ],
      workspace: "Disaster Management",
      tags: ["demographics", "disaster-planning", "rabun-county"],
      dependencies: [],
      estimatedHours: 6,
      createdAt: "2025-09-10",
      updatedAt: "2025-09-11"
    },
    { 
      id: '3',
      task: "FEMA IS-100 Course Materials", 
      owner: "Lk", 
      status: "Done", 
      due: "2025-12-08", 
      priority: "Low", 
      notes: "Completed course, need to review for certification",
      sources: [
        {
          id: 's3',
          title: "FEMA Emergency Management Institute",
          type: "Website",
          notes: "Official FEMA training materials and certification info",
          tags: ["fema", "certification", "emergency-management"],
          credibility: 5,
          dateAdded: "2025-09-05",
          url: "https://training.fema.gov"
        }
      ],
      workspace: "Professional Development",
      tags: ["fema", "certification", "professional-development"],
      dependencies: [],
      estimatedHours: 4,
      actualHours: 4,
      createdAt: "2025-09-05",
      updatedAt: "2025-09-08"
    },
    {
      id: '4',
      task: "BUILD Health Challenge Case Analysis",
      owner: "Lk",
      status: "Review",
      due: "2025-10-05",
      priority: "High",
      notes: "Analyze change management strategies, prepare presentation",
      sources: [
        {
          id: 's4',
          title: "BUILD Health Challenge Case Studies",
          type: "Report",
          notes: "Comprehensive case studies of successful health initiatives",
          tags: ["build-health", "case-study", "change-management"],
          credibility: 4,
          dateAdded: "2025-09-08",
          url: "https://buildhealthchallenge.org/case-studies"
        }
      ],
      workspace: "Academic Research",
      tags: ["build-health", "case-analysis", "change-management"],
      dependencies: ["1"],
      estimatedHours: 10,
      actualHours: 7,
      createdAt: "2025-09-08",
      updatedAt: "2025-09-12"
    }
  ]);

  const [aiStudioTools] = useState<AIStudioTool[]>([
    { id: 'mindmap', name: 'Mind Map Generator', description: 'Create visual concept maps from your research', icon: Network },
    { id: 'report', name: 'Research Report', description: 'Auto-generate research summaries', icon: FileText },
    { id: 'timeline', name: 'Research Timeline', description: 'Visualize research progress over time', icon: TrendingUp },
    { id: 'insights', name: 'Key Insights', description: 'Extract patterns and insights from data', icon: Lightbulb },
    { id: 'bibliography', name: 'Bibliography Builder', description: 'Format citations automatically', icon: BookOpen },
    { id: 'summary', name: 'Audio Summary', description: 'Generate audio overviews', icon: Mic }
  ]);

  const [newTask, setNewTask] = useState({
    task: '',
    status: 'To Do' as const,
    due: '',
    priority: 'Medium' as const,
    notes: '',
    workspace: selectedWorkspace,
    tags: [] as string[],
    estimatedHours: 0
  });

  const [selectedTask, setSelectedTask] = useState<ResearchTask | null>(null);
  const [isAddingTask, setIsAddingTask] = useState(false);
  const [isTaskDetailsOpen, setIsTaskDetailsOpen] = useState(false);
  const [isAIStudioOpen, setIsAIStudioOpen] = useState(false);
  const [selectedAITool, setSelectedAITool] = useState<AIStudioTool | null>(null);
  const [aiGeneratedContent, setAIGeneratedContent] = useState<string>('');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [draggedTask, setDraggedTask] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const workspaces = [
    { name: "Academic Research", icon: "🎓", color: "bg-blue-50 text-blue-700" },
    { name: "Disaster Management", icon: "🚨", color: "bg-red-50 text-red-700" },
    { name: "Professional Development", icon: "💼", color: "bg-green-50 text-green-700" },
    { name: "Health Projects", icon: "🏥", color: "bg-purple-50 text-purple-700" },
    { name: "Volunteering", icon: "🤝", color: "bg-orange-50 text-orange-700" }
  ];

  const statusColumns = [
    { status: 'To Do', color: 'bg-gray-50', count: 0 },
    { status: 'In Progress', color: 'bg-blue-50', count: 0 },
    { status: 'Review', color: 'bg-yellow-50', count: 0 },
    { status: 'Stuck', color: 'bg-red-50', count: 0 },
    { status: 'Done', color: 'bg-green-50', count: 0 }
  ];

  const filteredTasks = tasks.filter(task => {
    const matchesWorkspace = selectedWorkspace === "All Workspaces" || task.workspace === selectedWorkspace;
    const matchesSearch = searchQuery === '' || 
      task.task.toLowerCase().includes(searchQuery.toLowerCase()) ||
      task.notes.toLowerCase().includes(searchQuery.toLowerCase()) ||
      task.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesTags = selectedTags.length === 0 || 
      selectedTags.some(tag => task.tags.includes(tag));
    
    return matchesWorkspace && matchesSearch && matchesTags;
  });

  const allTags = Array.from(new Set(tasks.flatMap(task => task.tags)));

  // Update status column counts
  statusColumns.forEach(column => {
    column.count = filteredTasks.filter(task => task.status === column.status).length;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Done': return 'bg-green-100 text-green-700 border-green-200';
      case 'In Progress': return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'Review': return 'bg-yellow-100 text-yellow-700 border-yellow-200';
      case 'Stuck': return 'bg-red-100 text-red-700 border-red-200';
      default: return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'High': return 'bg-red-100 text-red-700';
      case 'Medium': return 'bg-yellow-100 text-yellow-700';
      case 'Low': return 'bg-green-100 text-green-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'Done': return <CheckCircle className="w-4 h-4" />;
      case 'In Progress': return <Clock className="w-4 h-4" />;
      case 'Review': return <AlertCircle className="w-4 h-4" />;
      case 'Stuck': return <AlertCircle className="w-4 h-4" />;
      default: return <Clock className="w-4 h-4" />;
    }
  };

  const addTask = () => {
    if (!newTask.task.trim()) return;
    
    const now = new Date().toISOString();
    const task: ResearchTask = {
      id: Date.now().toString(),
      task: newTask.task,
      owner: "Lk",
      status: newTask.status,
      due: newTask.due,
      priority: newTask.priority,
      notes: newTask.notes,
      sources: [],
      workspace: newTask.workspace,
      tags: newTask.tags,
      dependencies: [],
      estimatedHours: newTask.estimatedHours,
      createdAt: now,
      updatedAt: now
    };

    setTasks(prev => [...prev, task]);
    setNewTask({ 
      task: '', 
      status: 'To Do', 
      due: '', 
      priority: 'Medium', 
      notes: '', 
      workspace: selectedWorkspace,
      tags: [],
      estimatedHours: 0
    });
    setIsAddingTask(false);
  };

  const updateTaskStatus = (taskId: string, newStatus: ResearchTask['status']) => {
    setTasks(prev => prev.map(task => 
      task.id === taskId ? { ...task, status: newStatus, updatedAt: new Date().toISOString() } : task
    ));
  };

  const addSource = (taskId: string, sourceData: Partial<ResearchSource>) => {
    if (!sourceData.title?.trim()) return;
    
    const newSource: ResearchSource = {
      id: Date.now().toString(),
      title: sourceData.title,
      type: sourceData.type || 'Website',
      authors: sourceData.authors || [],
      year: sourceData.year,
      url: sourceData.url,
      notes: sourceData.notes || '',
      tags: sourceData.tags || [],
      credibility: sourceData.credibility || 3,
      dateAdded: new Date().toISOString(),
    };
    
    setTasks(prev => prev.map(task => 
      task.id === taskId ? { 
        ...task, 
        sources: [...task.sources, newSource],
        updatedAt: new Date().toISOString()
      } : task
    ));
  };

  const handleDragStart = (e: React.DragEvent, taskId: string) => {
    setDraggedTask(taskId);
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
  };

  const handleDrop = (e: React.DragEvent, newStatus: ResearchTask['status']) => {
    e.preventDefault();
    if (draggedTask) {
      updateTaskStatus(draggedTask, newStatus);
      setDraggedTask(null);
    }
  };

  const generateAIContent = async (tool: AIStudioTool) => {
    setSelectedAITool(tool);
    setIsAIStudioOpen(true);
    
    // Simulate AI generation
    setTimeout(() => {
      let content = '';
      switch (tool.id) {
        case 'mindmap':
          content = `# Research Mind Map: ${selectedWorkspace}

## Core Concepts
- Leadership Theories
  - Transformational Leadership
  - Servant Leadership
  - Authentic Leadership
- Change Management
  - Organizational Development
  - Stakeholder Engagement

## Research Questions
1. How do leadership styles impact organizational change?
2. What are the key success factors in health initiatives?
3. How can disaster management principles apply to organizational resilience?

## Methodologies
- Literature Review
- Case Study Analysis
- Comparative Analysis`;
          break;
        case 'report':
          content = `# Research Progress Report: ${selectedWorkspace}

## Executive Summary
Current research focus encompasses ${filteredTasks.length} active tasks across leadership development and disaster management domains.

## Key Findings
- Literature review reveals strong correlation between transformational leadership and organizational success
- Case studies demonstrate importance of stakeholder engagement in health initiatives
- FEMA certification provides foundational emergency management knowledge

## Next Steps
1. Complete literature review synthesis
2. Analyze BUILD Health Challenge cases
3. Integrate findings into comprehensive framework

## Timeline
- Immediate priorities: ${filteredTasks.filter(t => t.priority === 'High').length} high-priority tasks
- Completion target: ${filteredTasks.filter(t => t.status !== 'Done').length} remaining tasks`;
          break;
        case 'insights':
          content = `# Key Research Insights

## Patterns Identified
1. **Leadership Effectiveness**: Transformational approaches show 40% higher success rates
2. **Implementation Challenges**: Resource constraints and stakeholder resistance are primary barriers
3. **Success Factors**: Clear communication and phased implementation critical

## Emerging Themes
- Integration of theory and practice
- Importance of contextual adaptation
- Role of organizational culture

## Recommendations
- Focus on practical application frameworks
- Develop case-based learning materials
- Create implementation toolkits`;
          break;
        default:
          content = `# ${tool.name} Output

Generated content for ${selectedWorkspace} research workspace.
This is a simulated AI-generated response demonstrating the ${tool.description.toLowerCase()}.`;
      }
      setAIGeneratedContent(content);
    }, 2000);
  };

  const exportWorkspace = () => {
    const workspaceData = {
      name: selectedWorkspace,
      tasks: filteredTasks,
      exportDate: new Date().toISOString(),
      summary: {
        totalTasks: filteredTasks.length,
        completedTasks: filteredTasks.filter(t => t.status === 'Done').length,
        totalSources: filteredTasks.reduce((acc, task) => acc + task.sources.length, 0)
      }
    };

    const blob = new Blob([JSON.stringify(workspaceData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${selectedWorkspace.replace(/\s+/g, '_')}_research_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="grid grid-cols-12 gap-6 h-[calc(100vh-200px)]">
      {/* Sidebar */}
      <div className="col-span-3 space-y-4 overflow-y-auto">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BookOpen className="w-5 h-5" />
              Research Workspaces
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <Button
              variant={selectedWorkspace === "All Workspaces" ? "default" : "ghost"}
              className="w-full justify-start"
              onClick={() => setSelectedWorkspace("All Workspaces")}
            >
              📊 All Workspaces
              <Badge variant="secondary" className="ml-auto">
                {tasks.length}
              </Badge>
            </Button>
            {workspaces.map((workspace) => (
              <Button
                key={workspace.name}
                variant={selectedWorkspace === workspace.name ? "default" : "ghost"}
                className="w-full justify-start"
                onClick={() => setSelectedWorkspace(workspace.name)}
              >
                <span className="mr-2">{workspace.icon}</span>
                {workspace.name}
                <Badge variant="secondary" className="ml-auto">
                  {tasks.filter(t => t.workspace === workspace.name).length}
                </Badge>
              </Button>
            ))}
            <Separator className="my-3" />
            <Button 
              className="w-full" 
              onClick={() => setIsAddingTask(true)}
            >
              <Plus className="w-4 h-4 mr-2" />
              New Research Task
            </Button>
          </CardContent>
        </Card>

        {/* AI Studio Tools */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Brain className="w-5 h-5" />
              AI Research Studio
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {aiStudioTools.map((tool) => (
              <Button 
                key={tool.id}
                className="w-full justify-start" 
                variant="outline"
                onClick={() => generateAIContent(tool)}
              >
                <tool.icon className="w-4 h-4 mr-2" />
                {tool.name}
              </Button>
            ))}
          </CardContent>
        </Card>

        {/* Workspace Analytics */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5" />
              Analytics
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Completion Rate</span>
                <span>{Math.round((filteredTasks.filter(t => t.status === 'Done').length / Math.max(filteredTasks.length, 1)) * 100)}%</span>
              </div>
              <Progress value={(filteredTasks.filter(t => t.status === 'Done').length / Math.max(filteredTasks.length, 1)) * 100} />
            </div>
            <div className="grid grid-cols-2 gap-2 text-sm">
              <div className="text-center p-2 bg-blue-50 rounded">
                <div className="font-medium text-blue-700">{filteredTasks.filter(t => t.status === 'In Progress').length}</div>
                <div className="text-blue-600">Active</div>
              </div>
              <div className="text-center p-2 bg-yellow-50 rounded">
                <div className="font-medium text-yellow-700">{filteredTasks.filter(t => t.status === 'Review').length}</div>
                <div className="text-yellow-600">Review</div>
              </div>
            </div>
            <Button variant="outline" size="sm" className="w-full" onClick={exportWorkspace}>
              <Download className="w-4 h-4 mr-2" />
              Export Data
            </Button>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Zap className="w-5 h-5" />
              Quick Actions
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <Button variant="outline" size="sm" className="w-full justify-start">
              <Share2 className="w-4 h-4 mr-2" />
              Share Workspace
            </Button>
            <Button variant="outline" size="sm" className="w-full justify-start">
              <Archive className="w-4 h-4 mr-2" />
              Archive Completed
            </Button>
            <Button variant="outline" size="sm" className="w-full justify-start">
              <RefreshCw className="w-4 h-4 mr-2" />
              Sync Sources
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Area */}
      <div className="col-span-9 overflow-y-auto">
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-bold">
              {selectedWorkspace === "All Workspaces" ? "All Research Tasks" : selectedWorkspace}
            </h1>
            <div className="flex gap-2">
              <div className="relative">
                <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <Input 
                  placeholder="Search tasks..." 
                  className="pl-10 w-64"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <Select value={viewMode} onValueChange={(value) => setViewMode(value as any)}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="kanban">Kanban</SelectItem>
                  <SelectItem value="table">Table</SelectItem>
                  <SelectItem value="calendar">Calendar</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Tag Filter */}
          {allTags.length > 0 && (
            <div className="flex flex-wrap gap-2">
              <span className="text-sm font-medium">Filter by tags:</span>
              {allTags.map(tag => (
                <Button
                  key={tag}
                  variant={selectedTags.includes(tag) ? "default" : "outline"}
                  size="sm"
                  onClick={() => {
                    setSelectedTags(prev => 
                      prev.includes(tag) 
                        ? prev.filter(t => t !== tag)
                        : [...prev, tag]
                    );
                  }}
                >
                  <Tag className="w-3 h-3 mr-1" />
                  {tag}
                </Button>
              ))}
              {selectedTags.length > 0 && (
                <Button variant="ghost" size="sm" onClick={() => setSelectedTags([])}>
                  Clear filters
                </Button>
              )}
            </div>
          )}

          {/* Dynamic View Rendering */}
          {viewMode === 'kanban' && (
            <div className="grid grid-cols-5 gap-4 h-[600px]">
              {statusColumns.map((column) => (
                <Card key={column.status} className={`${column.color} border-2`}>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm flex items-center justify-between">
                      {column.status}
                      <Badge variant="secondary">{column.count}</Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent 
                    className="space-y-3 overflow-y-auto max-h-[500px]"
                    onDragOver={handleDragOver}
                    onDrop={(e) => handleDrop(e, column.status as ResearchTask['status'])}
                  >
                    {filteredTasks
                      .filter(task => task.status === column.status)
                      .map((task) => (
                        <Card 
                          key={task.id} 
                          className="cursor-move hover:shadow-md transition-shadow bg-white"
                          draggable
                          onDragStart={(e) => handleDragStart(e, task.id)}
                        >
                          <CardContent className="p-3">
                            <div className="space-y-2">
                              <div className="font-medium text-sm line-clamp-2">{task.task}</div>
                              <div className="flex items-center gap-1 text-xs text-gray-500">
                                <Calendar className="w-3 h-3" />
                                {new Date(task.due).toLocaleDateString()}
                              </div>
                              <div className="flex items-center justify-between">
                                <Badge size="sm" className={getPriorityColor(task.priority)}>
                                  {task.priority}
                                </Badge>
                                <div className="flex items-center gap-1 text-xs text-gray-500">
                                  <FileText className="w-3 h-3" />
                                  {task.sources.length}
                                </div>
                              </div>
                              {task.tags.length > 0 && (
                                <div className="flex flex-wrap gap-1">
                                  {task.tags.slice(0, 2).map(tag => (
                                    <Badge key={tag} variant="outline" className="text-xs">
                                      {tag}
                                    </Badge>
                                  ))}
                                  {task.tags.length > 2 && (
                                    <Badge variant="outline" className="text-xs">
                                      +{task.tags.length - 2}
                                    </Badge>
                                  )}
                                </div>
                              )}
                              <div className="flex gap-1">
                                <Button 
                                  size="sm" 
                                  variant="ghost"
                                  className="h-6 px-2 text-xs"
                                  onClick={() => {
                                    setSelectedTask(task);
                                    setIsTaskDetailsOpen(true);
                                  }}
                                >
                                  <Eye className="w-3 h-3" />
                                </Button>
                                <Button 
                                  size="sm" 
                                  variant="ghost"
                                  className="h-6 px-2 text-xs"
                                >
                                  <Edit className="w-3 h-3" />
                                </Button>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                  </CardContent>
                </Card>
              ))}
            </div>
          )}

          {viewMode === 'table' && (
            <Card>
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="text-left p-4">Task</th>
                        <th className="text-left p-4">Status</th>
                        <th className="text-left p-4">Due Date</th>
                        <th className="text-left p-4">Priority</th>
                        <th className="text-left p-4">Sources</th>
                        <th className="text-left p-4">Tags</th>
                        <th className="text-left p-4">Progress</th>
                        <th className="text-left p-4">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredTasks.map((task) => (
                        <tr key={task.id} className="border-b hover:bg-gray-50">
                          <td className="p-4">
                            <div>
                              <div className="font-medium">{task.task}</div>
                              <div className="text-sm text-gray-500">{task.workspace}</div>
                            </div>
                          </td>
                          <td className="p-4">
                            <Badge className={getStatusColor(task.status)}>
                              {getStatusIcon(task.status)}
                              <span className="ml-1">{task.status}</span>
                            </Badge>
                          </td>
                          <td className="p-4">
                            <div className="flex items-center gap-1 text-sm text-gray-600">
                              <Calendar className="w-4 h-4" />
                              {new Date(task.due).toLocaleDateString()}
                            </div>
                          </td>
                          <td className="p-4">
                            <Badge className={getPriorityColor(task.priority)}>
                              {task.priority}
                            </Badge>
                          </td>
                          <td className="p-4">
                            <div className="flex items-center gap-1 text-sm text-gray-600">
                              <FileText className="w-4 h-4" />
                              {task.sources.length} sources
                            </div>
                          </td>
                          <td className="p-4">
                            <div className="flex flex-wrap gap-1">
                              {task.tags.slice(0, 2).map(tag => (
                                <Badge key={tag} variant="outline" className="text-xs">
                                  {tag}
                                </Badge>
                              ))}
                              {task.tags.length > 2 && (
                                <Badge variant="outline" className="text-xs">
                                  +{task.tags.length - 2}
                                </Badge>
                              )}
                            </div>
                          </td>
                          <td className="p-4">
                            <div className="text-xs text-gray-500">
                              {task.actualHours || 0}h / {task.estimatedHours || 0}h
                            </div>
                            {task.estimatedHours && (
                              <Progress 
                                value={Math.min(((task.actualHours || 0) / task.estimatedHours) * 100, 100)} 
                                className="w-20 h-2 mt-1"
                              />
                            )}
                          </td>
                          <td className="p-4">
                            <div className="flex gap-1">
                              <Button 
                                size="sm" 
                                variant="outline"
                                onClick={() => {
                                  setSelectedTask(task);
                                  setIsTaskDetailsOpen(true);
                                }}
                              >
                                <Eye className="w-4 h-4" />
                              </Button>
                              <Button size="sm" variant="outline">
                                <Edit className="w-4 h-4" />
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          )}

          {viewMode === 'calendar' && (
            <Card>
              <CardContent className="p-6">
                <div className="grid grid-cols-7 gap-4">
                  {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
                    <div key={day} className="text-center font-medium text-gray-500 p-2">
                      {day}
                    </div>
                  ))}
                  {Array.from({ length: 35 }, (_, i) => {
                    const date = new Date();
                    date.setDate(date.getDate() - date.getDay() + i);
                    const dayTasks = filteredTasks.filter(task => 
                      new Date(task.due).toDateString() === date.toDateString()
                    );
                    
                    return (
                      <div key={i} className="border rounded p-2 h-24 overflow-y-auto">
                        <div className="text-sm font-medium">{date.getDate()}</div>
                        {dayTasks.map(task => (
                          <div 
                            key={task.id} 
                            className={`text-xs p-1 rounded mt-1 ${getPriorityColor(task.priority)}`}
                          >
                            {task.task.slice(0, 20)}...
                          </div>
                        ))}
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {/* Enhanced Task Details Modal */}
      <Dialog open={isTaskDetailsOpen} onOpenChange={setIsTaskDetailsOpen}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          {selectedTask && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  {selectedTask.task}
                  <Badge className={getPriorityColor(selectedTask.priority)}>
                    {selectedTask.priority}
                  </Badge>
                </DialogTitle>
                <DialogDescription>
                  {selectedTask.workspace} • Created {new Date(selectedTask.createdAt).toLocaleDateString()}
                </DialogDescription>
              </DialogHeader>
              
              <Tabs defaultValue="details" className="w-full">
                <TabsList className="grid w-full grid-cols-4">
                  <TabsTrigger value="details">Details</TabsTrigger>
                  <TabsTrigger value="sources">Sources ({selectedTask.sources.length})</TabsTrigger>
                  <TabsTrigger value="progress">Progress</TabsTrigger>
                  <TabsTrigger value="collaboration">Collaboration</TabsTrigger>
                </TabsList>
                
                <TabsContent value="details" className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium">Status</label>
                      <Select 
                        value={selectedTask.status}
                        onValueChange={(value) => updateTaskStatus(selectedTask.id, value as ResearchTask['status'])}
                      >
                        <SelectTrigger className="mt-1">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="To Do">To Do</SelectItem>
                          <SelectItem value="In Progress">In Progress</SelectItem>
                          <SelectItem value="Review">Review</SelectItem>
                          <SelectItem value="Done">Done</SelectItem>
                          <SelectItem value="Stuck">Stuck</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <label className="text-sm font-medium">Due Date</label>
                      <Input
                        type="date"
                        value={selectedTask.due}
                        onChange={(e) => {
                          setTasks(prev => prev.map(t => 
                            t.id === selectedTask.id ? { ...t, due: e.target.value, updatedAt: new Date().toISOString() } : t
                          ));
                          setSelectedTask(prev => prev ? { ...prev, due: e.target.value } : null);
                        }}
                        className="mt-1"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium">Notes & Description</label>
                    <Textarea 
                      value={selectedTask.notes}
                      onChange={(e) => {
                        const updatedNotes = e.target.value;
                        setTasks(prev => prev.map(t => 
                          t.id === selectedTask.id ? { ...t, notes: updatedNotes, updatedAt: new Date().toISOString() } : t
                        ));
                        setSelectedTask(prev => prev ? { ...prev, notes: updatedNotes } : null);
                      }}
                      className="mt-1"
                      rows={4}
                      placeholder="Add detailed notes, objectives, methodology, etc."
                    />
                  </div>

                  <div>
                    <label className="text-sm font-medium">Tags</label>
                    <div className="flex flex-wrap gap-2 mt-2">
                      {selectedTask.tags.map(tag => (
                        <Badge key={tag} variant="secondary" className="flex items-center gap-1">
                          {tag}
                          <button 
                            onClick={() => {
                              const newTags = selectedTask.tags.filter(t => t !== tag);
                              setTasks(prev => prev.map(t => 
                                t.id === selectedTask.id ? { ...t, tags: newTags, updatedAt: new Date().toISOString() } : t
                              ));
                              setSelectedTask(prev => prev ? { ...prev, tags: newTags } : null);
                            }}
                            className="text-xs hover:text-red-500"
                          >
                            ×
                          </button>
                        </Badge>
                      ))}
                      <Input
                        placeholder="Add tag..."
                        className="w-32 h-6"
                        onKeyPress={(e) => {
                          if (e.key === 'Enter' && e.currentTarget.value.trim()) {
                            const newTag = e.currentTarget.value.trim();
                            if (!selectedTask.tags.includes(newTag)) {
                              const newTags = [...selectedTask.tags, newTag];
                              setTasks(prev => prev.map(t => 
                                t.id === selectedTask.id ? { ...t, tags: newTags, updatedAt: new Date().toISOString() } : t
                              ));
                              setSelectedTask(prev => prev ? { ...prev, tags: newTags } : null);
                            }
                            e.currentTarget.value = '';
                          }
                        }}
                      />
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="sources" className="space-y-4">
                  <div className="flex justify-between items-center">
                    <h3 className="font-medium">Research Sources</h3>
                    <Button size="sm">
                      <Plus className="w-4 h-4 mr-2" />
                      Add Source
                    </Button>
                  </div>
                  
                  <div className="space-y-3">
                    {selectedTask.sources.map((source) => (
                      <Card key={source.id}>
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-2">
                                <FileText className="w-4 h-4" />
                                <span className="font-medium">{source.title}</span>
                                <Badge variant="outline">{source.type}</Badge>
                                <div className="flex">
                                  {Array.from({ length: source.credibility }, (_, i) => (
                                    <Star key={i} className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                                  ))}
                                </div>
                              </div>
                              {source.authors && source.authors.length > 0 && (
                                <div className="text-sm text-gray-600 mb-1">
                                  Authors: {source.authors.join(', ')}
                                </div>
                              )}
                              {source.year && (
                                <div className="text-sm text-gray-600 mb-1">Year: {source.year}</div>
                              )}
                              {source.notes && (
                                <div className="text-sm text-gray-700 mb-2">{source.notes}</div>
                              )}
                              <div className="flex flex-wrap gap-1">
                                {source.tags.map(tag => (
                                  <Badge key={tag} variant="outline" className="text-xs">
                                    {tag}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                            <div className="flex gap-2">
                              {source.url && (
                                <Button size="sm" variant="outline" asChild>
                                  <a href={source.url} target="_blank" rel="noopener noreferrer">
                                    <ExternalLink className="w-4 h-4" />
                                  </a>
                                </Button>
                              )}
                              <Button size="sm" variant="outline">
                                <Edit className="w-4 h-4" />
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </TabsContent>

                <TabsContent value="progress" className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <Card>
                      <CardContent className="p-4">
                        <h4 className="font-medium mb-2">Time Tracking</h4>
                        <div className="space-y-2">
                          <div className="flex justify-between">
                            <span>Estimated:</span>
                            <span>{selectedTask.estimatedHours || 0}h</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Actual:</span>
                            <span>{selectedTask.actualHours || 0}h</span>
                          </div>
                          {selectedTask.estimatedHours && (
                            <Progress 
                              value={Math.min(((selectedTask.actualHours || 0) / selectedTask.estimatedHours) * 100, 100)} 
                              className="mt-2"
                            />
                          )}
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardContent className="p-4">
                        <h4 className="font-medium mb-2">Completion Status</h4>
                        <div className="space-y-2">
                          <div className="flex items-center gap-2">
                            {getStatusIcon(selectedTask.status)}
                            <span>{selectedTask.status}</span>
                          </div>
                          <div className="text-sm text-gray-600">
                            Last updated: {new Date(selectedTask.updatedAt).toLocaleDateString()}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </TabsContent>

                <TabsContent value="collaboration" className="space-y-4">
                  <Card>
                    <CardContent className="p-4">
                      <h4 className="font-medium mb-3">Share & Collaborate</h4>
                      <div className="space-y-3">
                        <Button variant="outline" className="w-full justify-start">
                          <Share2 className="w-4 h-4 mr-2" />
                          Share Task
                        </Button>
                        <Button variant="outline" className="w-full justify-start">
                          <Users className="w-4 h-4 mr-2" />
                          Add Collaborators
                        </Button>
                        <Button variant="outline" className="w-full justify-start">
                          <Copy className="w-4 h-4 mr-2" />
                          Duplicate Task
                        </Button>
                        <Button variant="outline" className="w-full justify-start">
                          <Archive className="w-4 h-4 mr-2" />
                          Archive Task
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* AI Studio Modal */}
      <Dialog open={isAIStudioOpen} onOpenChange={setIsAIStudioOpen}>
        <DialogContent className="max-w-4xl max-h-[80vh]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Brain className="w-5 h-5" />
              AI Research Studio
              {selectedAITool && ` - ${selectedAITool.name}`}
            </DialogTitle>
            <DialogDescription>
              Generate research insights and visualizations using AI tools
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            {!selectedAITool ? (
              <div className="grid grid-cols-2 gap-4">
                {aiStudioTools.map((tool) => (
                  <Card key={tool.id} className="cursor-pointer hover:shadow-md transition-shadow"
                    onClick={() => generateAIContent(tool)}>
                    <CardContent className="p-4">
                      <div className="flex items-center gap-3">
                        <tool.icon className="w-8 h-8 text-blue-600" />
                        <div>
                          <h3 className="font-medium">{tool.name}</h3>
                          <p className="text-sm text-gray-600">{tool.description}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <selectedAITool.icon className="w-5 h-5" />
                    <span className="font-medium">{selectedAITool.name}</span>
                  </div>
                  <Button variant="outline" onClick={() => setSelectedAITool(null)}>
                    Back to Tools
                  </Button>
                </div>
                
                {aiGeneratedContent ? (
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex justify-between items-center mb-4">
                        <h3 className="font-medium">Generated Content</h3>
                        <div className="flex gap-2">
                          <Button size="sm" variant="outline">
                            <Copy className="w-4 h-4 mr-2" />
                            Copy
                          </Button>
                          <Button size="sm" variant="outline">
                            <Download className="w-4 h-4 mr-2" />
                            Export
                          </Button>
                        </div>
                      </div>
                      <div className="bg-gray-50 p-4 rounded-lg overflow-auto max-h-96">
                        <pre className="whitespace-pre-wrap text-sm">{aiGeneratedContent}</pre>
                      </div>
                    </CardContent>
                  </Card>
                ) : (
                  <Card>
                    <CardContent className="p-8 text-center">
                      <Brain className="w-12 h-12 mx-auto text-blue-600 mb-4 animate-pulse" />
                      <h3 className="font-medium mb-2">Generating {selectedAITool.name}...</h3>
                      <p className="text-sm text-gray-600">
                        Analyzing your research data and generating insights
                      </p>
                    </CardContent>
                  </Card>
                )}
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Enhanced Add Task Modal */}
      <Dialog open={isAddingTask} onOpenChange={setIsAddingTask}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Create New Research Task</DialogTitle>
            <DialogDescription>
              Set up a comprehensive research task with timeline, priorities, and context
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium">Task Title</label>
              <Input
                value={newTask.task}
                onChange={(e) => setNewTask(prev => ({ ...prev, task: e.target.value }))}
                placeholder="Enter descriptive task title..."
                className="mt-1"
              />
            </div>
            
            <div className="grid grid-cols-3 gap-4">
              <div>
                <label className="text-sm font-medium">Status</label>
                <Select 
                  value={newTask.status}
                  onValueChange={(value) => setNewTask(prev => ({ ...prev, status: value as ResearchTask['status'] }))}
                >
                  <SelectTrigger className="mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="To Do">To Do</SelectItem>
                    <SelectItem value="In Progress">In Progress</SelectItem>
                    <SelectItem value="Review">Review</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-sm font-medium">Priority</label>
                <Select 
                  value={newTask.priority}
                  onValueChange={(value) => setNewTask(prev => ({ ...prev, priority: value as ResearchTask['priority'] }))}
                >
                  <SelectTrigger className="mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Low">Low</SelectItem>
                    <SelectItem value="Medium">Medium</SelectItem>
                    <SelectItem value="High">High</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-sm font-medium">Estimated Hours</label>
                <Input
                  type="number"
                  value={newTask.estimatedHours}
                  onChange={(e) => setNewTask(prev => ({ ...prev, estimatedHours: parseInt(e.target.value) || 0 }))}
                  placeholder="0"
                  className="mt-1"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium">Due Date</label>
                <Input
                  type="date"
                  value={newTask.due}
                  onChange={(e) => setNewTask(prev => ({ ...prev, due: e.target.value }))}
                  className="mt-1"
                />
              </div>
              <div>
                <label className="text-sm font-medium">Workspace</label>
                <Select 
                  value={newTask.workspace}
                  onValueChange={(value) => setNewTask(prev => ({ ...prev, workspace: value }))}
                >
                  <SelectTrigger className="mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {workspaces.map(workspace => (
                      <SelectItem key={workspace.name} value={workspace.name}>
                        {workspace.icon} {workspace.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <label className="text-sm font-medium">Tags</label>
              <div className="flex flex-wrap gap-2 mt-2 mb-2">
                {newTask.tags.map(tag => (
                  <Badge key={tag} variant="secondary" className="flex items-center gap-1">
                    {tag}
                    <button 
                      onClick={() => setNewTask(prev => ({ 
                        ...prev, 
                        tags: prev.tags.filter(t => t !== tag) 
                      }))}
                      className="text-xs hover:text-red-500"
                    >
                      ×
                    </button>
                  </Badge>
                ))}
              </div>
              <Input
                placeholder="Add tags (press Enter to add)..."
                onKeyPress={(e) => {
                  if (e.key === 'Enter' && e.currentTarget.value.trim()) {
                    const tag = e.currentTarget.value.trim();
                    if (!newTask.tags.includes(tag)) {
                      setNewTask(prev => ({ ...prev, tags: [...prev.tags, tag] }));
                    }
                    e.currentTarget.value = '';
                  }
                }}
                className="mt-1"
              />
            </div>
            
            <div>
              <label className="text-sm font-medium">Description & Notes</label>
              <Textarea
                value={newTask.notes}
                onChange={(e) => setNewTask(prev => ({ ...prev, notes: e.target.value }))}
                placeholder="Describe the task objectives, methodology, key questions, or context..."
                rows={4}
                className="mt-1"
              />
            </div>

            <Separator />
            
            <div className="flex gap-2 justify-end">
              <Button variant="outline" onClick={() => {
                setIsAddingTask(false);
                setNewTask({ 
                  task: '', 
                  status: 'To Do', 
                  due: '', 
                  priority: 'Medium', 
                  notes: '', 
                  workspace: selectedWorkspace,
                  tags: [],
                  estimatedHours: 0
                });
              }}>
                Cancel
              </Button>
              <Button onClick={addTask} disabled={!newTask.task.trim()}>
                <PlusCircle className="w-4 h-4 mr-2" />
                Create Task
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Hidden file input for importing */}
      <input
        ref={fileInputRef}
        type="file"
        accept=".json"
        className="hidden"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) {
            const reader = new FileReader();
            reader.onload = (event) => {
              try {
                const data = JSON.parse(event.target?.result as string);
                // Handle imported workspace data
                console.log('Imported data:', data);
              } catch (error) {
                console.error('Error parsing imported file:', error);
              }
            };
            reader.readAsText(file);
          }
        }}
      />
    </div>
  );
}